#!/usr/bin/env python3
"""
dashboard_from_json.py — 9-panel CTC dashboard for production sweep runs.

This is the post-processing companion for ctc_beta5*.py output (nucleation
study, mass-gap study, β-scan, volume-scan). For the augmented-action
records produced by ctc_T0i_action_save.py, use dashboard_lite_from_json.py
instead (different panel set: replaces hadron formation with T⁰ⁱ panels).

Panel layout (matches the original ctc_beta5.py end-of-run dashboard):
  (1) Plaquette ⟨P⟩          (2) Vortex %               (3) Acceptance
  (4) ℤ₃ R/G/B counts        (5) ℤ₃ balance              (6) Hadron formation
  (7) Mass gap Δ             (8) Δ vs eddy core count    (9) Mass ratio

Each panel is wrapped in a "if data exists" guard so older runs (without
some keys) render gracefully with empty panels rather than crashing.

2026-05-04 update — metadata detection now reads N, β, seed from the JSON
itself first, then filename, then directory. Fixes the "N = 0" title bug
on records.json files written by ctc_T0i_action_save_v3.py.

2026-05-12 update (Option C, panel 6 fix) — Panel 6 now AUTO-DETECTS a
sibling *_hadrons.json file from measure_hadrons_from_U.py (greedy
matching, v58 m* formula). When present, panel 6 shows the paper-quality
counts as a bar chart instead of the inflated combinatorial counts from
records.json. The records.json combinatorial counts (~10K-25K "RGB Bar"
values) are misleading and have been replaced by the matched-pair census
(~250-600 baryons) whenever available. Falls back to records.json with
clarifying labels if no hadron JSON is found.

Usage
-----
    python3 dashboard_from_json.py CTC_Beta5_N24_b5.0_2026-04-27_220956/records.json
    python3 dashboard_from_json.py records.json --white --outdir figs/
    python3 dashboard_from_json.py records.json --cut_eq 400  # show sweeps >= 400
"""

import argparse
import json
import os
import re
import sys
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt


# --- CLI ----------------------------------------------------------------
ap = argparse.ArgumentParser(
    description='Regenerate the 9-panel CTC dashboard from records.json.')
ap.add_argument('json_file',
                help='Path to records.json saved by ctc_beta5*.py')
ap.add_argument('--outdir', default=None,
                help='Output directory (default: same as records.json)')
ap.add_argument('--dark', action='store_true',
                help='Dark background style (default: white)')
ap.add_argument('--cut_eq', type=int, default=0,
                help='Only plot sweeps >= this value '
                     '(useful for trimming pre-equilibrium transients)')
ap.add_argument('--hadron_json', default=None,
                help='Path to <base>_hadrons.json from measure_hadrons_from_U.py. '
                     'If not specified, auto-detects *_hadrons.json in the same '
                     'directory as records.json. Use --hadron_json "" to disable.')
ap.add_argument('--N',    type=int,   default=None)
ap.add_argument('--beta', type=float, default=None)
ap.add_argument('--seed', type=int,   default=None)
ap.add_argument('--dpi',  type=int,   default=350)
args = ap.parse_args()


# --- load records.json --------------------------------------------------
if not os.path.isfile(args.json_file):
    sys.exit(f"ERROR: file not found: {args.json_file}")

print(f"Loading {args.json_file} ...")
with open(args.json_file) as f:
    records = json.load(f)

if 'sweep' not in records or len(records['sweep']) == 0:
    sys.exit("ERROR: records.json contains no sweep data")


# --- metadata detection -------------------------------------------------
src   = os.path.dirname(os.path.abspath(args.json_file))
fname = os.path.basename(args.json_file)
m_fn  = re.search(r'N(\d+)_b([\d.]+)', fname)
m_dir = re.search(r'N(\d+)_b([\d.]+)', src)


def _records_scalar(key, cast):
    """Read a scalar metadata value from records (handles list or scalar form)."""
    if key not in records or records[key] is None:
        return None
    v = records[key]
    try:
        return cast(v[0]) if isinstance(v, list) and len(v) > 0 else cast(v)
    except (ValueError, TypeError, IndexError):
        return None


# N
if args.N is not None:
    N = args.N
elif _records_scalar('N', int) is not None:
    N = _records_scalar('N', int)
elif m_fn:
    N = int(m_fn.group(1))
elif m_dir:
    N = int(m_dir.group(1))
else:
    N = 0

# beta
if args.beta is not None:
    beta = args.beta
elif _records_scalar('beta', float) is not None:
    beta = _records_scalar('beta', float)
elif m_fn:
    beta = float(m_fn.group(2))
elif m_dir:
    beta = float(m_dir.group(2))
else:
    beta = float('nan')

# seed
seed = args.seed
if seed is None:
    seed = _records_scalar('seed', int)

if seed is None:
    m2 = (re.search(r'_s(\d+)', fname) or
          re.search(r'_s(\d+)', src))
    seed = int(m2.group(1)) if m2 else None

if seed is None:
    try:
        for f in os.listdir(src):
            m_u = re.search(r'U_final_.*_s(\d+)\.npy$', f)
            if m_u:
                seed = int(m_u.group(1))
                break
    except OSError:
        pass

if seed is None:
    print('  WARNING: could not auto-detect seed from JSON, U_final, or path.')
    print('           Pass --seed N explicitly to label the dashboard correctly.')
    seed = 0

n_records = len(records['sweep'])
print(f"  N={N}  beta={beta}  seed={seed}  records={n_records}")

outdir = args.outdir if args.outdir is not None else src
os.makedirs(outdir, exist_ok=True)


# --- load hadron JSON (Option C: panel 6 paper-quality counts) ---------
# Look for <base>_hadrons.json from measure_hadrons_from_U.py in the same
# directory as records.json. This provides greedy-matched hadron counts
# that replace the inflated combinatorial counts from records.json.
hadron_data = None
hadron_src_fname = None

if args.hadron_json == '':
    # User explicitly disabled hadron JSON lookup
    print("  Hadron JSON lookup DISABLED via --hadron_json \"\"")
elif args.hadron_json is not None:
    # User specified an explicit path
    if os.path.isfile(args.hadron_json):
        try:
            with open(args.hadron_json) as f:
                hadron_data = json.load(f)
            hadron_src_fname = os.path.basename(args.hadron_json)
            print(f"  Loaded hadron census: {args.hadron_json}")
        except (json.JSONDecodeError, OSError) as e:
            print(f"  WARNING: could not load --hadron_json {args.hadron_json}: {e}")
    else:
        print(f"  WARNING: --hadron_json file not found: {args.hadron_json}")
else:
    # Auto-detect: look for any *_hadrons.json in records.json's directory
    try:
        for fn in sorted(os.listdir(src)):
            if fn.endswith('_hadrons.json'):
                try:
                    with open(os.path.join(src, fn)) as f:
                        hadron_data = json.load(f)
                    hadron_src_fname = fn
                    print(f"  Loaded hadron census: {fn}  "
                          f"(greedy matching, v58 m* formula)")
                    break
                except (json.JSONDecodeError, OSError):
                    continue
    except OSError:
        pass


# --- apply equilibrium cut if requested ---------------------------------
if args.cut_eq > 0:
    sw_arr = np.array(records['sweep'])
    keep   = sw_arr >= args.cut_eq
    if keep.sum() < 2:
        sys.exit(f"ERROR: --cut_eq {args.cut_eq} leaves <2 records; aborting")
    for k in records:
        if isinstance(records[k], list) and len(records[k]) == n_records:
            records[k] = [v for v, ok in zip(records[k], keep) if ok]
    n_records = len(records['sweep'])
    print(f"  After --cut_eq {args.cut_eq}: {n_records} records remain")


# --- style -------------------------------------------------------------
WHITE = not args.dark
if WHITE:
    BG, PAN, TC = 'white', '#f5f5f5', 'black'
    EDGE = '#888888'
    CYAN, RED, BLUE = '#0077bb', '#cc2222', '#2255aa'
    GOLD, GRN, ORG  = '#bb8800', '#118855', '#cc6611'
    plt.style.use('default')
    plt.rcParams.update({
        'axes.facecolor': PAN,
        'figure.facecolor': BG,
        'axes.edgecolor': EDGE,
        'text.color': TC,
        'axes.labelcolor': TC,
        'xtick.color': TC,
        'ytick.color': TC,
        'grid.color': '#cccccc',
    })
else:
    BG, PAN, TC = '#0a0a0a', '#0d0d15', 'white'
    EDGE = '#00ffff'
    CYAN, RED, BLUE = '#00ffff', '#ff3366', '#3399ff'
    GOLD, GRN, ORG  = '#ffcc00', '#33ff99', '#ff9933'
    plt.style.use('dark_background')
    plt.rcParams.update({
        'axes.edgecolor': EDGE,
        'xtick.color': 'white',
        'ytick.color': 'white',
        'text.color': 'white',
        'axes.labelcolor': 'white',
    })

plt.rcParams.update({
    'figure.dpi': 150,
    'savefig.dpi': args.dpi,
})


# --- helpers -----------------------------------------------------------
def style(ax, title):
    ax.set_facecolor(PAN)
    ax.set_title(title, fontsize=10, fontweight='bold', color=TC, pad=5)
    ax.tick_params(colors=TC)
    ax.grid(True, alpha=0.15, linestyle='--',
            color='grey' if WHITE else 'white')
    for sp in ax.spines.values():
        sp.set_color(EDGE)
        sp.set_linewidth(1.5 if not WHITE else 0.8)


def has(key):
    """Return True if records contains a non-empty list for this key."""
    v = records.get(key)
    return isinstance(v, list) and len(v) > 0


def annotate_empty(ax, message='(not measured in this run)'):
    """Annotate an empty panel cleanly when its data is missing."""
    ax.text(0.5, 0.5, message, transform=ax.transAxes,
            ha='center', va='center', fontsize=11, color=TC, alpha=0.5,
            style='italic')


# --- build figure ------------------------------------------------------
sw = np.array(records['sweep'])
fig, axes = plt.subplots(3, 3, figsize=(20, 15))
fig.patch.set_facecolor(BG)

cut_label = f' (sweeps >= {args.cut_eq})' if args.cut_eq > 0 else ''
fig.suptitle(
    f'CTC SU(3)  beta = {beta} -- N = {N}, seed = {seed}{cut_label}',
    fontsize=14, fontweight='bold', color=TC, y=0.99)


# Panel (1): Plaquette
ax = axes[0, 0]
style(ax, '(1) Plaquette <P>')
if has('plaquette'):
    ax.plot(sw, records['plaquette'], 'o-', color=BLUE, lw=2, ms=3)
else:
    annotate_empty(ax)
ax.set_xlabel('Sweep', color=TC)


# Panel (2): Vortex %
# y-axis locked to the full physical range [0, 105] so that small
# fluctuations near 100% are not visually amplified by auto-scaling.
# A drop from 100% to 88% looks dramatic on a [88, 100] range but is
# a small physical variation on the natural [0, 100] scale.
ax = axes[0, 1]
style(ax, '(2) Vortex %')
if has('vortex_pct'):
    ax.plot(sw, records['vortex_pct'], 'o-', color=RED, lw=2, ms=3)
else:
    annotate_empty(ax)
ax.set_xlabel('Sweep', color=TC)
ax.set_ylim(0, 105)


# Panel (3): Acceptance
ax = axes[0, 2]
style(ax, '(3) Acceptance')
if has('acceptance'):
    ax.plot(sw, records['acceptance'], 'o-', color=GRN, lw=2, ms=3)
    ax.axhline(0.5, color=GOLD, lw=1.5, linestyle='--', label='Target')
    ax.legend(fontsize=7, facecolor=PAN, edgecolor=EDGE, labelcolor=TC)
else:
    annotate_empty(ax)
ax.set_xlabel('Sweep', color=TC)


# Panel (4): Z3 R/G/B color counts
ax = axes[1, 0]
style(ax, '(4) Z3 Distribution: R / G / B')
if has('n_R') and has('n_G') and has('n_B'):
    ax.plot(sw, records['n_R'], 'o-', color='#ff3333', lw=2, ms=3, label='R')
    ax.plot(sw, records['n_G'], 's-', color='#33aa33', lw=2, ms=3, label='G')
    ax.plot(sw, records['n_B'], '^-', color='#3333aa', lw=2, ms=3, label='B')
    ax.legend(fontsize=8, facecolor=PAN, edgecolor=EDGE, labelcolor=TC)
else:
    annotate_empty(ax)
ax.set_xlabel('Sweep', color=TC)


# Panel (5): Z3 Balance
ax = axes[1, 1]
style(ax, '(5) Z3 Balance (min/max RGB)')
if has('z3_balance'):
    ax.plot(sw, records['z3_balance'], 'o-', color=GOLD, lw=2, ms=3)
    ax.axhline(0.5, color=GOLD, lw=1.5, linestyle='--', alpha=0.4,
               label='Moderate')
    ax.legend(fontsize=7, facecolor=PAN, edgecolor=EDGE, labelcolor=TC)
else:
    annotate_empty(ax)
ax.set_xlabel('Sweep', color=TC)
ax.set_ylim(0, 1.05)


# Panel (6): Hadron Census (OPTION C upgrade)
#
# Three modes:
#   A. measure_hadrons JSON available  -> bar chart with paper-quality counts
#   B. records.json hadron data only    -> time series with clearer labels +
#                                          caveat that these are combinatorial
#   C. neither available                -> annotated "not measured"
ax = axes[1, 2]

if hadron_data is not None:
    # Mode A: Paper-quality hadron census from measure_hadrons_from_U.py
    n_m = int(hadron_data.get('n_mesons',  0))
    n_b = int(hadron_data.get('n_baryons', 0))
    n_p = int(hadron_data.get('n_planar',  0))
    labels = ['Mesons', 'Baryons', 'Planar\nbaryons']
    counts = [n_m, n_b, n_p]
    colors = [BLUE, GOLD, GRN]
    bars = ax.bar(labels, counts, color=colors, edgecolor=EDGE,
                  linewidth=1.2, alpha=0.85)
    # Annotate each bar with its value
    y_max = max(counts) if max(counts) > 0 else 1
    for bar, count in zip(bars, counts):
        ax.text(bar.get_x() + bar.get_width() / 2,
                bar.get_height() + 0.02 * y_max,
                f'{count}', ha='center', va='bottom',
                fontsize=11, fontweight='bold', color=TC)
    ax.set_ylabel('Count at U_final', color=TC)
    ax.set_ylim(0, y_max * 1.18)

    # Source caption
    ax.text(0.98, 0.97,
            f'Source: measure_hadrons_from_U.py\n'
            f'(greedy matching, v58 m* formula)\n'
            f'File: {hadron_src_fname[:36]}',
            transform=ax.transAxes, fontsize=7, va='top', ha='right',
            color=TC, alpha=0.75,
            bbox=dict(boxstyle='round,pad=0.3',
                      facecolor=PAN, edgecolor=EDGE, alpha=0.7))

    ax.set_title('(6) Hadron Census at U_final  (matched pairs)',
                 fontsize=10, fontweight='bold', color=TC, pad=5)
    ax.set_facecolor(PAN)
    ax.tick_params(colors=TC)
    ax.grid(True, alpha=0.15, linestyle='--',
            color='grey' if WHITE else 'white', axis='y')
    for sp in ax.spines.values():
        sp.set_color(EDGE)
        sp.set_linewidth(1.5 if not WHITE else 0.8)

elif has('n_mesons') or has('n_baryons') or has('n_planar'):
    # Mode B: Fall back to records.json combinatorial counts with clearer labels
    style(ax, '(6) Z3 sector co-locations (combinatorial)')
    if has('n_mesons'):
        ax.plot(sw, records['n_mesons'], 'o-', color=BLUE, lw=2, ms=3,
                label='Z3 neutral pair sites')
    if has('n_baryons'):
        ax.plot(sw, records['n_baryons'], 's-', color=GOLD, lw=2, ms=3,
                label='RGB triplet sites')
    if has('n_planar'):
        ax.plot(sw, records['n_planar'], '^-', color=GRN, lw=2, ms=3,
                label='Coplanar triplets')
    ax.legend(fontsize=8, facecolor=PAN, edgecolor=EDGE, labelcolor=TC,
              loc='upper left')

    # Caveat about combinatorial nature
    ax.text(0.98, 0.97,
            'Combinatorial counts.\n'
            'See measure_hadrons_from_U.py for\n'
            'paper-quality matched-pair census.',
            transform=ax.transAxes, fontsize=7, va='top', ha='right',
            color=TC, alpha=0.7,
            bbox=dict(boxstyle='round,pad=0.3',
                      facecolor=PAN, edgecolor=EDGE, alpha=0.7))
    ax.set_xlabel('Sweep', color=TC)

else:
    # Mode C: Nothing available
    style(ax, '(6) Hadron Formation')
    annotate_empty(ax,
                   '(not measured -- try dashboard_lite_from_json.py\n'
                   'for augmented-action runs)')
    ax.set_xlabel('Sweep', color=TC)


# Panel (7): Mass Gap Delta
ax = axes[2, 0]
style(ax, '(7) Mass Gap Delta')
if has('mass_gap'):
    Δ_arr = np.array(records['mass_gap'])
    err_arr = (np.array(records['mass_gap_err']) if has('mass_gap_err')
               else np.zeros_like(Δ_arr))
    ax.errorbar(sw, Δ_arr, yerr=err_arr, fmt='o-', color=CYAN, lw=2, ms=3,
                ecolor=CYAN, elinewidth=0.8, capsize=2, alpha=0.85)
    if len(Δ_arr) >= 4:
        eq_cut = len(Δ_arr) // 2
        Δ_eq = float(np.mean(Δ_arr[eq_cut:]))
        Δ_eq_std = float(np.std(Δ_arr[eq_cut:], ddof=1))
        ax.axhline(Δ_eq, color=GOLD, lw=1.5, linestyle='--',
                   label=f'Delta_eq = {Δ_eq:.4f} +/- {Δ_eq_std:.4f}')
        ax.legend(fontsize=7, facecolor=PAN, edgecolor=EDGE, labelcolor=TC)
else:
    annotate_empty(ax)
ax.set_xlabel('Sweep', color=TC)


# Panel (8): Delta vs eddy core count (twin-axis decoupling proof)
ax = axes[2, 1]
style(ax, '(8) Delta vs Eddy Core Count')
if has('mass_gap') and has('n_cores'):
    ax2 = ax.twinx()
    ax.plot(sw,  records['mass_gap'], 'o-', color=RED, lw=2.5, ms=4,
            label='Delta')
    ax2.plot(sw, records['n_cores'],  's--', color=GOLD, lw=2, ms=3,
             label='Cores')
    ax.set_ylabel('Delta', color=RED)
    ax2.set_ylabel('Cores', color=GOLD)
    ax.tick_params(axis='y', labelcolor=RED)
    ax2.tick_params(axis='y', labelcolor=GOLD)
    l1, lb1 = ax.get_legend_handles_labels()
    l2, lb2 = ax2.get_legend_handles_labels()
    ax.legend(l1 + l2, lb1 + lb2, fontsize=8,
              facecolor=PAN, edgecolor=EDGE, labelcolor=TC)
else:
    annotate_empty(ax)
ax.set_xlabel('Sweep', color=TC)


# Panel (9): Mass Ratio
ax = axes[2, 2]
style(ax, '(9) Mass Ratio (eddy / background)')
if has('mass_ratio'):
    ax.plot(sw, records['mass_ratio'], 'o-', color=ORG, lw=2, ms=3)
    ax.axhline(1.0, color=GOLD, lw=1.5, linestyle='--', label='No enh.')
    ax.legend(fontsize=7, facecolor=PAN, edgecolor=EDGE, labelcolor=TC)
else:
    annotate_empty(ax)
ax.set_xlabel('Sweep', color=TC)


plt.tight_layout()


# --- save --------------------------------------------------------------
cut_suffix = f'_eq{args.cut_eq}' if args.cut_eq > 0 else ''
out_png = os.path.join(
    outdir,
    f'dashboard_N{N}_b{beta:.1f}_s{seed}{cut_suffix}.png')
plt.savefig(out_png, dpi=args.dpi, bbox_inches='tight', facecolor=BG)
plt.close()
print(f"\nSaved: {out_png}  ({os.path.getsize(out_png) // 1024} KB)")

# Final summary
if hadron_data is not None:
    n_m = hadron_data.get('n_mesons', 0)
    n_b = hadron_data.get('n_baryons', 0)
    n_p = hadron_data.get('n_planar', 0)
    print(f"  Panel 6 source: measure_hadrons (matched)  "
          f"mesons={n_m}, baryons={n_b}, planar={n_p}")
else:
    print("  Panel 6 source: records.json (combinatorial; relabeled)")

print('Done.')
