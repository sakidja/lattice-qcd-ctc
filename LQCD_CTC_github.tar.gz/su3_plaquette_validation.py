#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
su3_plaquette_validation.py

SU(3) Wilson Monte Carlo. Thermalizes a periodic lattice at the
requested beta, then measures the equilibrium mean plaquette across
a set of decorrelated configurations and compares to the established
Wilson benchmark.
"""

from __future__ import annotations
import numpy as np
from dataclasses import dataclass, field
from itertools import product
import argparse
import time

np.set_printoptions(precision=5, suppress=True)

I3 = np.eye(3, dtype=np.complex128)


# ----------------------------------------------------------------------
# SU(3) utilities
# ----------------------------------------------------------------------

def expm_iH(H: np.ndarray) -> np.ndarray:
    w, V = np.linalg.eigh(H)
    return (V * np.exp(1j * w)) @ V.conj().T


def rand_su3(eps: float, rng: np.random.Generator) -> np.ndarray:
    H = rng.normal(size=(3, 3)) + 1j * rng.normal(size=(3, 3))
    H = (H + H.conj().T) / 2.0
    H -= (np.trace(H) / 3.0) * I3
    return expm_iH(eps * H)


# ----------------------------------------------------------------------
# Lattice
# ----------------------------------------------------------------------

@dataclass
class Lattice:
    L: int
    T: int
    beta: float
    seed: int = 42
    U: np.ndarray = field(init=False)

    def __post_init__(self):
        self.rng = np.random.default_rng(self.seed)
        shp = (self.L, self.L, self.L, self.T, 4, 3, 3)
        self.U = np.zeros(shp, dtype=np.complex128)
        self.U[..., :, :] = I3
        self.dirs = [(1, 0, 0, 0), (0, 1, 0, 0),
                     (0, 0, 1, 0), (0, 0, 0, 1)]

    def shift(self, site, mu, sign=+1):
        d = self.dirs[mu]
        n = (self.L, self.L, self.L, self.T)
        return tuple((site[i] + sign * d[i]) % n[i] for i in range(4))

    def link(self, site, mu):
        return self.U[site[0], site[1], site[2], site[3], mu]

    def set_link(self, site, mu, M):
        self.U[site[0], site[1], site[2], site[3], mu] = M

    def plaquette(self, site, mu, nu):
        s = site
        s_mu = self.shift(s, mu)
        s_nu = self.shift(s, nu)
        U1 = self.link(s, mu)
        U2 = self.link(s_mu, nu)
        U3 = self.link(s_nu, mu).conj().T
        U4 = self.link(s, nu).conj().T
        return U1 @ U2 @ U3 @ U4


# ----------------------------------------------------------------------
# Action and Metropolis
# ----------------------------------------------------------------------

def staple(lat: Lattice, site, mu):
    A = np.zeros((3, 3), dtype=np.complex128)
    for nu in range(4):
        if nu == mu:
            continue
        s = site
        s_mu = lat.shift(s, mu)
        s_nu = lat.shift(s, nu)
        s_mu_mnu = lat.shift(s_mu, nu, -1)
        s_mnu = lat.shift(s, nu, -1)
        A += lat.link(s_mu, nu) @ lat.link(s_nu, mu).conj().T \
            @ lat.link(s, nu).conj().T
        A += lat.link(s_mu_mnu, nu).conj().T \
            @ lat.link(s_mnu, mu).conj().T @ lat.link(s_mnu, nu)
    return A


def local_dS(lat: Lattice, site, mu, Uold, Unew):
    St = staple(lat, site, mu)
    return (lat.beta / 3.0) * np.real(np.trace((Unew - Uold) @ St))


def metropolis_sweep(lat: Lattice, eps: float, n_hit: int = 2):
    acc = 0
    tot = 0
    for site in product(range(lat.L), range(lat.L),
                        range(lat.L), range(lat.T)):
        for mu in range(4):
            Uold = lat.link(site, mu).copy()
            for _ in range(n_hit):
                R = rand_su3(eps, lat.rng)
                Unew = R @ Uold
                dS = local_dS(lat, site, mu, Uold, Unew)
                if dS >= 0 or lat.rng.random() < np.exp(dS):
                    Uold = Unew
                    acc += 1
                tot += 1
            lat.set_link(site, mu, Uold)
    return acc / max(tot, 1)


# ----------------------------------------------------------------------
# Measurements (all derived from the same plaquette / link traversal)
# ----------------------------------------------------------------------

def measure(lat: Lattice):
    """Return a dict with:
       plaq           : <P>, full average over all six planes
       plaq_ss        : <P_spatial-spatial>, planes (1,2),(1,3),(2,3)
       plaq_st        : <P_temporal-spatial>, planes (0,1),(0,2),(0,3)
       plaq_per_site  : flat array of per-site (Re Tr P)/3 across all
                        sites and planes (for distribution histogram)
       polyakov_abs   : <|L|>, magnitude of the Polyakov loop averaged
                        over spatial sites
    """
    s_all = 0.0; n_all = 0
    s_ss = 0.0;  n_ss = 0
    s_st = 0.0;  n_st = 0
    per_site_vals = []

    for site in product(range(lat.L), range(lat.L),
                        range(lat.L), range(lat.T)):
        for mu in range(4):
            for nu in range(mu + 1, 4):
                v = np.real(np.trace(lat.plaquette(site, mu, nu))) / 3.0
                s_all += v; n_all += 1
                per_site_vals.append(v)
                if mu == 0 or nu == 0:        # temporal-spatial
                    s_st += v; n_st += 1
                else:                          # spatial-spatial
                    s_ss += v; n_ss += 1

    # Polyakov loop L(x) = product over t of U_t(x,t); average |Tr L| / 3
    L_sum = 0.0
    L_cnt = 0
    for x, y, z in product(range(lat.L), range(lat.L), range(lat.L)):
        M = I3.copy()
        for t in range(lat.T):
            M = M @ lat.U[x, y, z, t, 3]
        L_sum += abs(np.trace(M)) / 3.0
        L_cnt += 1

    return {
        'plaq': s_all / n_all,
        'plaq_ss': s_ss / n_ss,
        'plaq_st': s_st / n_st,
        'plaq_per_site': np.array(per_site_vals),
        'polyakov_abs': L_sum / L_cnt,
    }


def mean_plaquette(lat: Lattice):
    """Convenience wrapper kept for compatibility; returns scalar <P>."""
    return measure(lat)['plaq']


# ----------------------------------------------------------------------
# Driver
# ----------------------------------------------------------------------

@dataclass
class RunConfig:
    L: int = 6
    T: int = 8
    beta: float = 6.0
    seed: int = 42
    n_therm: int = 2000
    n_sep: int = 20
    n_conf: int = 8
    eps: float = 0.20


PLAQ_BENCH = {5.7: 0.549, 5.8: 0.567, 6.0: 0.594, 6.2: 0.614}


def run(rc: RunConfig, verbose=True):
    lat = Lattice(rc.L, rc.T, rc.beta, seed=rc.seed)
    t0 = time.time()
    if verbose:
        print(f"  thermalizing {rc.n_therm} sweeps ...", flush=True)
    for s in range(rc.n_therm):
        rate = metropolis_sweep(lat, rc.eps)
        if verbose and (s + 1) % 10 == 0:
            elapsed = time.time() - t0
            print(f"    therm sweep {s+1}/{rc.n_therm}   "
                  f"acc={rate:.3f}   elapsed={elapsed:.1f}s",
                  flush=True)
    if verbose:
        print(f"  thermalized {rc.n_therm} sweeps in "
              f"{time.time()-t0:.1f}s", flush=True)

    plaqs = []
    plaqs_ss = []
    plaqs_st = []
    polyakov = []
    per_site_all = []          # accumulated for the distribution figure

    t_m0 = time.time()
    for c in range(rc.n_conf):
        for s in range(rc.n_sep):
            rate = metropolis_sweep(lat, rc.eps)
            if verbose and (s + 1) % 5 == 0:
                print(f"    config {c+1}/{rc.n_conf}   "
                      f"decorr sweep {s+1}/{rc.n_sep}   "
                      f"acc={rate:.3f}", flush=True)
        m = measure(lat)
        plaqs.append(m['plaq'])
        plaqs_ss.append(m['plaq_ss'])
        plaqs_st.append(m['plaq_st'])
        polyakov.append(m['polyakov_abs'])
        per_site_all.append(m['plaq_per_site'])
        if verbose:
            elapsed = time.time() - t_m0
            print(f"  config {c+1}/{rc.n_conf}  "
                  f"<P>={m['plaq']:.4f}  "
                  f"<P_ss>={m['plaq_ss']:.4f}  "
                  f"<P_st>={m['plaq_st']:.4f}  "
                  f"<|L|>={m['polyakov_abs']:.4f}   "
                  f"(elapsed = {elapsed/60:.1f} min)",
                  flush=True)

    return {
        'plaqs':         np.array(plaqs),
        'plaqs_ss':      np.array(plaqs_ss),
        'plaqs_st':      np.array(plaqs_st),
        'polyakov':      np.array(polyakov),
        'per_site_all':  np.concatenate(per_site_all),
    }


def report(rc: RunConfig, results: dict):
    plaqs = results['plaqs']
    plaqs_ss = results['plaqs_ss']
    plaqs_st = results['plaqs_st']
    polyakov = results['polyakov']

    print("=" * 70)
    print(f"SU(3) Wilson measurements  (beta = {rc.beta})")
    print("=" * 70)

    def stats(a):
        m = float(a.mean())
        s = float(a.std()) if len(a) > 1 else 0.0
        return m, s

    pm,  pe  = stats(plaqs)
    pms, pes = stats(plaqs_ss)
    pmt, pet = stats(plaqs_st)
    lm,  le  = stats(polyakov)
    pb = PLAQ_BENCH.get(rc.beta, float('nan'))

    print(f"  <P>      = {pm:.4f} +/- {pe:.4f}    "
          f"benchmark = {pb:.3f}   delta = {pm - pb:+.4f}")
    print(f"  <P_ss>   = {pms:.4f} +/- {pes:.4f}    "
          f"(spatial-spatial planes)")
    print(f"  <P_st>   = {pmt:.4f} +/- {pet:.4f}    "
          f"(temporal-spatial planes)")
    print(f"  <P_ss> - <P_st> = {pms - pmt:+.4f}   "
          f"(symmetry check; expected ~0)")
    print(f"  <|L|>    = {lm:.4f} +/- {le:.4f}    "
          f"(Polyakov loop magnitude)")

    from plaquette_figure_addon import write_plaquette_figure
    write_plaquette_figure(rc, results,
                           out_png=f'plaq_b{rc.beta}.png',
                           out_csv=f'plaq_b{rc.beta}.csv')


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--beta", type=float, default=6.0)
    ap.add_argument("--L", type=int, default=6)
    ap.add_argument("--T", type=int, default=8)
    ap.add_argument("--nconf", type=int, default=8)
    args = ap.parse_args()

    rc = RunConfig(L=args.L, T=args.T, beta=args.beta, n_conf=args.nconf)
    results = run(rc)
    report(rc, results)


if __name__ == "__main__":
    main()
