#!/usr/bin/env python3
"""
ctc_z3_rgb_movie.py
====================

Movie of the ℤ₃ R/G/B sector field across a continuation run.

Companion to ctc_meson_baryon_movie.py. Where that script visualises
the |Im Tr P_{0i}| flux field and identifies meson tubes and baryon
junctions, this script visualises the ℤ₃ Polyakov-loop sector field
that underlies the R/G/B framework: at every spatial column, the
Polyakov loop trace phase places that column in one of three sectors,
labelled R (sector 0), G (sector 1), or B (sector 2).

Render modes
------------
  --render volume   (default)
        Every spatial voxel rendered as a translucent cube coloured by
        its ℤ₃ sector. The three sub-lattices show as overlapping
        clouds; their relative weights and spatial distribution are
        the "RGB composition" of the configuration.

  --render walls
        Soap-bubble rendering of the domain-wall network. Only those
        faces between adjacent voxels whose ℤ₃ sectors differ are
        drawn, coloured by the pair: R-G → yellow, G-B → cyan,
        R-B → magenta. The bulk is left empty. This is the cleanest
        view of confinement-phase mixing vs. deconfined macroscopic
        domains.

  --isolate R | G | B
        Render only the chosen sub-lattice. Useful for showing what
        "all the R sites" or "all the G sites" look like spatially.
        Combines with --render volume.

Per-frame diagnostics tracked
-----------------------------
  n_R, n_G, n_B               sector populations
  fR, fG, fB                  fractions (sum to 1)
  balance = min / max         population balance (1 = perfect ℤ₃ isotropy)
  dominant_sector             argmax of (n_R, n_G, n_B)
  n_walls                     voxels with at least one heterogeneous neighbour
  wall_area_lu2               number of heterogeneous faces (lattice units²)
  polyakov_phase_R,G,B        mean Polyakov trace phase in each sub-lattice

Run mode
--------
Continuation run from a pre-thermalized U_final.npy. Monte Carlo
update is pure Wilson Metropolis. The ℤ₃ classifier is the
Polyakov-loop trace phase, identical to the one used in
ctc_meson_baryon_movie.py and the production scripts, so any cross-
referencing between the two movies refers to the same sector field.

Outputs
-------
  S5_z3_rgb_<TAG>.gif
  S5_z3_rgb_<TAG>_history.json

Usage
-----
    python3 ctc_z3_rgb_movie.py /path/to/U_final_*.npy
    python3 ctc_z3_rgb_movie.py U_final_*.npy --render walls
    python3 ctc_z3_rgb_movie.py U_final_*.npy --isolate R --render volume
"""

import argparse, os, re, sys, time, json, warnings
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D                  # noqa: F401
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
import imageio
warnings.filterwarnings('ignore')


# ─── CLI ──────────────────────────────────────────────────────────────────
ap = argparse.ArgumentParser(
    description='Movie of the ℤ₃ R/G/B sector field for a CTC run.')
ap.add_argument('u_file',          help='Path to U_final_*.npy')
ap.add_argument('--movie_sweeps',  type=int,   default=400)
ap.add_argument('--save_every',    type=int,   default=2)
ap.add_argument('--fps',           type=int,   default=12)
ap.add_argument('--elev',          type=float, default=25.0)
ap.add_argument('--rotations',     type=float, default=1.0)

ap.add_argument('--render',        choices=['volume', 'walls', 'slices', 'panels'],
                default='panels',
                help='Render mode: panels = R, G, B in three side-by-side 3D '
                     'panels (default, no occlusion); '
                     'volume = colour every voxel by sector (legacy, R/G/B '
                     'overlap and occlude); '
                     'walls = render only heterogeneous-pair faces; '
                     'slices = three orthogonal 2D cross-sections through '
                     'the lattice centre (cleanest view of bulk domains)')
ap.add_argument('--glyph',         choices=['cubes', 'points'], default='cubes',
                help='Volume glyph style: shrunken cubes (default) or scatter points')
ap.add_argument('--glyph_size',    type=float, default=None,
                help='Glyph size. For cubes: fraction of cell (default 0.5). '
                     'For points: matplotlib scatter s= (default 60)')
ap.add_argument('--volume_alpha',  type=float, default=0.15,
                help='Per-cube alpha for --render volume (default 0.15)')
ap.add_argument('--isolate',       choices=['R', 'G', 'B'], default=None,
                help='Render only one sub-lattice (volume mode only)')

ap.add_argument('--N',             type=int,   default=None)
ap.add_argument('--beta',          type=float, default=None)
ap.add_argument('--alpha',         type=float, default=None)
ap.add_argument('--seed',          type=int,   default=None)
ap.add_argument('--rng_seed',      type=int,   default=None)
ap.add_argument('--outdir',        type=str,   default='.')
args = ap.parse_args()

if not os.path.isfile(args.u_file):
    sys.exit(f'ERROR: not found: {args.u_file}')

print(f'Loading {args.u_file} ...')
U = np.load(args.u_file)

m_meta = re.search(r'N(\d+)_b([\d.]+)_(?:a([\d.]+)_)?s(\d+)',
                   os.path.basename(args.u_file))
if m_meta:
    N     = args.N     if args.N     is not None else int(m_meta.group(1))
    beta  = args.beta  if args.beta  is not None else float(m_meta.group(2))
    alpha = (args.alpha if args.alpha is not None
             else (float(m_meta.group(3)) if m_meta.group(3) else None))
    seed  = args.seed  if args.seed  is not None else int(m_meta.group(4))
else:
    N     = args.N     if args.N     is not None else U.shape[1]
    beta  = args.beta  if args.beta  is not None else 5.0
    alpha = args.alpha
    seed  = args.seed  if args.seed  is not None else 0

rng_seed = args.rng_seed if args.rng_seed is not None else (1000 + seed)
np.random.seed(rng_seed)

print(f'  U.shape={U.shape}  N={N}  dtype={U.dtype}')
if alpha is not None:
    print(f'  beta={beta}  alpha={alpha}  seed={seed}  RNG seed={rng_seed}')
    TAG = f'N{N}_b{beta:.1f}_a{alpha:.2f}_s{seed}'
else:
    print(f'  beta={beta}  seed={seed}  RNG seed={rng_seed}')
    TAG = f'N{N}_b{beta:.1f}_s{seed}'
print(f'  render = {args.render}'
      + (f', isolate = {args.isolate}' if args.isolate else ''))
os.makedirs(args.outdir, exist_ok=True)


# ─── SU(3) primitives (verbatim from the unified movie script) ────────────
PLANES = [(0, 1), (0, 2), (0, 3), (1, 2), (1, 3), (2, 3)]


def random_su3_batch(shape):
    size = int(np.prod(shape))
    A = np.random.randn(size, 3, 3) + 1j * np.random.randn(size, 3, 3)
    Q, _ = np.linalg.qr(A)
    d = np.linalg.det(Q)
    return (Q / (d[:, None, None] ** (1 / 3))).reshape(*shape, 3, 3)


def project_su3_batch(M):
    sh = M.shape; sz = int(np.prod(sh[:-2]))
    M2 = M.reshape(sz, 3, 3)
    Uu, _, Vh = np.linalg.svd(M2)
    Q = Uu @ Vh
    d = np.linalg.det(Q)
    return (Q / (d[:, None, None] ** (1 / 3))).reshape(sh)


def plaq(U, mu, nu):
    P = U[mu] @ np.roll(U[nu], -1, axis=mu)
    P = P @ np.roll(U[mu], -1, axis=nu).conj().swapaxes(-1, -2)
    return P @ U[nu].conj().swapaxes(-1, -2)


def staple(U, mu):
    S = np.zeros((N, N, N, N, 3, 3), dtype=complex)
    for nu in range(4):
        if nu == mu: continue
        fwd = (U[nu] @ np.roll(U[mu], -1, axis=nu)
               @ np.roll(U[nu], -1, axis=mu).conj().swapaxes(-1, -2))
        Ub = np.roll(U[nu], 1, axis=nu)
        bwd = (Ub.conj().swapaxes(-1, -2)
               @ np.roll(U[mu], 1, axis=nu)
               @ np.roll(Ub, -1, axis=mu))
        S += fwd + bwd
    return S


_x, _y, _z, _t = np.meshgrid(*[np.arange(N)] * 4, indexing='ij')
PAR = (_x + _y + _z + _t) % 2


def metropolis_sweep(U, beta, delta):
    accepted = total = 0
    for mu in range(4):
        S = staple(U, mu)
        for p in [0, 1]:
            mask = (PAR == p); idx = np.where(mask)
            old = U[mu][idx].copy()
            new = project_su3_batch(
                old + delta * (random_su3_batch((len(idx[0]),)) - old))
            dS = beta * (np.real(np.trace(new @ S[idx], axis1=-2, axis2=-1))
                         - np.real(np.trace(old @ S[idx], axis1=-2, axis2=-1)))
            acc = np.random.random(len(idx[0])) < np.exp(np.clip(dS, -100, 0))
            fa = np.zeros((N, N, N, N), dtype=bool); fa[idx] = acc
            U[mu][fa] = new[acc]
            accepted += int(acc.sum()); total += len(idx[0])
    rate = accepted / max(total, 1)
    if rate > 0.6:
        delta = min(delta * 1.05, 0.5)
    elif rate < 0.4:
        delta = max(delta * 0.95, 0.15)
    return U, rate, delta


def measure_plaq(U):
    s = 0.0; tot = 0
    for mu, nu in PLANES:
        trP = np.real(np.trace(plaq(U, mu, nu), axis1=-2, axis2=-1))
        s += np.sum(trP) / 3.0; tot += trP.size
    return s / tot


# ─── ℤ₃ Polyakov classifier (returns 3D sector field + 3D phase field) ──

def compute_z3_polyakov_with_phase(U):
    """Polyakov-loop trace phase at every spatial site.
    Returns (z3_3d, phase_3d) where z3_3d has values in {0, 1, 2} and
    phase_3d is the raw angle in [0, 2π).
    """
    L = U[0][:, :, :, 0, :, :].copy()
    for tau in range(1, N):
        L = np.matmul(L, U[0][:, :, :, tau, :, :])
    Tr_L = np.trace(L, axis1=-2, axis2=-1)
    angle = np.angle(Tr_L) % (2 * np.pi)
    z3 = np.round(angle * 3.0 / (2 * np.pi)).astype(int) % 3
    return z3, angle


# ─── Wall detection ──────────────────────────────────────────────────────

def domain_wall_voxels(z3_3d):
    """Boolean 3D mask: voxels where at least one of the 6 PBC neighbours
    has a different ℤ₃ sector."""
    is_wall = np.zeros_like(z3_3d, dtype=bool)
    for axis in (0, 1, 2):
        for shift in (-1, +1):
            nb = np.roll(z3_3d, shift, axis=axis)
            is_wall |= (nb != z3_3d)
    return is_wall


def heterogeneous_faces(z3_3d):
    """Per axis, count faces (between site x and x+ê_axis) where ℤ₃
    differs. Returns total and per-pair counts.
    """
    pair_counts = {(0, 1): 0, (1, 2): 0, (0, 2): 0}
    total = 0
    for axis in (0, 1, 2):
        nb = np.roll(z3_3d, -1, axis=axis)
        diff = (nb != z3_3d)
        total += int(diff.sum())
        for k1, k2 in [(0, 1), (1, 2), (0, 2)]:
            m = ((z3_3d == k1) & (nb == k2)) | ((z3_3d == k2) & (nb == k1))
            pair_counts[(k1, k2)] += int(m.sum())
    return total, pair_counts


# ─── Sector colours ──────────────────────────────────────────────────────

SECTOR_RGB = {
    0: (0.95, 0.15, 0.15),   # R
    1: (0.15, 0.85, 0.25),   # G
    2: (0.20, 0.35, 0.95),   # B
}
SECTOR_NAME = {0: 'R', 1: 'G', 2: 'B'}

PAIR_RGB = {
    (0, 1): (1.0, 0.95, 0.10),   # R-G  -> yellow
    (1, 2): (0.10, 0.95, 0.95),  # G-B  -> cyan
    (0, 2): (0.95, 0.20, 0.95),  # R-B  -> magenta
}


# ─── Rendering primitives ────────────────────────────────────────────────

def _cube_mesh_faces(coords, size=1.0):
    if len(coords) == 0:
        return []
    half = size / 2.0
    offsets = np.array([
        [-half, -half, -half], [+half, -half, -half],
        [+half, +half, -half], [-half, +half, -half],
        [-half, -half, +half], [+half, -half, +half],
        [+half, +half, +half], [-half, +half, +half],
    ])
    face_idx = [[0, 1, 2, 3], [4, 5, 6, 7], [0, 1, 5, 4],
                [2, 3, 7, 6], [1, 2, 6, 5], [0, 3, 7, 4]]
    out = []
    for c in coords:
        corners = c + offsets
        for fi in face_idx:
            out.append(corners[fi])
    return out


def add_cube_volume(ax, indicator_3d, color_rgb, alpha, size=1.05,
                    edgecolor=(0, 0, 0, 0.25), linewidth=0.2):
    coords = np.argwhere(indicator_3d)
    if len(coords) == 0:
        return
    faces = _cube_mesh_faces(coords, size=size)
    mesh = Poly3DCollection(faces, alpha=alpha)
    mesh.set_facecolor(list(color_rgb) + [alpha])
    mesh.set_edgecolor(edgecolor)
    mesh.set_linewidth(linewidth)
    ax.add_collection3d(mesh)


def draw_lattice_wireframe(ax, L, color=(0.65, 0.65, 0.75, 0.45),
                           linewidth=0.6):
    """Faint white wireframe of the cubic lattice bounding box, drawn
    behind the rendered content. Anchors 3D perception so floating
    shrunken cubes read as a 3D arrangement rather than a flat scatter.
    """
    # 12 edges of an axis-aligned cube from (-0.5, -0.5, -0.5)
    # to (L-0.5, L-0.5, L-0.5) so the box hugs the voxel centres.
    a, b = -0.5, L - 0.5
    corners = np.array([
        [a, a, a], [b, a, a], [b, b, a], [a, b, a],
        [a, a, b], [b, a, b], [b, b, b], [a, b, b],
    ])
    edges = [
        (0, 1), (1, 2), (2, 3), (3, 0),     # bottom face
        (4, 5), (5, 6), (6, 7), (7, 4),     # top face
        (0, 4), (1, 5), (2, 6), (3, 7),     # verticals
    ]
    for i, j in edges:
        xs = [corners[i, 0], corners[j, 0]]
        ys = [corners[i, 1], corners[j, 1]]
        zs = [corners[i, 2], corners[j, 2]]
        ax.plot(xs, ys, zs, color=color, linewidth=linewidth,
                zorder=0, alpha=color[3] if len(color) == 4 else 1.0)


# Pre-build the 6 unit-face offsets used by the walls renderer
_WALL_FACE_OFFSETS = {
    # axis along which the face is normal: (face center offset, corners)
    0: (np.array([+0.5, 0.0, 0.0]),
        np.array([[0.5, -0.5, -0.5], [0.5, +0.5, -0.5],
                  [0.5, +0.5, +0.5], [0.5, -0.5, +0.5]])),
    1: (np.array([0.0, +0.5, 0.0]),
        np.array([[-0.5, 0.5, -0.5], [+0.5, 0.5, -0.5],
                  [+0.5, 0.5, +0.5], [-0.5, 0.5, +0.5]])),
    2: (np.array([0.0, 0.0, +0.5]),
        np.array([[-0.5, -0.5, 0.5], [+0.5, -0.5, 0.5],
                  [+0.5, +0.5, 0.5], [-0.5, +0.5, 0.5]])),
}


def add_wall_faces(ax, z3_3d, alpha=0.55, linewidth=0.0):
    """Render only the faces between sites with different ℤ₃ sectors,
    coloured by pair. Periodic faces (axis wrap) are included."""
    faces_by_pair = {(0, 1): [], (1, 2): [], (0, 2): []}
    for axis, (centre_off, corners) in _WALL_FACE_OFFSETS.items():
        nb = np.roll(z3_3d, -1, axis=axis)
        diff_mask = (nb != z3_3d)
        diff_coords = np.argwhere(diff_mask)
        for x in diff_coords:
            k1 = int(z3_3d[x[0], x[1], x[2]])
            k2 = int(nb[x[0], x[1], x[2]])
            pair = tuple(sorted([k1, k2]))
            if pair not in faces_by_pair: continue
            face_quad = (x.astype(float) + 0.5) + corners
            faces_by_pair[pair].append(face_quad)
    for pair, quads in faces_by_pair.items():
        if not quads:
            continue
        mesh = Poly3DCollection(quads, alpha=alpha)
        mesh.set_facecolor(list(PAIR_RGB[pair]) + [alpha])
        mesh.set_edgecolor('none' if linewidth == 0
                           else (0, 0, 0, 0.4))
        mesh.set_linewidth(linewidth)
        ax.add_collection3d(mesh)


def fig_to_rgba(fig):
    fig.canvas.draw()
    img = np.asarray(fig.canvas.buffer_rgba())
    plt.close(fig)
    return img


from matplotlib.colors import ListedColormap


def render_slices_figure(z3_3d, sweep_num, plaq_val, stats_text):
    """Three orthogonal 2D slices through the lattice centre.

    Each slice is a 12x12 (or NxN) grid of coloured squares, one per
    lattice site. The R/G/B colour mapping matches the 3D modes.
    """
    cmap = ListedColormap([SECTOR_RGB[0], SECTOR_RGB[1], SECTOR_RGB[2]])
    mid = N // 2
    slice_xy = z3_3d[:, :, mid]            # constant z
    slice_xz = z3_3d[:, mid, :]            # constant y
    slice_yz = z3_3d[mid, :, :]            # constant x

    fig, axes = plt.subplots(1, 3, figsize=(13, 5.2), facecolor='black')
    fig.patch.set_facecolor('black')
    for ax, slc, label in [
        (axes[0], slice_xy, f'XY slice at z = {mid}'),
        (axes[1], slice_xz, f'XZ slice at y = {mid}'),
        (axes[2], slice_yz, f'YZ slice at x = {mid}'),
    ]:
        ax.imshow(slc.T, cmap=cmap, vmin=0, vmax=2, origin='lower',
                  interpolation='nearest')
        ax.set_title(label, color='white', fontsize=10)
        ax.set_xticks(range(0, N, max(1, N // 6)))
        ax.set_yticks(range(0, N, max(1, N // 6)))
        ax.tick_params(colors='white', labelsize=7)
        for sp in ax.spines.values():
            sp.set_color('#444444')

    title = (f'CTC SU(3) — \u2124\u2083 R/G/B sector field, slice view    '
             f'N={N}, \u03B2={beta}'
             + (f', \u03B1={alpha}' if alpha is not None else '') + '\n'
             f'Sweep {sweep_num}    \u27E8P\u27E9 = {plaq_val:.4f}    '
             + stats_text)
    fig.suptitle(title, color='white', fontsize=10, y=0.99)
    fig.tight_layout(rect=[0, 0, 1, 0.92])
    return fig_to_rgba(fig)


def render_panels_figure(z3_3d, sweep_num, plaq_val, az, elev,
                         glyph='cubes', glyph_size=None,
                         stats=None):
    """Three side-by-side 3D panels — R sector, G sector, B sector,
    each rendered alone in its own subplot with no occlusion between
    sectors. Each panel shows the same lattice viewed from the same
    angle; differences between panels show how each sub-lattice is
    spatially distributed.
    """
    SECTOR_LABEL = ['R', 'G', 'B']
    fig = plt.figure(figsize=(18, 7), facecolor='black')

    # Top title strip
    title = (f'CTC SU(3) — ℤ₃ R/G/B sector field    N={N}, β={beta}'
             + (f', α={alpha}' if alpha is not None else '') + '\n'
             + f'Three sub-lattices shown separately: each panel renders '
             + f'only its own sector, no occlusion.')
    fig.suptitle(title, color='white', fontsize=11, y=0.985)

    # Stats strip below the title — one line spanning all three panels
    if stats is not None:
        stats_line = (f'Sweep {sweep_num}    ⟨P⟩ = {plaq_val:.4f}    '
                      f'R = {stats["n_R"]} ({100*stats["fR"]:.1f}%)    '
                      f'G = {stats["n_G"]} ({100*stats["fG"]:.1f}%)    '
                      f'B = {stats["n_B"]} ({100*stats["fB"]:.1f}%)    '
                      f'Balance = {stats["balance"]:.3f}    '
                      f'Dominant = {stats["dominant"]}    '
                      f'Wall voxels = {stats["n_wall_voxels"]}    '
                      f'Heterogeneous faces = {stats["wall_face_total"]}    '
                      f'(R-G: {stats["wall_pair_RG"]}, '
                      f'G-B: {stats["wall_pair_GB"]}, '
                      f'R-B: {stats["wall_pair_RB"]})')
        fig.text(0.5, 0.92, stats_line, color='white', fontsize=9,
                 family='monospace', ha='center', va='top')

    cube_frac = glyph_size if glyph_size is not None else 0.5
    point_size = glyph_size if glyph_size is not None else 60.0

    for k, lab in enumerate(SECTOR_LABEL):
        ax = fig.add_subplot(1, 3, k + 1, projection='3d', facecolor='black')

        # Render this sector alone, opaque (no alpha needed: nothing to
        # blend against). Full sized cubes so domain structure is visible.
        if glyph == 'points':
            coords = np.argwhere(z3_3d == k)
            if len(coords):
                ax.scatter(coords[:, 0], coords[:, 1], coords[:, 2],
                           c=[SECTOR_RGB[k]], s=point_size,
                           depthshade=True, edgecolors='none')
        else:
            add_cube_volume(ax, z3_3d == k,
                            color_rgb=SECTOR_RGB[k],
                            alpha=1.0, size=cube_frac,
                            edgecolor=(0, 0, 0, 0.3),
                            linewidth=0.15)

        # Per-panel population label inside the axes — top-left of subplot
        if stats is not None:
            n_k = stats[f"n_{lab}"]
            f_k = stats[f"f{lab}"]
            ax.text2D(0.02, 0.95,
                      f'{lab} sector:  {n_k}  ({100*f_k:.1f}%)',
                      transform=ax.transAxes,
                      color=SECTOR_RGB[k], fontsize=12, fontweight='bold')

        ax.set_xlim(0, N); ax.set_ylim(0, N); ax.set_zlim(0, N)
        ax.set_xlabel('x', color='white', fontsize=7)
        ax.set_ylabel('y', color='white', fontsize=7)
        ax.set_zlabel('z', color='white', fontsize=7)
        ax.tick_params(colors='white', labelsize=6)
        for pane in (ax.xaxis.pane, ax.yaxis.pane, ax.zaxis.pane):
            pane.fill = False
            pane.set_edgecolor('#222222')
        draw_lattice_wireframe(ax, N)
        ax.view_init(elev=elev, azim=az)
        ax.set_title(f'{lab} sub-lattice', color=SECTOR_RGB[k],
                     fontsize=10, pad=4)

    fig.tight_layout(rect=[0.0, 0.0, 1.0, 0.90])
    return fig_to_rgba(fig)


def render_frame(z3_3d, phase_3d, sweep_num, plaq_val, az, elev,
                 render_mode, volume_alpha, isolate,
                 glyph='cubes', glyph_size=None):
    # Per-frame measurements (needed for both 2D and 3D modes)
    total_sites = int(z3_3d.size)
    n_R = int(np.sum(z3_3d == 0))
    n_G = int(np.sum(z3_3d == 1))
    n_B = int(np.sum(z3_3d == 2))
    fR, fG, fB = n_R / total_sites, n_G / total_sites, n_B / total_sites
    rgb = [n_R, n_G, n_B]
    bal = min(rgb) / max(rgb) if max(rgb) > 0 else 0.0
    dominant = SECTOR_NAME[int(np.argmax(rgb))]
    n_walls = int(domain_wall_voxels(z3_3d).sum())
    wall_total, wall_pairs = heterogeneous_faces(z3_3d)
    stats_dict = dict(
        n_R=n_R, n_G=n_G, n_B=n_B,
        fR=fR, fG=fG, fB=fB,
        balance=bal, dominant=dominant,
        n_wall_voxels=n_walls, wall_face_total=wall_total,
        wall_pair_RG=wall_pairs[(0, 1)],
        wall_pair_GB=wall_pairs[(1, 2)],
        wall_pair_RB=wall_pairs[(0, 2)],
    )

    # 2D slices mode: bypass 3D rendering entirely, return a 3-panel figure
    if render_mode == 'slices':
        stats_text = (f'R={n_R} ({100*fR:.1f}%)  '
                      f'G={n_G} ({100*fG:.1f}%)  '
                      f'B={n_B} ({100*fB:.1f}%)  '
                      f'balance={bal:.3f}  dominant={dominant}  '
                      f'walls={n_walls}')
        img = render_slices_figure(z3_3d, sweep_num, plaq_val, stats_text)
        return img, stats_dict

    # Panels mode: three separate 3D subplots, one per sector — no occlusion
    if render_mode == 'panels':
        img = render_panels_figure(z3_3d, sweep_num, plaq_val, az, elev,
                                   glyph=glyph, glyph_size=glyph_size,
                                   stats=stats_dict)
        return img, stats_dict

    fig = plt.figure(figsize=(12, 10), facecolor='black')
    ax = fig.add_subplot(111, projection='3d', facecolor='black')

    if render_mode == 'walls':
        add_wall_faces(ax, z3_3d, alpha=0.55)
    else:  # volume
        sectors_to_draw = ([{'R': 0, 'G': 1, 'B': 2}[isolate]]
                           if isolate else [0, 1, 2])
        if glyph == 'points':
            point_size = glyph_size if glyph_size is not None else 60.0
            for k in sectors_to_draw:
                coords = np.argwhere(z3_3d == k)
                if len(coords):
                    ax.scatter(coords[:, 0], coords[:, 1], coords[:, 2],
                               c=[SECTOR_RGB[k]], s=point_size,
                               depthshade=True, edgecolors='none')
        else:  # cubes — shrunken so neighbours don't touch, gaps reveal interior
            cube_frac = glyph_size if glyph_size is not None else 0.5
            for k in sectors_to_draw:
                add_cube_volume(ax, z3_3d == k,
                                color_rgb=SECTOR_RGB[k],
                                alpha=0.9, size=cube_frac,
                                edgecolor=(0, 0, 0, 0.4),
                                linewidth=0.25)

    # Per-frame measurement derivations for title-strip display
    f_wall_vox = n_walls / total_sites
    f_wall_face = wall_total / (3 * total_sites)   # 3 directions per site

    ax.text2D(0.02, 0.97,
              f'ℤ₃ Polyakov sector field    '
              f'Sweep {sweep_num}    ⟨P⟩ = {plaq_val:.4f}',
              transform=ax.transAxes, color='white', fontsize=9,
              bbox=dict(facecolor='black', alpha=0.5, pad=2))
    ax.text2D(0.02, 0.92,
              f'R = {n_R:5d}   ({100*fR:.1f}%)',
              transform=ax.transAxes, color=SECTOR_RGB[0], fontsize=10,
              fontweight='bold')
    ax.text2D(0.02, 0.88,
              f'G = {n_G:5d}   ({100*fG:.1f}%)',
              transform=ax.transAxes, color=SECTOR_RGB[1], fontsize=10,
              fontweight='bold')
    ax.text2D(0.02, 0.84,
              f'B = {n_B:5d}   ({100*fB:.1f}%)',
              transform=ax.transAxes, color=SECTOR_RGB[2], fontsize=10,
              fontweight='bold')
    ax.text2D(0.02, 0.78,
              f'Balance min/max = {bal:.3f}   '
              f'Dominant sector = {dominant}',
              transform=ax.transAxes, color='#dddddd', fontsize=9)
    ax.text2D(0.02, 0.74,
              f'Domain-wall voxels: {n_walls:5d}   '
              f'({100*f_wall_vox:.1f}%)',
              transform=ax.transAxes, color='#dddddd', fontsize=9)
    ax.text2D(0.02, 0.70,
              f'Heterogeneous faces (lu²): {wall_total:5d}   '
              f'({100*f_wall_face:.1f}% of all faces)',
              transform=ax.transAxes, color='#dddddd', fontsize=9)
    ax.text2D(0.02, 0.65,
              f'  R-G: {wall_pairs[(0,1)]:4d}   '
              f'G-B: {wall_pairs[(1,2)]:4d}   '
              f'R-B: {wall_pairs[(0,2)]:4d}',
              transform=ax.transAxes, color='#aaaaaa', fontsize=8,
              family='monospace')

    ax.set_xlim(0, N); ax.set_ylim(0, N); ax.set_zlim(0, N)
    ax.set_xlabel('x', color='white', fontsize=8)
    ax.set_ylabel('y', color='white', fontsize=8)
    ax.set_zlabel('z', color='white', fontsize=8)
    ax.tick_params(colors='white', labelsize=6)
    for pane in (ax.xaxis.pane, ax.yaxis.pane, ax.zaxis.pane):
        pane.fill = False
        pane.set_edgecolor('#222222')
    # Faint bounding wireframe — drawn after limits so it covers the
    # whole lattice volume regardless of how few/many voxels are filled
    draw_lattice_wireframe(ax, N)
    ax.view_init(elev=elev, azim=az)

    if render_mode == 'walls':
        legend_line = ('Wall faces: R-G → yellow, G-B → cyan, R-B → magenta '
                       '(soap-bubble view of the ℤ₃ domain network)')
    elif isolate:
        legend_line = f'Isolated {isolate} sub-lattice (other sectors hidden)'
    else:
        legend_line = ('All ℤ₃ sectors layered: R (red), G (green), B (blue) '
                       'at translucent overlay')
    fig.suptitle(
        f'CTC SU(3) — ℤ₃ R/G/B sector field    N={N}, β={beta}'
        + (f', α={alpha}' if alpha is not None else '') + '\n'
        + legend_line,
        color='white', fontsize=10, y=0.995)
    fig.tight_layout()
    return fig_to_rgba(fig), stats_dict


# ─── Main loop ───────────────────────────────────────────────────────────

delta_step = 0.15
plaq_val = measure_plaq(U)
print(f'\nInitial ⟨P⟩ = {plaq_val:.4f}')

# ── Pre-flight: inspect the initial sector field and warn if the chosen
# render mode is likely to be uninformative on this configuration. ────
_z3_init, _ = compute_z3_polyakov_with_phase(U)
_init_total = _z3_init.size
_init_n = [int(np.sum(_z3_init == k)) for k in (0, 1, 2)]
_init_f = [c / _init_total for c in _init_n]
_init_wall_vox = int(domain_wall_voxels(_z3_init).sum())
_init_wall_frac = _init_wall_vox / _init_total
_init_min_frac = min(_init_f)
_init_min_sector = ['R', 'G', 'B'][int(np.argmin(_init_f))]

print(f'Initial ℤ₃ composition:  '
      f'R={_init_n[0]} ({100*_init_f[0]:.1f}%)  '
      f'G={_init_n[1]} ({100*_init_f[1]:.1f}%)  '
      f'B={_init_n[2]} ({100*_init_f[2]:.1f}%)')
print(f'Initial domain-wall voxel fraction: {100*_init_wall_frac:.1f}%')

if args.render == 'walls' and _init_wall_frac > 0.85:
    print('\n  WARNING: walls render mode will be largely uninformative on '
          'this configuration.')
    print(f'  {100*_init_wall_frac:.1f}% of voxels neighbour a heterogeneous '
          'sector, so the soap-bubble view collapses into a single coloured '
          'blob.')
    print('  Consider --render volume (default cubes/points) or '
          f'--isolate {_init_min_sector} to see the minority sector alone.\n')

if (_init_min_frac < 0.10 and args.isolate is None
        and args.render not in ('slices', 'panels')):
    print(f'\n  NOTE: sector {_init_min_sector} is at '
          f'{100*_init_min_frac:.1f}% of sites (minority). It may be hard '
          f'to see in the combined view.')
    print(f'  Consider rerunning with --isolate {_init_min_sector} to '
          'render that sub-lattice alone, or --render panels to see each '
          'sector in its own subplot.\n')
del _z3_init  # don't carry the pre-flight array through the run

frames = []
hist = {
    'sweep': [], 'plaq': [],
    'n_R': [], 'n_G': [], 'n_B': [],
    'fR': [], 'fG': [], 'fB': [],
    'balance': [], 'dominant': [],
    'n_wall_voxels': [], 'wall_face_total': [],
    'wall_pair_RG': [], 'wall_pair_GB': [], 'wall_pair_RB': [],
    'polyakov_phase_mean_R': [],
    'polyakov_phase_mean_G': [],
    'polyakov_phase_mean_B': [],
}

t0 = time.time()
n_frames = args.movie_sweeps // args.save_every
print(f'\n[Movie] {n_frames} frames over {args.movie_sweeps} sweeps   '
      f'render={args.render}'
      + (f', isolate={args.isolate}' if args.isolate else ''))

for s in range(args.movie_sweeps):
    U, rate, delta_step = metropolis_sweep(U, beta, delta_step)
    if s % args.save_every == 0:
        idx = s // args.save_every
        plaq_val = measure_plaq(U)
        z3_3d, phase_3d = compute_z3_polyakov_with_phase(U)

        az = (idx * args.rotations * 360 / max(n_frames, 1)) % 360
        img, stats = render_frame(z3_3d, phase_3d, s, plaq_val,
                                  az, args.elev,
                                  render_mode=args.render,
                                  volume_alpha=args.volume_alpha,
                                  isolate=args.isolate,
                                  glyph=args.glyph,
                                  glyph_size=args.glyph_size)
        frames.append(img)

        hist['sweep'].append(s); hist['plaq'].append(plaq_val)
        for k, v in stats.items():
            if k in hist:
                hist[k].append(v)
        for k in ('R', 'G', 'B'):
            kidx = {'R': 0, 'G': 1, 'B': 2}[k]
            mask = (z3_3d == kidx)
            mean_phase = (float(phase_3d[mask].mean()) if mask.any() else 0.0)
            hist[f'polyakov_phase_mean_{k}'].append(mean_phase)

        elapsed = (time.time() - t0) / 60
        rem = (n_frames - idx - 1) * (time.time() - t0) / max(idx + 1, 1) / 60
        print(f'  frame {idx+1:3d}/{n_frames}  sw={s:4d}  '
              f'⟨P⟩={plaq_val:.4f}  '
              f'RGB=({stats["n_R"]:4d}/{stats["n_G"]:4d}/{stats["n_B"]:4d})  '
              f'bal={stats["balance"]:.3f}  dom={stats["dominant"]}  '
              f'walls={stats["n_wall_voxels"]:4d}  '
              f'el={elapsed:.1f}m rem~{rem:.1f}m')


# ─── Save outputs ────────────────────────────────────────────────────────

isolate_suffix = f'_{args.isolate}' if args.isolate else ''
render_suffix = f'_{args.render}' if args.render != 'volume' else ''
out_tag = TAG + render_suffix + isolate_suffix

gif_path = os.path.join(args.outdir, f'S5_z3_rgb_{out_tag}.gif')
print(f'\nSaving {len(frames)} frames to {gif_path} ...')
imageio.mimsave(gif_path, frames, fps=args.fps, loop=0)
print(f'Saved: {gif_path}  ({os.path.getsize(gif_path)/1024/1024:.1f} MB)')

hist_path = os.path.join(args.outdir, f'S5_z3_rgb_{out_tag}_history.json')
with open(hist_path, 'w') as f:
    json.dump({
        'classifier':    'polyakov_loop_phase',
        'render_mode':   args.render,
        'isolate':       args.isolate,
        'volume_alpha':  args.volume_alpha,
        'movie_sweeps':  args.movie_sweeps,
        'save_every':    args.save_every,
        'fps':           args.fps,
        'rotations':     args.rotations,
        'elev':          args.elev,
        'N':             N,
        'beta':          beta,
        'alpha':         alpha,
        'seed':          seed,
        'history':       hist,
    }, f, indent=2)
print(f'History: {hist_path}')


# ─── Run-averaged diagnostics ────────────────────────────────────────────

n_R_arr = np.asarray(hist['n_R'])
n_G_arr = np.asarray(hist['n_G'])
n_B_arr = np.asarray(hist['n_B'])
bal_arr = np.asarray(hist['balance'])
walls_arr = np.asarray(hist['n_wall_voxels'])

print('\n=== Run-averaged diagnostics ===')
print(f'  ⟨n_R⟩ = {n_R_arr.mean():.1f} ± {n_R_arr.std():.1f}    '
      f'⟨fR⟩ = {n_R_arr.mean()/N**3:.3f}')
print(f'  ⟨n_G⟩ = {n_G_arr.mean():.1f} ± {n_G_arr.std():.1f}    '
      f'⟨fG⟩ = {n_G_arr.mean()/N**3:.3f}')
print(f'  ⟨n_B⟩ = {n_B_arr.mean():.1f} ± {n_B_arr.std():.1f}    '
      f'⟨fB⟩ = {n_B_arr.mean()/N**3:.3f}')
print(f'  ⟨balance⟩ = {bal_arr.mean():.3f} ± {bal_arr.std():.3f}')
print(f'  ⟨wall voxels⟩ = {walls_arr.mean():.1f} ± {walls_arr.std():.1f}   '
      f'({100*walls_arr.mean()/N**3:.1f}% of lattice)')

# Sector-rotation diagnostic
from collections import Counter
dom_counter = Counter(hist['dominant'])
n_total = len(hist['dominant'])
most_common = dom_counter.most_common(1)[0] if n_total else ('?', 0)
print(f'  dominant sector tenure: '
      f'{most_common[0]} held {most_common[1]}/{n_total} frames '
      f'({100*most_common[1]/max(n_total,1):.0f}%)')
if most_common[1] / max(n_total, 1) < 0.8:
    print('  -> dominant sector rotates across run')
    print('     (trajectory sampled multiple ℤ\u2083 sectors;')
    print('      consistent with unbroken ℤ\u2083 in the thermodynamic limit)')
else:
    print('  -> dominant sector is stable')
    print('     (Polyakov sector freezing: tunneling between ℤ\u2083 vacua is')
    print('      exponentially suppressed at finite volume. The full')
    print('      ℤ\u2083-symmetric ensemble is recovered by averaging across')
    print('      independent seeds, not within a single run. Multi-seed test')
    print('      required to distinguish from genuine ℤ\u2083 symmetry breaking.)')

print('\nDone.')
