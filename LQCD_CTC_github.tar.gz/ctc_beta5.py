#!/usr/bin/env python3
# ============================================================
# CTC SU(3) — VECTORIZED PRODUCTION SCALING STUDY (BETA=5.0)
#
# OPTIMIZED FOR BETA=5.0 (warm phase):
#   - Larger meson search radius (more spread out vortices)
#   - Larger baryon perimeter (wider triplets)
#   - R-inclusive baryon sampling (all R eddies always checked)
#   - Strict center projection kept at trP < 1.0
#
# 2026-05-04 update — Z3 classifier is now Polyakov-loop trace phase
#   (true topological sector at each spatial site). The previous
#   single-plane plaquette argmax was biased toward k=0 in the bulk
#   Wilson vacuum (Tr P_01 is real-positive most everywhere). The old
#   plaquette classifier is kept alongside as a parallel diagnostic
#   under keys n_R_plaq, n_G_plaq, n_B_plaq, so any disagreement
#   between the two classifiers is visible in records.json per sweep.
#   This matches ctc_T0i_action_save_v3.py.
#
# 2026-05-08 update — find_rgb_mesons rewritten with per-color
#   sampling, mirroring the structure of find_rgb_baryons. Previous
#   version used max_pts = min(len(cores), 500) which capped the
#   meson count at ~250 for any run with >500 eddy cores. At N>=24
#   that cap was binding and produced an artifact volume-scaling in
#   mes/N^4. See docstring of find_rgb_mesons below for the full
#   explanation.
#
# Usage:
#   python3 ctc_beta5.py --N 24 --beta 5.0 --sweeps 1000
# ============================================================

import numpy as np
import matplotlib.pyplot as plt
from scipy.ndimage import maximum_filter
from scipy.stats import gaussian_kde
import warnings
import datetime
import os
import json
import argparse

warnings.filterwarnings('ignore')

parser = argparse.ArgumentParser()
parser.add_argument('--N',             type=int,   default=24)
parser.add_argument('--beta',          type=float, default=5.0)
parser.add_argument('--sweeps',        type=int,   default=1000)
parser.add_argument('--measure_every', type=int,   default=10)
parser.add_argument('--seed',          type=int,   default=42)
parser.add_argument('--output_dir',    type=str,   default=None)
args = parser.parse_args()

N             = args.N
beta          = args.beta
sweeps        = args.sweeps
measure_every = args.measure_every
SEED          = args.seed
np.random.seed(SEED)

RUN_TIMESTAMP = datetime.datetime.now().strftime("%Y-%m-%d_%H%M%S")
OUTPUT_DIR    = (args.output_dir or
                 f"CTC_Beta5_N{N}_b{beta:.1f}_{RUN_TIMESTAMP}")
os.makedirs(OUTPUT_DIR, exist_ok=True)
LOG_FILE = os.path.join(OUTPUT_DIR, "run.log")

def log(msg):
    print(msg, flush=True)
    with open(LOG_FILE, 'a') as f:
        f.write(msg + '\n')

log("=" * 80)
log("CTC SU(3) — OPTIMIZED FOR BETA=5.0 (WARM PHASE)")
log("=" * 80)
log(f"N={N}  ({N**4} sites)  beta={beta}  sweeps={sweeps}  seed={SEED}")
log(f"Output: {OUTPUT_DIR}/")
log("=" * 80)
log("FIXES vs uploaded version:")
log("  1. center projection: trP < 1.0 (strict) not < 2.5 (loose)")
log("  2. baryon search: R-inclusive sampling, not first-200 cutoff")
log("  3. Z3 classifier: Polyakov-loop trace phase (true topological sector)")
log("     + parallel single-plane plaquette classifier kept for diagnostics")
log("  4. meson search: per-color sampling (mirrors baryon fix); previous")
log("     500-core cap capped meson counts at ~250 for N>=24")
log("=" * 80)

PLANES = [(0,1),(0,2),(0,3),(1,2),(1,3),(2,3)]

# ============================================================
# 1. SU(3) UTILITIES
# ============================================================

def random_su3_batch(shape):
    size = int(np.prod(shape))
    A = (np.random.randn(size, 3, 3) + 1j*np.random.randn(size, 3, 3))
    Q, R = np.linalg.qr(A)
    d = np.linalg.det(Q)
    Q = Q / (d[:, None, None] ** (1/3))
    return Q.reshape(*shape, 3, 3)

def project_su3_batch(M):
    U_arr, _, Vh = np.linalg.svd(M)
    Q = U_arr @ Vh
    d = np.linalg.det(Q)
    return Q / (d[..., None, None] ** (1/3))

def plaquette_batch(U, mu, nu):
    U_nu_xmu = np.roll(U[nu], -1, axis=mu)
    U_mu_xnu = np.roll(U[mu], -1, axis=nu)
    P  = U[mu] @ U_nu_xmu
    P  = P     @ U_mu_xnu.conj().swapaxes(-1,-2)
    P  = P     @ U[nu].conj().swapaxes(-1,-2)
    return P

def staple_batch(U, mu):
    staple = np.zeros((N,N,N,N,3,3), dtype=complex)
    for nu in range(4):
        if nu == mu: continue
        U_nu_xmu  = np.roll(U[nu], -1, axis=mu)
        U_mu_xnu  = np.roll(U[mu], -1, axis=nu)
        U_nu_bwd  = np.roll(U[nu],  1, axis=nu)
        U_mu_bwd  = np.roll(U[mu],  1, axis=nu)
        fwd = U[nu] @ U_mu_xnu @ U_nu_xmu.conj().swapaxes(-1,-2)
        staple += fwd
        U_nu_xmu_bwd = np.roll(U_nu_bwd, -1, axis=mu)
        bwd = U_nu_bwd.conj().swapaxes(-1,-2) @ U_mu_bwd @ U_nu_xmu_bwd
        staple += bwd
    return staple

# ============================================================
# 2. METROPOLIS
# ============================================================

def metropolis_sweep(U, beta, delta):
    accepted = 0; total = 0
    for mu in range(4):
        staples = staple_batch(U, mu)
        xi, yi, zi, ti = np.meshgrid(
            np.arange(N), np.arange(N), np.arange(N), np.arange(N),
            indexing='ij')
        parity = (xi + yi + zi + ti) % 2
        for p in [0, 1]:
            mask      = (parity == p)
            old_links = U[mu].copy()
            new_links = project_su3_batch(
                old_links + delta*(random_su3_batch((N,N,N,N)) - old_links))
            S_old = beta * np.real(np.trace(old_links @ staples, axis1=-2, axis2=-1))
            S_new = beta * np.real(np.trace(new_links @ staples, axis1=-2, axis2=-1))
            accept = (np.random.random((N,N,N,N)) <
                      np.exp(np.clip(S_new - S_old, -100, 0))) & mask
            U[mu][accept] = new_links[accept]
            accepted += int(accept.sum()); total += int(mask.sum())
    rate = accepted / max(total, 1)
    delta = min(delta*1.05, 0.5) if rate > 0.55 else max(delta*0.95, 0.05)
    return U, rate, delta

# ============================================================
# 3. OBSERVABLES
# ============================================================

def measure_bulk(U):
    plaq_sum = 0.0; vortex_count = 0; total = 0
    for mu, nu in PLANES:
        trP = np.real(np.trace(plaquette_batch(U, mu, nu), axis1=-2, axis2=-1))
        plaq_sum     += np.sum(trP) / 3.0
        vortex_count += int(np.sum(np.abs(trP) < 2.5))
        total        += trP.size
    return plaq_sum / total, vortex_count / total * 100

# ── Z3 classifiers ────────────────────────────────────────────────────────────

def compute_z3_polyakov(U):
    """True topological Z3 sector at each spatial site via Polyakov loop.
    L(x,y,z) = U_t(x,y,z,0) @ U_t(x,y,z,1) @ ... @ U_t(x,y,z,N-1)
    arg(Tr L) ∈ {≈0, ≈2π/3, ≈4π/3} → sector k = 0, 1, 2.
    Returns 4D array with same Z3 sector tiled across all t.
    """
    L = U[0][:, :, :, 0, :, :].copy()
    for tau in range(1, N):
        L = np.matmul(L, U[0][:, :, :, tau, :, :])
    Tr_L  = np.trace(L, axis1=-2, axis2=-1)
    angle = np.angle(Tr_L) % (2 * np.pi)
    z3_3d = np.round(angle * 3.0 / (2 * np.pi)).astype(int) % 3
    return np.broadcast_to(z3_3d[:, :, :, None], (N, N, N, N)).copy()

def compute_z3_plaquette_old(U):
    """Original single-plane (0,1) plaquette argmax classifier.
    Kept for direct comparison with the Polyakov-loop classifier."""
    P01  = plaquette_batch(U, 0, 1)
    tr01 = np.trace(P01, axis1=-2, axis2=-1)
    vals = np.stack([np.real(tr01 * np.exp(-2j*np.pi*k/3)) for k in range(3)], axis=-1)
    return np.argmax(vals, axis=-1).astype(int)

def compute_ctc(U):
    curv_sum = np.zeros((N,N,N,N))
    div_sum  = np.zeros((N,N,N,N))
    center   = np.zeros((N,N,N,N), dtype=int)
    for mu, nu in PLANES:
        P   = plaquette_batch(U, mu, nu)
        trP = np.real(np.trace(P, axis1=-2, axis2=-1))
        curv_sum += np.arccos(np.clip(trP/3.0, -1.0, 1.0))
        # ── STRICT center projection: trP < 1.0 (not 2.5) ──
        # 2.5 is the loose vortex criterion and flags everything at beta=5.0
        # 1.0 is the strict criterion — only genuine Z3 non-trivial sites
        center += (trP < 1.0).astype(int)
        for rho in range(4):
            if rho == mu or rho == nu: continue
            P_fwd = np.roll(P, -1, axis=rho)
            transported = U[rho] @ P_fwd @ U[rho].conj().swapaxes(-1,-2)
            div_sum += np.sqrt(np.sum(np.abs(P - transported)**2, axis=(-2,-1)))
    curvature     = curv_sum / len(PLANES)
    center_charge = np.where(center > 0, 1, -1)
    divF          = div_sum / len(PLANES) + 1e-6
    mass          = curvature / divF
    # ── Z3 classification ──
    # Primary: Polyakov-loop trace phase (gauge-invariant Z3 order parameter)
    # Diagnostic: single-plane plaquette argmax (the previous classifier)
    z3_field      = compute_z3_polyakov(U)
    z3_field_plaq = compute_z3_plaquette_old(U)
    return curvature, mass, center_charge, divF, z3_field, z3_field_plaq

def extract_mass_gap(mass, divF):
    mask = (divF > 1e-6) & (mass < 100) & (mass > 0)
    m    = mass[mask].flatten()
    if len(m) < 10: return float(np.percentile(m, 0.5)), 0.0
    try:
        kde     = gaussian_kde(m, bw_method='silverman')
        x_range = np.linspace(m.min(), np.percentile(m, 25), 1000)
        density = kde(x_range)
        noise   = np.percentile(density, 5)
        above   = x_range[density > 3.0*noise]
        gap     = above[0] if len(above) > 0 else float(np.percentile(m, 0.5))
        gd      = kde(np.array([gap]))[0]
        return float(gap), float(0.5/(gd*len(m)) if gd > 0 else 0.0)
    except:
        return float(np.percentile(m, 0.5)), 0.0

def find_eddy_cores(mass, center_charge, peak_radius=2):
    local_max = (mass == maximum_filter(mass, size=peak_radius*2+1))
    return np.argwhere(local_max & (center_charge == 1))

def pbc_dist(p1, p2):
    diff = np.abs(p1.astype(int) - p2.astype(int))
    return float(np.sqrt(np.sum(np.minimum(diff, N-diff)**2)))

def mass_ratio_calc(mass, cores, n_bg=500):
    if len(cores) == 0: return 1.0
    eddy_m = [float(mass[tuple(c)]) for c in cores if mass[tuple(c)] < 100]
    bg_m = []; attempts = 0
    while len(bg_m) < n_bg and attempts < n_bg*10:
        pt = tuple(np.random.randint(0, N, 4))
        if mass[pt] < 100:
            dists = [pbc_dist(c, np.array(pt)) for c in cores]
            if min(dists) > 5: bg_m.append(float(mass[pt]))
        attempts += 1
    return float(np.mean(eddy_m)/np.mean(bg_m)) if eddy_m and bg_m else 1.0

# ============================================================
# 4. RGB DETECTION — R-INCLUSIVE BARYON & MESON SEARCH
# ============================================================

def find_rgb_mesons(cores, z3_charges, mass, max_dist):
    """
    R-inclusive meson search.

    Mirrors the per-color-cap structure used in find_rgb_baryons so
    the meson search subset cannot be silently consumed by a single
    Z3 sector at large N. Previous version used
        max_pts = min(len(cores), 500)
    which capped the search at the first 500 cores by lexicographic
    np.argwhere order and therefore at ~250 mesons total. At N >= 24
    the eddy-core count exceeds 500 (~600 at N=24, ~2000 at N=32),
    so the meson count saturated at ~245 across all sweeps and the
    apparent meson density mes/N^4 dropped with volume — a cap
    artifact, not physics.

    A meson is any pair of eddy cores whose Z3 charges sum to 0 mod 3:
    (R,R), (G,B), or (B,G). Per-color sampling guarantees that all
    three pair types are findable independent of the relative R/G/B
    populations on the lattice.
    """
    if len(cores) < 2:
        return []
    mesons = []
    used = set()

    r_idx = np.where(z3_charges == 0)[0]
    g_idx = np.where(z3_charges == 1)[0]
    b_idx = np.where(z3_charges == 2)[0]

    # Per-color cap. Mesons are O(n^2), so we can afford a much
    # higher cap than baryons (which are O(n^3) and use 200/color).
    # 1000/color = 3000 in the pool = up to 1500 mesons, well clear
    # of any current run including N=32.
    max_per_color = 1000

    if len(r_idx) > max_per_color:
        r_sample = np.random.choice(r_idx, max_per_color, replace=False)
    else:
        r_sample = r_idx
    if len(g_idx) > max_per_color:
        g_sample = np.random.choice(g_idx, max_per_color, replace=False)
    else:
        g_sample = g_idx
    if len(b_idx) > max_per_color:
        b_sample = np.random.choice(b_idx, max_per_color, replace=False)
    else:
        b_sample = b_idx

    sample_idx     = np.concatenate([r_sample, g_sample, b_sample]).astype(int)
    sample_cores   = cores[sample_idx]
    sample_charges = z3_charges[sample_idx]

    n = len(sample_cores)
    for i in range(n):
        if i in used:
            continue
        c1 = int(sample_charges[i])
        best_dist = max_dist + 1
        best_j = -1
        for j in range(n):
            if j == i or j in used:
                continue
            if (c1 + int(sample_charges[j])) % 3 != 0:
                continue
            d = pbc_dist(sample_cores[i], sample_cores[j])
            if d < best_dist:
                best_dist = d
                best_j = j
        if best_j >= 0 and best_dist <= max_dist:
            mesons.append({
                'charge1': c1,
                'charge2': int(sample_charges[best_j]),
                'distance': best_dist,
                'total_mass': float(
                    mass[tuple(sample_cores[i])] +
                    mass[tuple(sample_cores[best_j])]
                )
            })
            used.add(i)
            used.add(best_j)
    return mesons

def find_rgb_baryons(cores, z3_charges, mass, max_perim, planarity_thresh):
    """
    R-inclusive baryon search.
    Always includes ALL R eddies (scarce color) in the search subset.
    Randomly samples G and B to fill remaining slots up to 200 total.
    This prevents missing baryons due to R eddies being excluded from
    a first-N positional cutoff.
    """
    if len(cores) < 3: return []
    baryons = []; t_thresh = planarity_thresh * N

    # R-inclusive sampling: all R + random sample of G and B
    r_idx = np.where(z3_charges == 0)[0]
    g_idx = np.where(z3_charges == 1)[0]
    b_idx = np.where(z3_charges == 2)[0]

    # R-inclusive sampling: cap EACH sector independently rather than the total.
    # Previous version used a single max_sample=200 cap that was consumed by
    # all R cores when the R sector had >200 cores (e.g. at N=24 with ~700
    # cores, R alone is ~230, leaving 0 budget for G and B and zero baryons
    # ever found). Now each sector contributes up to max_per_color=200 cores,
    # so even when R is abundant, G and B still get sampled and R+G+B triplets
    # become findable.
    max_per_color = 200

    if len(r_idx) > max_per_color:
        r_sample = np.random.choice(r_idx, max_per_color, replace=False)
    else:
        r_sample = r_idx
    if len(g_idx) > max_per_color:
        g_sample = np.random.choice(g_idx, max_per_color, replace=False)
    else:
        g_sample = g_idx
    if len(b_idx) > max_per_color:
        b_sample = np.random.choice(b_idx, max_per_color, replace=False)
    else:
        b_sample = b_idx

    sample_idx = np.concatenate([r_sample, g_sample, b_sample]).astype(int)
    sample_cores   = cores[sample_idx]
    sample_charges = z3_charges[sample_idx]

    n = len(sample_cores)
    for i in range(n):
        if len(baryons) > 500: break
        for j in range(i+1, n):
            for k in range(j+1, n):
                c1 = int(sample_charges[i])
                c2 = int(sample_charges[j])
                c3 = int(sample_charges[k])
                if sorted([c1,c2,c3]) != [0,1,2]: continue
                v1, v2, v3 = sample_cores[i], sample_cores[j], sample_cores[k]
                d12 = pbc_dist(v1, v2)
                d23 = pbc_dist(v2, v3)
                d31 = pbc_dist(v3, v1)
                perim = d12 + d23 + d31
                if perim >= max_perim: continue
                if not (d12+d23>d31 and d23+d31>d12 and d31+d12>d23): continue
                t_spread = float(max(v1[3],v2[3],v3[3]) - min(v1[3],v2[3],v3[3]))
                baryons.append({
                    'perimeter': float(perim),
                    'total_mass': float(mass[tuple(v1)]+mass[tuple(v2)]+mass[tuple(v3)]),
                    'is_planar': t_spread < t_thresh,
                    't_spread': t_spread
                })
    return baryons

# ============================================================
# 5. MAIN LOOP
# ============================================================

log(f"\nInitializing U[4,{N},{N},{N},{N},3,3]...")
U     = random_su3_batch((4,N,N,N,N))
delta = 0.15
log("Done.")

records = {k: [] for k in [
    'sweep','plaquette','vortex_pct','acceptance','delta_val',
    'n_cores','n_R','n_G','n_B','z3_balance',
    'n_R_plaq','n_G_plaq','n_B_plaq',
    'n_mesons','n_baryons','n_planar',
    'mass_gap','mass_gap_err','mass_ratio',
]}

log(f"\nRunning {sweeps} sweeps, measuring every {measure_every}...")
log("-" * 80)
t_total = datetime.datetime.now()

for s in range(sweeps):
    t0 = datetime.datetime.now()
    U, rate, delta = metropolis_sweep(U, beta, delta)
    t_sw = (datetime.datetime.now()-t0).total_seconds()

    if s % measure_every == 0 or s == sweeps-1:
        t1 = datetime.datetime.now()
        plaq, vdens = measure_bulk(U)
        curvature, mass, center_charge, divF, z3_field, z3_field_plaq = compute_ctc(U)
        cores = find_eddy_cores(mass, center_charge)

        if len(cores) > 0:
            # Primary: Polyakov-loop classification (used for hadron search)
            z3_charges = z3_field[cores[:,0], cores[:,1], cores[:,2], cores[:,3]]
            n_R = int(np.sum(z3_charges==0))
            n_G = int(np.sum(z3_charges==1))
            n_B = int(np.sum(z3_charges==2))
            rgb = [n_R,n_G,n_B]
            bal = min(rgb)/max(rgb) if max(rgb)>0 else 0.0
            dom = ['R','G','B'][int(np.argmax(rgb))]

            # Parallel diagnostic: old single-plane plaquette classifier
            z3_charges_plaq = z3_field_plaq[cores[:,0], cores[:,1], cores[:,2], cores[:,3]]
            n_R_plaq = int(np.sum(z3_charges_plaq==0))
            n_G_plaq = int(np.sum(z3_charges_plaq==1))
            n_B_plaq = int(np.sum(z3_charges_plaq==2))

            # Adaptive thresholds for beta=5.0 warm phase
            d_mean       = (N**4 / max(len(cores),1))**0.25
            meson_reach  = max(10, int(2.5*d_mean))
            baryon_perim = max(25, int(3.5*meson_reach))

            mesons  = find_rgb_mesons(cores, z3_charges, mass, meson_reach)
            baryons = find_rgb_baryons(cores, z3_charges, mass,
                                        baryon_perim, 0.15)
            planar  = [b for b in baryons if b['is_planar']]
            gap, gap_err = extract_mass_gap(mass, divF)
            ratio        = mass_ratio_calc(mass, cores)
        else:
            n_R=n_G=n_B=0; bal=0.0; dom='?'
            n_R_plaq=n_G_plaq=n_B_plaq=0
            mesons=[]; baryons=[]; planar=[]
            gap=gap_err=0.0; ratio=1.0

        for key,val in [
            ('sweep',s),('plaquette',float(plaq)),
            ('vortex_pct',float(vdens)),('acceptance',float(rate)),
            ('delta_val',float(delta)),('n_cores',int(len(cores))),
            ('n_R',n_R),('n_G',n_G),('n_B',n_B),
            ('z3_balance',float(bal)),
            ('n_R_plaq',n_R_plaq),('n_G_plaq',n_G_plaq),('n_B_plaq',n_B_plaq),
            ('n_mesons',int(len(mesons))),
            ('n_baryons',int(len(baryons))),
            ('n_planar',int(len(planar))),
            ('mass_gap',gap),('mass_gap_err',gap_err),
            ('mass_ratio',float(ratio)),
        ]: records[key].append(val)

        with open(os.path.join(OUTPUT_DIR,'records.json'),'w') as f:
            json.dump(records, f, indent=2)

        t_ms = (datetime.datetime.now()-t1).total_seconds()
        tot  = (datetime.datetime.now()-t_total).total_seconds()
        log(f"  Sweep {s:5d}: "
            f"<P>={plaq:.4f}  Vx={vdens:.1f}%  Acc={rate:.3f}  d={delta:.3f}  "
            f"cores={len(cores)}  "
            f"RGB_poly=({n_R}/{n_G}/{n_B})[{dom}]  "
            f"RGB_plaq=({n_R_plaq}/{n_G_plaq}/{n_B_plaq})  "
            f"bal={bal:.3f}  "
            f"mes={len(mesons)}  bar={len(baryons)}({len(planar)}pl)  "
            f"Δ={gap:.5f}±{gap_err:.5f}  r={ratio:.3f}x  "
            f"t_sw={t_sw:.1f}s  t_ms={t_ms:.1f}s  tot={tot/60:.1f}m")

# ============================================================
# 6. FINAL ANALYSIS + VISUALIZATION
# ============================================================

# ── Save equilibrated U field for post-processing ─────────────────────────
u_path = os.path.join(OUTPUT_DIR, f'U_final_N{N}_b{beta:.1f}_s{SEED}.npy')
np.save(u_path, U)
log(f"\nSaved equilibrated U field: {u_path}")
log(f"  Shape: {U.shape}  dtype: {U.dtype}  size: {U.nbytes/1e6:.1f} MB")
log("  → Use figure1_from_U.py to regenerate Figure 1 from this checkpoint.")


log("\n"+"="*80+"\nFINAL ANALYSIS\n"+"="*80)
r = records
if len(r['sweep'])>0:
    log(f"N={N}, beta={beta}")
    log(f"  <P>:        {r['plaquette'][0]:.4f} -> {r['plaquette'][-1]:.4f}")
    log(f"  Vortex:     {r['vortex_pct'][0]:.1f}% -> {r['vortex_pct'][-1]:.1f}%")
    log(f"  Cores:      {r['n_cores'][-1]}")
    log(f"  Z3 balance: {r['z3_balance'][0]:.3f} -> {r['z3_balance'][-1]:.3f}")
    log(f"  Mesons:     {r['n_mesons'][-1]}")
    log(f"  Baryons:    {r['n_baryons'][-1]} ({r['n_planar'][-1]} planar)")
    log(f"  Delta:      {r['mass_gap'][-1]:.5f} +/- {r['mass_gap_err'][-1]:.5f}")
    log(f"  Ratio:      {r['mass_ratio'][-1]:.3f}x")
    if len(r['mass_gap'])>=5:
        g_late  = np.std(r['mass_gap'][-5:])
        g_early = np.std(r['mass_gap'][:3]) if len(r['mass_gap'])>=3 else 1.0
        log(f"\n  CTC KEY TEST: Delta std early={g_early:.6f}  late={g_late:.6f}")
        log(f"  {'SUPPORTED' if g_late < g_early*0.5 else 'Need more sweeps'}")

plt.style.use('dark_background')
plt.rcParams.update({'font.family':'serif','figure.dpi':150,'savefig.dpi':350,
                     'axes.edgecolor':'#00ffff','xtick.color':'white',
                     'ytick.color':'white','text.color':'white','axes.labelcolor':'white'})
sw = np.array(r['sweep'])
fig, axes = plt.subplots(3,3,figsize=(20,15))
fig.patch.set_facecolor('#0a0a0a')
fig.suptitle(f'CTC SU(3) beta=5.0 — N={N}, sweeps={sweeps}',
             fontsize=14, fontweight='bold', color='white', y=0.99)
CYAN='#00ffff'; RED='#ff3366'; BLUE='#3399ff'
GOLD='#ffcc00'; GRN='#33ff99'; ORG='#ff9933'

def style(ax, title):
    ax.set_facecolor('#0d0d15'); ax.set_title(title,fontsize=10,fontweight='bold',color='white',pad=5)
    ax.tick_params(colors='white'); ax.grid(True,alpha=0.15,linestyle='--',color='white')
    for sp in ax.spines.values(): sp.set_color(CYAN); sp.set_linewidth(1.5)

for ax,key,title,col,hl,hll in [
    (axes[0,0],'plaquette','(1) Plaquette',BLUE,0.3,'Target'),
    (axes[0,1],'vortex_pct','(2) Vortex %',RED,50.,'Expected'),
    (axes[0,2],'acceptance','(3) Acceptance',GRN,0.5,'Target'),
    (axes[1,2],'z3_balance','(5) Z3 Balance',GOLD,0.5,'Moderate'),
    (axes[2,0],'mass_gap','(7) Mass Gap Δ',CYAN,None,None),
    (axes[2,2],'mass_ratio','(9) Mass Ratio',ORG,1.0,'No enh.'),
]:
    style(ax,title); ax.plot(sw,r[key],'o-',color=col,lw=2,ms=3)
    if hl: ax.axhline(hl,color=GOLD,lw=1.5,linestyle='--',label=hll); ax.legend(fontsize=7,facecolor='#0d0d15',edgecolor=CYAN,labelcolor='white')
    ax.set_xlabel('Sweep',color='white')

ax=axes[1,0]; style(ax,'(4) Z3 Distribution')
ax.plot(sw,r['n_R'],'o-',color='#ff3333',lw=2,ms=3,label='R')
ax.plot(sw,r['n_G'],'s-',color='#33ff33',lw=2,ms=3,label='G')
ax.plot(sw,r['n_B'],'^-',color='#3333ff',lw=2,ms=3,label='B')
ax.set_xlabel('Sweep',color='white'); ax.legend(fontsize=8,facecolor='#0d0d15',edgecolor=CYAN,labelcolor='white')

ax=axes[1,1]; style(ax,'(6) Hadron Formation')
ax.plot(sw,r['n_mesons'],'o-',color=BLUE,lw=2,ms=3,label='Mesons')
ax.plot(sw,r['n_baryons'],'s-',color=GOLD,lw=2,ms=3,label='RGB Bar')
ax.plot(sw,r['n_planar'],'^-',color=GRN,lw=2,ms=3,label='Planar')
ax.set_xlabel('Sweep',color='white'); ax.legend(fontsize=8,facecolor='#0d0d15',edgecolor=CYAN,labelcolor='white')

ax=axes[2,1]; style(ax,'(8) Δ vs Eddy Count')
ax2=ax.twinx()
ax.plot(sw,r['mass_gap'],'o-',color=RED,lw=2.5,ms=4,label='Δ')
ax2.plot(sw,r['n_cores'],'s--',color=GOLD,lw=2,ms=3,label='Cores')
ax.set_ylabel('Δ',color=RED); ax2.set_ylabel('Cores',color=GOLD)
ax.tick_params(axis='y',labelcolor=RED); ax2.tick_params(axis='y',labelcolor=GOLD)
ax.set_xlabel('Sweep',color='white')
l1,lb1=ax.get_legend_handles_labels(); l2,lb2=ax2.get_legend_handles_labels()
ax.legend(l1+l2,lb1+lb2,fontsize=8,facecolor='#0d0d15',edgecolor=CYAN,labelcolor='white')

plt.tight_layout()
outpng = os.path.join(OUTPUT_DIR,f'CTC_Beta5_N{N}_b{beta:.1f}.png')
plt.savefig(outpng,dpi=350,bbox_inches='tight',facecolor='#0a0a0a')
log(f"\nPlot: {outpng}")
log(f"JSON: {os.path.join(OUTPUT_DIR,'records.json')}")
log("\nDone.")
