#!/usr/bin/env python3
"""
dashboard_lite_from_json.py — 9-panel dashboard for augmented-action runs.

This is the post-processing companion for ctc_T0i_action_save.py output.
It is structurally identical to dashboard_from_json.py but adapted for the
augmented-action record set:

  - No mesons / baryons / planar panels (the augmented-action script does
    not measure these). Those panels are replaced by T⁰ⁱ-related diagnostics.
  - Reads N, β, α, seed directly from records.json (the augmented-action
    script stores them as scalars, not lists).

The dashboard's load-bearing panel is "Δ vs T⁰ⁱ mean" (panel 9), which
visualises the central empirical claim: as α drives T⁰ⁱ to large amplitude,
Δ does not respond.

Usage
-----
    python3 dashboard_lite_from_json.py records_N24_b5.8_a1.00_s42.json
    python3 dashboard_lite_from_json.py records_*.json --dark --outdir figs/
    python3 dashboard_lite_from_json.py records.json --cut_eq 1500
"""

import argparse
import json
import os
import re
import sys
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt


# ─── CLI ──────────────────────────────────────────────────────────────────
ap = argparse.ArgumentParser(
    description='9-panel dashboard for augmented-action records.json.')
ap.add_argument('json_file',
                help='Path to records*.json saved by ctc_T0i_action_save.py')
ap.add_argument('--outdir', default=None,
                help='Output directory (default: same as records.json)')
ap.add_argument('--dark', action='store_true',
                help='Dark background style (default: white)')
ap.add_argument('--cut_eq', type=int, default=0,
                help='Only plot sweeps >= this value '
                     '(useful for trimming pre-equilibrium transients)')
ap.add_argument('--N',     type=int,   default=None)
ap.add_argument('--beta',  type=float, default=None)
ap.add_argument('--alpha', type=float, default=None)
ap.add_argument('--seed',  type=int,   default=None)
ap.add_argument('--dpi',   type=int,   default=350)
args = ap.parse_args()


# ─── load JSON ────────────────────────────────────────────────────────────
if not os.path.isfile(args.json_file):
    sys.exit(f"ERROR: file not found: {args.json_file}")

print(f"Loading {args.json_file} ...")
with open(args.json_file) as f:
    records = json.load(f)

if 'sweep' not in records or len(records['sweep']) == 0:
    sys.exit("ERROR: records.json contains no sweep data")


# ─── metadata ─────────────────────────────────────────────────────────────
# The augmented-action script stores N, β, α, seed as scalars.
def _scalar(key, default=None):
    """Return records[key] as a scalar (the augmented-action script stores
    these as scalars, but be tolerant if a list slipped in)."""
    v = records.get(key, default)
    if isinstance(v, list):
        return v[0] if v else default
    return v

N     = args.N     if args.N     is not None else _scalar('N',     0)
beta  = args.beta  if args.beta  is not None else _scalar('beta',  float('nan'))
alpha = args.alpha if args.alpha is not None else _scalar('alpha', None)
seed  = args.seed  if args.seed  is not None else _scalar('seed',  None)

# Fallback: parse from filename if metadata missing
if (N == 0) or (alpha is None) or (seed is None):
    fname = os.path.basename(args.json_file)
    m = re.search(r'N(\d+)_b([\d.]+?)_(?:(am?)([\d.]+?)_)?s(\d+)', fname)
    if m:
        if N == 0:    N    = int(m.group(1))
        if np.isnan(beta): beta = float(m.group(2))
        if alpha is None and m.group(4) is not None:
            sign = -1.0 if m.group(3) == 'am' else 1.0
            alpha = sign * float(m.group(4))
        if seed is None: seed = int(m.group(5))

# Final integer/float sanitisation
try:
    N    = int(N)
except (ValueError, TypeError):
    N = 0
try:
    beta = float(beta)
except (ValueError, TypeError):
    beta = float('nan')
try:
    seed = int(seed) if seed is not None else 0
except (ValueError, TypeError):
    seed = 0
try:
    alpha = float(alpha) if alpha is not None else 0.0
except (ValueError, TypeError):
    alpha = 0.0

n_records = len(records['sweep'])
print(f"  N={N}  β={beta}  α={alpha:+.2f}  seed={seed}  records={n_records}")

outdir = args.outdir if args.outdir is not None else os.path.dirname(
    os.path.abspath(args.json_file))
os.makedirs(outdir, exist_ok=True)


# ─── apply equilibrium cut if requested ──────────────────────────────────
if args.cut_eq > 0:
    sw_arr = np.array(records['sweep'])
    keep   = sw_arr >= args.cut_eq
    if keep.sum() < 2:
        sys.exit(f"ERROR: --cut_eq {args.cut_eq} leaves <2 records; aborting")
    for k in records:
        if isinstance(records[k], list) and len(records[k]) == n_records:
            records[k] = [v for v, ok in zip(records[k], keep) if ok]
    n_records = len(records['sweep'])
    print(f"  After --cut_eq {args.cut_eq}: {n_records} records remain")


# ─── style ─────────────────────────────────────────────────────────────────
WHITE = not args.dark
if WHITE:
    BG, PAN, TC = 'white', '#f5f5f5', 'black'
    EDGE = '#888888'
    CYAN, RED, BLUE = '#0077bb', '#cc2222', '#2255aa'
    GOLD, GRN, ORG  = '#bb8800', '#118855', '#cc6611'
    PURPLE = '#7a3d9a'
    plt.style.use('default')
    plt.rcParams.update({
        'font.family': 'serif',
        'axes.facecolor': PAN,
        'figure.facecolor': BG,
        'axes.edgecolor': EDGE,
        'text.color': TC,
        'axes.labelcolor': TC,
        'xtick.color': TC,
        'ytick.color': TC,
        'grid.color': '#cccccc',
    })
else:
    BG, PAN, TC = '#0a0a0a', '#0d0d15', 'white'
    EDGE = '#00ffff'
    CYAN, RED, BLUE = '#00ffff', '#ff3366', '#3399ff'
    GOLD, GRN, ORG  = '#ffcc00', '#33ff99', '#ff9933'
    PURPLE = '#bb55dd'
    plt.style.use('dark_background')
    plt.rcParams.update({
        'font.family': 'serif',
        'axes.edgecolor': EDGE,
        'xtick.color': 'white',
        'ytick.color': 'white',
        'text.color': 'white',
        'axes.labelcolor': 'white',
    })

plt.rcParams.update({
    'figure.dpi': 150,
    'savefig.dpi': args.dpi,
})


# ─── helpers ──────────────────────────────────────────────────────────────
def style(ax, title):
    ax.set_facecolor(PAN)
    ax.set_title(title, fontsize=10, fontweight='bold', color=TC, pad=5)
    ax.tick_params(colors=TC)
    ax.grid(True, alpha=0.15, linestyle='--',
            color='grey' if WHITE else 'white')
    for sp in ax.spines.values():
        sp.set_color(EDGE)
        sp.set_linewidth(1.5 if not WHITE else 0.8)


def has(key):
    """Return True if records contains a non-empty list for this key."""
    v = records.get(key)
    return isinstance(v, list) and len(v) > 0


# ─── build figure ─────────────────────────────────────────────────────────
sw = np.array(records['sweep'])
fig, axes = plt.subplots(3, 3, figsize=(20, 15))
fig.patch.set_facecolor(BG)

cut_label = f' (sweeps ≥ {args.cut_eq})' if args.cut_eq > 0 else ''
fig.suptitle(
    f'CTC SU(3) augmented action  β = {beta} — N = {N}, '
    f'α = {alpha:+.2f}, seed = {seed}{cut_label}',
    fontsize=14, fontweight='bold', color=TC, y=0.99)


# Panel (1): Plaquette
ax = axes[0, 0]
style(ax, '(1) Plaquette ⟨P⟩')
if has('plaquette'):
    ax.plot(sw, records['plaquette'], 'o-', color=BLUE, lw=2, ms=3)
ax.set_xlabel('Sweep', color=TC)


# Panel (2): Running Pearson r(⟨|Im Tr|⟩, Δ) — time-resolved decoupling.
# Replaces the original Vortex % panel, which was degenerate at strong α
# (saturated at 100% to within 1-2 plaquettes out of N⁴×6). The running
# correlation between T⁰ⁱ amplitude and Δ is the time-resolved version
# of the decoupling test shown as a scatter in panel (9). If the
# framework's central claim holds, r should fluctuate around 0 throughout
# the run rather than tracking the T⁰ⁱ trend. The final r value here
# matches the value annotated in panel (9).
ax = axes[0, 1]
style(ax, r'(2) Running r(⟨|Im Tr|⟩, Δ)  (decoupling trace)')
if has('T0i_mean') and has('mass_gap'):
    T_arr = np.asarray(records['T0i_mean'], dtype=float)
    D_arr = np.asarray(records['mass_gap'],  dtype=float)
    n = len(T_arr)
    # Sliding-window correlation: window = max(10, n // 5)
    win = max(10, n // 5)
    half = win // 2
    centers, r_vals = [], []
    for i in range(half, n - half):
        Tw = T_arr[i - half : i + half + 1]
        Dw = D_arr[i - half : i + half + 1]
        if np.std(Tw) > 1e-12 and np.std(Dw) > 1e-12:
            r_vals.append(float(np.corrcoef(Tw, Dw)[0, 1]))
            centers.append(sw[i])
    if r_vals:
        ax.axhline(0.0, color=GOLD, lw=1.0, linestyle='--', alpha=0.7,
                   label='r = 0 (decoupled)')
        ax.fill_between([sw.min(), sw.max()], -0.3, 0.3,
                        color=GOLD, alpha=0.08)
        ax.plot(centers, r_vals, 'o-', color=PURPLE, lw=2, ms=3,
                label=f'window = {win} measurements')
        # Full-run r as well, annotated at the right edge
        full_r = float(np.corrcoef(T_arr, D_arr)[0, 1])
        ax.text(0.98, 0.05,
                f'full-run r = {full_r:+.3f}',
                transform=ax.transAxes, fontsize=8, color=TC,
                horizontalalignment='right',
                family='monospace',
                bbox=dict(facecolor=PAN, edgecolor=EDGE, alpha=0.85,
                          boxstyle='round,pad=0.3'))
        ax.set_ylim(-1.05, 1.05)
        ax.legend(fontsize=7, facecolor=PAN, edgecolor=EDGE,
                  labelcolor=TC, loc='upper left')
ax.set_ylabel('Pearson r', color=TC)
ax.set_xlabel('Sweep', color=TC)


# Panel (3): Acceptance
ax = axes[0, 2]
style(ax, '(3) Acceptance')
if has('acceptance'):
    ax.plot(sw, records['acceptance'], 'o-', color=GRN, lw=2, ms=3)
    ax.axhline(0.5, color=GOLD, lw=1.5, linestyle='--', label='Target')
    ax.legend(fontsize=7, facecolor=PAN, edgecolor=EDGE, labelcolor=TC)
ax.set_xlabel('Sweep', color=TC)


# Panel (4): Z3 R/G/B color counts (the striking observation at α=1)
ax = axes[1, 0]
style(ax, '(4) Z₃ Distribution: R / G / B')
if has('n_R') and has('n_G') and has('n_B'):
    ax.plot(sw, records['n_R'], 'o-', color='#ff3333', lw=2, ms=3, label='R')
    ax.plot(sw, records['n_G'], 's-', color='#33aa33', lw=2, ms=3, label='G')
    ax.plot(sw, records['n_B'], '^-', color='#3333aa', lw=2, ms=3, label='B')
    ax.legend(fontsize=8, facecolor=PAN, edgecolor=EDGE, labelcolor=TC)
ax.set_xlabel('Sweep', color=TC)


# Panel (5): Z3 balance
ax = axes[1, 1]
style(ax, '(5) Z₃ Balance (min/max RGB)')
if has('z3_balance'):
    ax.plot(sw, records['z3_balance'], 'o-', color=GOLD, lw=2, ms=3)
    ax.axhline(0.5, color=GOLD, lw=1.5, linestyle='--', alpha=0.4,
               label='Moderate')
    ax.axhline(1.0, color=GRN, lw=1.0, linestyle=':',
               label='Z₃-symmetric')
    ax.legend(fontsize=7, facecolor=PAN, edgecolor=EDGE, labelcolor=TC)
ax.set_xlabel('Sweep', color=TC)
ax.set_ylim(0, 1.05)


# Panel (6): T⁰ⁱ mean and std (the augmented-action driver)
# Previous version drew a +/- 1σ band, but on real data σ ≈ 0.59 swamps
# the mean's actual trend amplitude (~0.02 over the run). The band is
# now replaced with a twin axis: mean on the left (purple, solid) and
# the per-site standard deviation on the right (lighter purple, dashed).
# Both quantities are preserved, neither dominates the other visually.
ax = axes[1, 2]
style(ax, r'(6) ⟨|Im Tr[P$_{0i}$]|⟩ and σ  (T⁰ⁱ amplitude)')
if has('T0i_mean'):
    m_arr = np.array(records['T0i_mean'])
    line1, = ax.plot(sw, m_arr, 'o-', color=PURPLE, lw=2, ms=3,
                    label=r'⟨|Im Tr|⟩  (mean)')
    ax.set_ylabel(r'⟨|Im Tr|⟩  (mean)', color=PURPLE)
    ax.tick_params(axis='y', labelcolor=PURPLE)
    if has('T0i_std'):
        ax_r = ax.twinx()
        s_arr = np.array(records['T0i_std'])
        PURPLE_LITE = '#cc99ee' if not WHITE else '#aa77cc'
        line2, = ax_r.plot(sw, s_arr, 's--', color=PURPLE_LITE,
                          lw=1.8, ms=3,
                          label=r'σ(|Im Tr|)  (per-site std)')
        ax_r.set_ylabel(r'σ  (per-site std)', color=PURPLE_LITE)
        ax_r.tick_params(axis='y', labelcolor=PURPLE_LITE)
        ax.legend(handles=[line1, line2], fontsize=7,
                  facecolor=PAN, edgecolor=EDGE, labelcolor=TC,
                  loc='center right')
    else:
        ax.legend(fontsize=7, facecolor=PAN, edgecolor=EDGE, labelcolor=TC)
ax.set_xlabel('Sweep', color=TC)


# Panel (7): Mass Gap Δ (the load-bearing observable)
ax = axes[2, 0]
style(ax, '(7) Mass Gap Δ')
if has('mass_gap'):
    Δ_arr = np.array(records['mass_gap'])
    err_arr = np.array(records['mass_gap_err']) if has('mass_gap_err') else np.zeros_like(Δ_arr)
    ax.errorbar(sw, Δ_arr, yerr=err_arr, fmt='o-', color=CYAN, lw=2, ms=3,
                ecolor=CYAN, elinewidth=0.8, capsize=2, alpha=0.85)
    # Annotate the equilibrium-mean value
    if len(Δ_arr) >= 4:
        eq_cut = len(Δ_arr) // 2
        Δ_eq = float(np.mean(Δ_arr[eq_cut:]))
        Δ_eq_std = float(np.std(Δ_arr[eq_cut:], ddof=1))
        ax.axhline(Δ_eq, color=GOLD, lw=1.5, linestyle='--',
                   label=f'Δ_eq = {Δ_eq:.4f} ± {Δ_eq_std:.4f}')
        ax.legend(fontsize=7, facecolor=PAN, edgecolor=EDGE, labelcolor=TC)
ax.set_xlabel('Sweep', color=TC)


# Panel (8): n_cores (eddy core count)
ax = axes[2, 1]
style(ax, '(8) Eddy Core Count')
if has('n_cores'):
    ax.plot(sw, records['n_cores'], 'o-', color=ORG, lw=2, ms=3)
ax.set_xlabel('Sweep', color=TC)


# Panel (9): Δ vs ⟨|Im Tr|⟩ — the load-bearing decoupling plot.
# Previous version plotted Δ vs sweep and ⟨|Im Tr|⟩ vs sweep on twin
# axes, which is two time series and NOT a decoupling test. The proper
# decoupling test scatters Δ directly against ⟨|Im Tr|⟩ to show whether
# they covary. Points are coloured by sweep number so the temporal
# evolution is preserved.
ax = axes[2, 2]
style(ax, r'(9) Δ vs ⟨|Im Tr|⟩  (decoupling test)')
if has('mass_gap') and has('T0i_mean'):
    Δ_arr = np.asarray(records['mass_gap'], dtype=float)
    T_arr = np.asarray(records['T0i_mean'], dtype=float)
    sw_arr = np.asarray(records['sweep'], dtype=float)
    sc = ax.scatter(T_arr, Δ_arr, c=sw_arr, cmap='plasma',
                    s=42, edgecolors=EDGE, linewidths=0.6, zorder=3)
    cb = fig.colorbar(sc, ax=ax, pad=0.02, shrink=0.85)
    cb.set_label('Sweep', color=TC, fontsize=8)
    cb.ax.tick_params(colors=TC, labelsize=7)
    # Horizontal reference: equilibrium-mean Δ (using late half of records)
    if len(Δ_arr) >= 4:
        eq_cut = len(Δ_arr) // 2
        Δ_eq = float(np.mean(Δ_arr[eq_cut:]))
        Δ_eq_std = float(np.std(Δ_arr[eq_cut:], ddof=1))
        ax.axhline(Δ_eq, color=GOLD, lw=1.5, linestyle='--',
                   label=f'Δ_eq = {Δ_eq:.4f} ± {Δ_eq_std:.4f}')
        ax.axhspan(Δ_eq - Δ_eq_std, Δ_eq + Δ_eq_std,
                   color=GOLD, alpha=0.10)
        ax.legend(fontsize=7, loc='best',
                  facecolor=PAN, edgecolor=EDGE, labelcolor=TC)
    # Correlation coefficient as a quick decoupling diagnostic
    if len(T_arr) >= 5 and np.std(T_arr) > 0:
        r = float(np.corrcoef(T_arr, Δ_arr)[0, 1])
        ax.text(0.04, 0.95,
                f'Pearson r(⟨|Im Tr|⟩, Δ) = {r:+.3f}',
                transform=ax.transAxes, fontsize=8, color=TC,
                verticalalignment='top', family='monospace',
                bbox=dict(facecolor=PAN, edgecolor=EDGE, alpha=0.85,
                          boxstyle='round,pad=0.3'))
ax.set_xlabel(r'⟨|Im Tr[P$_{0i}$]|⟩', color=TC)
ax.set_ylabel('Δ  (lattice units)', color=TC)

plt.tight_layout()


# ─── save ────────────────────────────────────────────────────────────────
cut_suffix = f'_eq{args.cut_eq}' if args.cut_eq > 0 else ''
# α tag for filename (matches the convention used in figure1_from_U.py)
if alpha < 0.0:
    alpha_tag = f'_am{abs(alpha):.2f}'
elif alpha > 0.0:
    alpha_tag = f'_a{alpha:.2f}'
else:
    alpha_tag = '_a0.00'
out_png = os.path.join(
    outdir,
    f'dashboard_lite_N{N}_b{beta:.1f}{alpha_tag}_s{seed}{cut_suffix}.png')
plt.savefig(out_png, dpi=args.dpi, bbox_inches='tight', facecolor=BG)
plt.close()
print(f"\nSaved: {out_png}  ({os.path.getsize(out_png) // 1024} KB)")
print('Done.')
