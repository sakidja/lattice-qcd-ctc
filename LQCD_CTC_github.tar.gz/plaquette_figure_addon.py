#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
plaquette_figure_addon.py

Figure + CSV companion to su3_plaquette_validation.py.

Produces a multi-panel figure with:
  (a) <P> per-config trace with ensemble mean and Wilson benchmark
  (b) spatial-spatial vs temporal-spatial <P> per config (symmetry check)
  (c) Polyakov loop magnitude per config
  (d) per-site plaquette distribution histogram (all configs combined)
"""

from __future__ import annotations
import csv
import numpy as np


PLAQ_BENCH = {5.7: 0.549, 5.8: 0.567, 6.0: 0.594, 6.2: 0.614}


def write_plaquette_figure(rc, results, out_png='plaq.png',
                           out_csv='plaq.csv'):
    plaqs    = results['plaqs']
    plaqs_ss = results['plaqs_ss']
    plaqs_st = results['plaqs_st']
    polyakov = results['polyakov']
    per_site = results['per_site_all']

    pm  = float(plaqs.mean())
    pe  = float(plaqs.std()) if len(plaqs) > 1 else 0.0
    pms = float(plaqs_ss.mean()); pes = float(plaqs_ss.std()) if len(plaqs_ss) > 1 else 0.0
    pmt = float(plaqs_st.mean()); pet = float(plaqs_st.std()) if len(plaqs_st) > 1 else 0.0
    lm  = float(polyakov.mean()); le  = float(polyakov.std()) if len(polyakov) > 1 else 0.0
    pb  = PLAQ_BENCH.get(rc.beta, float('nan'))

    with open(out_csv, 'w', newline='') as f:
        w = csv.writer(f)
        w.writerow(['config', 'plaq', 'plaq_ss', 'plaq_st', 'polyakov_abs'])
        for i in range(len(plaqs)):
            w.writerow([i + 1,
                        f'{plaqs[i]:.5f}',
                        f'{plaqs_ss[i]:.5f}',
                        f'{plaqs_st[i]:.5f}',
                        f'{polyakov[i]:.5f}'])
        w.writerow([])
        w.writerow(['summary', 'mean', 'std'])
        w.writerow(['plaq',         f'{pm:.5f}',  f'{pe:.5f}'])
        w.writerow(['plaq_ss',      f'{pms:.5f}', f'{pes:.5f}'])
        w.writerow(['plaq_st',      f'{pmt:.5f}', f'{pet:.5f}'])
        w.writerow(['polyakov_abs', f'{lm:.5f}',  f'{le:.5f}'])
        w.writerow(['wilson_benchmark', f'{pb:.3f}'])
        w.writerow(['delta_plaq', f'{pm - pb:+.5f}'])

    try:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
    except ImportError:
        print(f'  CSV written: {out_csv}')
        return

    cfg = np.arange(1, len(plaqs) + 1)

    fig = plt.figure(figsize=(14, 9))
    gs = fig.add_gridspec(3, 2, hspace=0.42, wspace=0.28)

    fig.suptitle(
        f'SU(3) Wilson measurements  '
        f'(beta = {rc.beta},  L^3 x T = {rc.L}^3 x {rc.T},  '
        f'n_conf = {rc.n_conf})',
        fontsize=12, y=0.995)

    # (a) <P> per config
    ax_a = fig.add_subplot(gs[0, :])
    ax_a.plot(cfg, plaqs, 'o-', color='#1f4e8c', markersize=7,
              linewidth=1.5, label='measured per-config <P>')
    ax_a.axhline(pm, color='#1f4e8c', linewidth=1.2, alpha=0.65,
                 label=f'ensemble mean = {pm:.4f} +/- {pe:.4f}')
    ax_a.fill_between(cfg, pm - pe, pm + pe, color='#1f4e8c', alpha=0.12)
    ax_a.axhline(pb, color='#c0392b', linestyle='--', linewidth=2,
                 label=f'Wilson benchmark = {pb:.3f}')
    ax_a.set_xlabel('configuration index')
    ax_a.set_ylabel(r'$\langle P \rangle$')
    ax_a.set_title('(a) equilibrium mean plaquette per configuration',
                   fontsize=11)
    ax_a.grid(alpha=0.3); ax_a.legend(fontsize=9, loc='best')

    # (b) spatial-spatial vs temporal-spatial
    ax_b = fig.add_subplot(gs[1, 0])
    ax_b.plot(cfg, plaqs_ss, 'o-', color='#1f4e8c', markersize=6,
              linewidth=1.3, label=f'<P_ss> = {pms:.4f}')
    ax_b.plot(cfg, plaqs_st, 's-', color='#c97e2a', markersize=6,
              linewidth=1.3, label=f'<P_st> = {pmt:.4f}')
    ax_b.set_xlabel('configuration index')
    ax_b.set_ylabel(r'$\langle P \rangle$')
    ax_b.set_title('(b) spatial-spatial vs temporal-spatial planes',
                   fontsize=10)
    ax_b.grid(alpha=0.3); ax_b.legend(fontsize=9)

    # (c) Polyakov loop magnitude
    ax_c = fig.add_subplot(gs[1, 1])
    ax_c.plot(cfg, polyakov, 'o-', color='#2e7d4f', markersize=6,
              linewidth=1.3, label=f'<|L|> = {lm:.4f} +/- {le:.4f}')
    ax_c.axhline(lm, color='#2e7d4f', linewidth=1.0, alpha=0.5)
    ax_c.fill_between(cfg, lm - le, lm + le, color='#2e7d4f', alpha=0.12)
    ax_c.set_xlabel('configuration index')
    ax_c.set_ylabel(r'$\langle |L| \rangle$')
    ax_c.set_title('(c) Polyakov loop magnitude per configuration',
                   fontsize=10)
    ax_c.grid(alpha=0.3); ax_c.legend(fontsize=9)

    # (d) per-site plaquette distribution
    ax_d = fig.add_subplot(gs[2, :])
    ax_d.hist(per_site, bins=60, color='#1f4e8c', alpha=0.75,
              edgecolor='white', linewidth=0.3)
    ax_d.axvline(pm, color='#c0392b', linestyle='--', linewidth=1.5,
                 label=f'mean = {pm:.4f}')
    ax_d.set_xlabel(r'per-site $\mathrm{Re\,Tr}\,P / 3$')
    ax_d.set_ylabel('count')
    ax_d.set_title(f'(d) per-site plaquette distribution  '
                   f'(N = {len(per_site)})', fontsize=10)
    ax_d.grid(alpha=0.3); ax_d.legend(fontsize=9)

    plt.tight_layout()
    plt.savefig(out_png, dpi=140, bbox_inches='tight')
    plt.close(fig)
    print(f'  CSV written:    {out_csv}')
    print(f'  Figure written: {out_png}')
