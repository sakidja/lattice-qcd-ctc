#!/usr/bin/env python3
"""
check_div_epsilon.py — Diagnostic for the +1e-6 softening in ctc_T0i_action_save_v4.py

Question: did the `+1e-6` in `div = div/len(PLANES) + 1e-6` ever bind on any
production config? If `min(div) >> 1e-6` everywhere and the core set is
unchanged when the epsilon is removed, the alpha-scan figure is unaffected.

USAGE:
  python3 check_div_epsilon.py U_final_N24_b5.8_a0.60_s42.npy

OUTPUT:
  - Distribution statistics of div (without epsilon)
  - Counts of sites below several small thresholds
  - Maximum |mass_with_eps - mass_without_eps| above floating-point noise
  - Core-set comparison: are the identified cores the same with and without?
  - For each core: its actual div value (so you can see if any core sits near eps)
"""

import sys
import numpy as np
from scipy.ndimage import maximum_filter

if len(sys.argv) != 2:
    print("Usage: check_div_epsilon.py <U_final_*.npy>")
    sys.exit(1)

U_path = sys.argv[1]
U = np.load(U_path)
N = U.shape[1]
print(f"Loaded {U_path}")
print(f"  shape={U.shape}  dtype={U.dtype}  N={N}")

PLANES = [(0,1),(0,2),(0,3),(1,2),(1,3),(2,3)]

def plaq(U, mu, nu):
    P = U[mu] @ np.roll(U[nu], -1, axis=mu)
    P = P @ np.roll(U[mu], -1, axis=nu).conj().swapaxes(-1, -2)
    return P @ U[nu].conj().swapaxes(-1, -2)

# Recompute curv and div from scratch, NO epsilon
curv = np.zeros((N, N, N, N))
div_raw = np.zeros((N, N, N, N))
cent = np.zeros((N, N, N, N), dtype=int)

for mu, nu in PLANES:
    P = plaq(U, mu, nu)
    trP = np.real(np.trace(P, axis1=-2, axis2=-1))
    curv += np.arccos(np.clip(trP/3.0, -1.0, 1.0))
    cent += (trP < 1.0).astype(int)
    for rho in range(4):
        if rho == mu or rho == nu:
            continue
        Pf = np.roll(P, -1, axis=rho)
        T = U[rho] @ Pf @ U[rho].conj().swapaxes(-1, -2)
        div_raw += np.sqrt(np.sum(np.abs(P - T)**2, axis=(-2, -1)))

curv /= len(PLANES)
div_raw /= len(PLANES)  # WITHOUT the +1e-6
center_charge = np.where(cent > 0, 1, -1)

print("\n=== div distribution (WITHOUT epsilon) ===")
print(f"  min      = {div_raw.min():.3e}")
print(f"  max      = {div_raw.max():.3e}")
print(f"  mean     = {div_raw.mean():.3e}")
print(f"  median   = {np.median(div_raw):.3e}")
print(f"  percentile 0.001% = {np.percentile(div_raw, 0.001):.3e}")
print(f"  percentile 0.01%  = {np.percentile(div_raw, 0.01):.3e}")
print(f"  percentile 0.1%   = {np.percentile(div_raw, 0.1):.3e}")
print(f"  percentile 1%     = {np.percentile(div_raw, 1):.3e}")

print("\n=== Sites where div is small ===")
for thresh in [1e-3, 1e-4, 1e-5, 1e-6, 1e-7]:
    n_below = int(np.sum(div_raw < thresh))
    pct = 100.0 * n_below / div_raw.size
    print(f"  div < {thresh:.0e}: {n_below:>10d} sites ({pct:.4f}%)")

# Compute mass two ways
mass_with_eps = curv / (div_raw + 1e-6)
# Without eps: keep mass finite where div is identically zero, but flag it
mass_no_eps = np.where(div_raw > 0, curv / np.where(div_raw > 0, div_raw, 1.0), np.inf)

print("\n=== Effect of epsilon on mass field ===")
n_zero = int(np.sum(div_raw == 0))
print(f"  Sites where div is exactly 0: {n_zero}")

# Compare on finite values
finite_mask = np.isfinite(mass_no_eps)
diff = np.abs(mass_with_eps[finite_mask] - mass_no_eps[finite_mask])
rel_diff = diff / np.abs(mass_no_eps[finite_mask] + 1e-30)
print(f"  Max absolute |mass_with_eps - mass_no_eps| on finite sites: {diff.max():.3e}")
print(f"  Max relative difference:                                    {rel_diff.max():.3e}")
print(f"  Sites with rel_diff > 1%:    {int(np.sum(rel_diff > 0.01))}")
print(f"  Sites with rel_diff > 0.1%:  {int(np.sum(rel_diff > 0.001))}")
print(f"  Sites with rel_diff > 0.01%: {int(np.sum(rel_diff > 0.0001))}")

# Core identification with and without epsilon
def find_cores(mass, center_charge, peak_radius=2):
    local_max = (mass == maximum_filter(mass, size=peak_radius*2+1))
    return np.argwhere(local_max & (center_charge == 1))

# For find_cores we need a finite mass field; use a sentinel for true div=0
mass_no_eps_for_peaks = np.where(div_raw > 0,
                                  curv / np.where(div_raw > 0, div_raw, 1.0),
                                  0.0)  # 0 won't be a local max, harmless

cores_with = find_cores(mass_with_eps, center_charge)
cores_without = find_cores(mass_no_eps_for_peaks, center_charge)

print("\n=== Core identification ===")
print(f"  Cores found WITH epsilon:    {len(cores_with)}")
print(f"  Cores found WITHOUT epsilon: {len(cores_without)}")

set_with = set(map(tuple, cores_with))
set_without = set(map(tuple, cores_without))
only_with = set_with - set_without
only_without = set_without - set_with
shared = set_with & set_without

print(f"  Shared cores:               {len(shared)}")
print(f"  Only with epsilon (lost if removed): {len(only_with)}")
print(f"  Only without epsilon (gained if removed): {len(only_without)}")

print("\n=== div values AT identified cores (with epsilon) ===")
if len(cores_with) > 0:
    core_divs = np.array([div_raw[tuple(c)] for c in cores_with])
    print(f"  min div at a core:    {core_divs.min():.3e}")
    print(f"  max div at a core:    {core_divs.max():.3e}")
    print(f"  median div at a core: {np.median(core_divs):.3e}")
    print(f"  Cores with div < 1e-3: {int(np.sum(core_divs < 1e-3))}")
    print(f"  Cores with div < 1e-4: {int(np.sum(core_divs < 1e-4))}")
    print(f"  Cores with div < 1e-5: {int(np.sum(core_divs < 1e-5))}")
    print(f"  Cores with div < 1e-6: {int(np.sum(core_divs < 1e-6))}")

print("\n=== Verdict ===")
if div_raw.min() > 1e-3:
    print("  CLEAN: min(div) is well above 1e-6 across the entire lattice.")
    print("  The +1e-6 epsilon never bound. Paper numbers are unaffected.")
elif len(only_with) == 0 and len(only_without) == 0:
    print("  CLEAN: the epsilon affects some mass values but the core set is")
    print("  identical with and without. The alpha-scan figure is unaffected.")
else:
    print("  ATTENTION: the core set changes when the epsilon is removed.")
    print(f"  {len(only_with)} cores lost, {len(only_without)} gained.")
    print("  This config's alpha-scan contribution may need re-evaluation.")
