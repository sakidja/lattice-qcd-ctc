#!/usr/bin/env python3
"""
cp_test.py
==========
CP-symmetry verification for the framework's augmented action.

Runs TWO complementary CP checks on a saved equilibrated link-field
configuration U_final_*.npy:

(A) ALGEBRAIC per-site identity check.
    Under charge conjugation  U -> U*  (link by link):
        v_i(x)  = Im Tr P_{0,i}(x)   ->  -v_i(x)   (CP-odd)
        T^2(x)  = sum_i v_i(x)^2     ->  +T^2(x)   (CP-even)
    Verifies the two identities at every site:
        max |v_i(x) + v_i^C(x)|  <  tol     (CP-odd residual)
        max |T^2(x) - T^2_C(x)|  <  tol     (CP-even residual)
    These should pass at machine epsilon (~ 1e-15) regardless of basin
    because CP-evenness of the augmented term  alpha (Im Tr P_{0,i})^2
    is an algebraic property of the action, not a dynamical one.

(B) STATISTICAL ensemble check.
    Computes the per-site signed mean  <Im Tr P_{0,i}>  over all 3*N^4
    site evaluations of the configuration and reports
        mean, SEM, |mean|/SEM significance, sigma, sigma^2, skewness
    both COMBINED across the three temporal-spatial planes (this is
    what Tables S3b and S3c of the manuscript report row-by-row) and
    PER CHANNEL (R, G, B). Verdict is "Consistent" if |mean|/SEM is
    below the threshold tol_stat (default 3.0 standard deviations
    from zero). The variance sigma^2 is the topology-protected
    quantity bounded below by the Helmholtz argument of Section S6.

(A) verifies the augmented term's algebraic CP identity at the per-site
    level (deductive: should pass on any configuration).
(B) verifies the equilibrium ensemble respects CP empirically (the
    physically substantive claim: ties to the neutron EDM bound).

Outputs per configuration:
    cp_test_<TAG>.png    nine-panel diagnostic figure
    cp_test_<TAG>.json   numerical summary of both tests

Usage:
    python3 cp_test.py U_final_<TAG>.npy
    python3 cp_test.py U_final_<TAG>.npy --outdir results --tol 1e-10 --tol_stat 3.0
"""

import argparse, os, re, sys, json, warnings
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
warnings.filterwarnings('ignore')

# =========================================================================
# CLI
# =========================================================================
ap = argparse.ArgumentParser()
ap.add_argument('u_file', help='U_final_*.npy path')
ap.add_argument('--outdir', default='.', help='Output directory')
ap.add_argument('--tol', type=float, default=1e-10,
                help='Algebraic CP tolerance for declaring identity '
                     'preserved (default 1e-10)')
ap.add_argument('--tol_stat', type=float, default=3.0,
                help='Statistical CP tolerance in sigma units '
                     '(default 3.0)')
args = ap.parse_args()

if not os.path.isfile(args.u_file):
    sys.exit(f'ERROR: not found: {args.u_file}')

print(f'Loading {args.u_file} ...')
U = np.load(args.u_file)
m_meta = re.search(r'N(\d+)_b([\d.]+)_(?:a([\d.]+)_)?s(\d+)',
                   os.path.basename(args.u_file))
if not m_meta:
    sys.exit('ERROR: could not parse metadata')
N = int(m_meta.group(1)); beta = float(m_meta.group(2))
alpha = float(m_meta.group(3)) if m_meta.group(3) is not None else 0.0
seed = int(m_meta.group(4))
basin = 'Wilson' if alpha == 0.0 else f'Augmented (alpha={alpha})'
TAG = f'N{N}_b{beta:.1f}_a{alpha:.2f}_s{seed}'
print(f'  N={N}, beta={beta}, alpha={alpha} ({basin}), seed={seed}')


TEMPORAL = [(0,1),(0,2),(0,3)]   # R, G, B = (t,x), (t,y), (t,z)


# =========================================================================
# CORE FUNCTIONS
# =========================================================================

def plaq(U, mu, nu):
    """Plaquette P_{mu nu}(x) = U_mu(x) U_nu(x+mu) U_mu(x+nu)^+ U_nu(x)^+."""
    P = U[mu] @ np.roll(U[nu], -1, axis=mu)
    P = P @ np.roll(U[mu], -1, axis=nu).conj().swapaxes(-1, -2)
    return P @ U[nu].conj().swapaxes(-1, -2)


def compute_v_signed(U):
    """Returns signed Im Tr P_{0,i} for i = 1, 2, 3 (R, G, B channels)."""
    out = []
    for (mu, nu) in TEMPORAL:
        P = plaq(U, mu, nu)
        out.append(np.imag(np.trace(P, axis1=-2, axis2=-1)))
    return out


def sample_skewness(x):
    """Third standardised moment of a 1D sample. Returns 0 if sigma==0."""
    x = np.asarray(x).flatten()
    mu = float(x.mean())
    sg = float(x.std(ddof=0))
    if sg == 0:
        return 0.0
    return float(np.mean((x - mu)**3) / sg**3)


def stats_block(x, label=''):
    """Returns dict with n, mean, SEM, |m|/SEM, sigma, sigma^2, skew."""
    x = np.asarray(x).flatten()
    n  = int(x.size)
    mu = float(x.mean())
    sg = float(x.std(ddof=0))
    sem = sg / np.sqrt(n) if n > 0 else 0.0
    sig = abs(mu) / sem if sem > 0 else 0.0
    sk  = sample_skewness(x)
    return {'label': label, 'n': n, 'mean': mu, 'sem': sem,
            'sig': sig, 'sigma': sg, 'sigma2': sg*sg, 'skew': sk}


# =========================================================================
# COMPUTE: ORIGINAL AND CHARGE-CONJUGATED CONFIGURATIONS
# =========================================================================
print('\nComputing original v_R, v_G, v_B ...')
v_R, v_G, v_B = compute_v_signed(U)
T2_original = v_R**2 + v_G**2 + v_B**2

# C: U -> U*  (complex conjugate, link by link)
print('Computing charge-conjugated v_R^C, v_G^C, v_B^C ...')
U_C = U.conj()
v_R_C, v_G_C, v_B_C = compute_v_signed(U_C)
T2_C = v_R_C**2 + v_G_C**2 + v_B_C**2


# =========================================================================
# TEST (A1): CP-odd algebraic identity  v + v^C = 0
# =========================================================================
print('\n===== TEST (A1): CP-odd algebraic identity  v + v^C = 0 =====')
resid_R = np.abs(v_R + v_R_C)
resid_G = np.abs(v_G + v_G_C)
resid_B = np.abs(v_B + v_B_C)
max_resid_R = float(resid_R.max())
max_resid_G = float(resid_G.max())
max_resid_B = float(resid_B.max())
max_resid   = max(max_resid_R, max_resid_G, max_resid_B)

print(f'  max |v_R + v_R^C|:  {max_resid_R:.3e}')
print(f'  max |v_G + v_G^C|:  {max_resid_G:.3e}')
print(f'  max |v_B + v_B^C|:  {max_resid_B:.3e}')
print(f'  overall max:         {max_resid:.3e}    tolerance = {args.tol:.0e}')
a1_pass = (max_resid < args.tol)
print(f'  Verdict: {"PASS (CP-odd preserved)" if a1_pass else "FAIL (CP violation detected)"}')


# =========================================================================
# TEST (A2): CP-even algebraic identity  T^2 = T^2_C
# =========================================================================
print('\n===== TEST (A2): CP-even algebraic identity  T^2 = T^2_C =====')
diff_T2 = np.abs(T2_original - T2_C)
max_diff_T2 = float(diff_T2.max())
print(f'  max |T^2 - T^2_C|:   {max_diff_T2:.3e}    tolerance = {args.tol:.0e}')
a2_pass = (max_diff_T2 < args.tol)
print(f'  Verdict: {"PASS (CP-even preserved)" if a2_pass else "FAIL"}')


# =========================================================================
# LATTICE SUMS (Sigma v flips sign under C, Sigma T^2 is preserved)
# =========================================================================
print('\n===== LATTICE SUMS =====')
sum_R   = float(v_R.sum());   sum_R_C = float(v_R_C.sum())
sum_G   = float(v_G.sum());   sum_G_C = float(v_G_C.sum())
sum_B   = float(v_B.sum());   sum_B_C = float(v_B_C.sum())
sum_T2  = float(T2_original.sum())
sum_T2_C = float(T2_C.sum())

print(f'  Sigma v_R   = {sum_R:+12.4f}    Sigma v_R^C  = {sum_R_C:+12.4f}    '
      f'expected sign flip')
print(f'  Sigma v_G   = {sum_G:+12.4f}    Sigma v_G^C  = {sum_G_C:+12.4f}')
print(f'  Sigma v_B   = {sum_B:+12.4f}    Sigma v_B^C  = {sum_B_C:+12.4f}')
print(f'  Sigma T^2   = {sum_T2:+12.4f}   Sigma T^2_C  = {sum_T2_C:+12.4f}   '
      f'expected equal')


# =========================================================================
# TEST (B): STATISTICAL ENSEMBLE CHECK  <Im Tr P_{0,i}> consistent with 0
# =========================================================================
print('\n===== TEST (B): Statistical ensemble check  <Im Tr P_{0,i}> = 0 =====')

# Per-channel statistics
stat_R = stats_block(v_R, 'R: Im Tr P_{0,1}')
stat_G = stats_block(v_G, 'G: Im Tr P_{0,2}')
stat_B = stats_block(v_B, 'B: Im Tr P_{0,3}')

# Combined across all three temporal-spatial planes
# (this is what Tables S3b and S3c of the manuscript report)
combined = np.concatenate([v_R.flatten(), v_G.flatten(), v_B.flatten()])
stat_combined = stats_block(combined, 'combined (R+G+B)')

def fmt_row(s):
    return (f"  {s['label']:24s}  n={s['n']:>10d}  "
            f"mean={s['mean']:+11.4e}  SEM={s['sem']:.3e}  "
            f"|m|/SEM={s['sig']:5.2f}s  sigma={s['sigma']:.4f}  "
            f"sigma^2={s['sigma2']:.4f}  skew={s['skew']:+.4f}")

print(fmt_row(stat_R))
print(fmt_row(stat_G))
print(fmt_row(stat_B))
print(fmt_row(stat_combined))

b_pass_R = stat_R['sig'] < args.tol_stat
b_pass_G = stat_G['sig'] < args.tol_stat
b_pass_B = stat_B['sig'] < args.tol_stat
b_pass_combined = stat_combined['sig'] < args.tol_stat
b_pass = b_pass_R and b_pass_G and b_pass_B and b_pass_combined

print(f'\n  Per-channel  R: {"Consistent" if b_pass_R else "FAIL"} '
      f'({stat_R["sig"]:.2f}sigma < {args.tol_stat:.1f}sigma)')
print(f'  Per-channel  G: {"Consistent" if b_pass_G else "FAIL"} '
      f'({stat_G["sig"]:.2f}sigma < {args.tol_stat:.1f}sigma)')
print(f'  Per-channel  B: {"Consistent" if b_pass_B else "FAIL"} '
      f'({stat_B["sig"]:.2f}sigma < {args.tol_stat:.1f}sigma)')
print(f'  Combined R+G+B: {"Consistent" if b_pass_combined else "FAIL"} '
      f'({stat_combined["sig"]:.2f}sigma < {args.tol_stat:.1f}sigma)')


# =========================================================================
# FIGURE  (3x3 grid covering both tests)
# =========================================================================
print('\nBuilding figure ...')
fig = plt.figure(figsize=(16, 13))
gs  = fig.add_gridspec(3, 3, hspace=0.55, wspace=0.36)

# --- Row 1: per-channel signed v distributions with statistical annotations
v_max_abs = max(np.percentile(np.abs(v_R), 99.5),
                np.percentile(np.abs(v_G), 99.5),
                np.percentile(np.abs(v_B), 99.5))
bins = np.linspace(-v_max_abs * 1.05, v_max_abs * 1.05, 60)

for k, (label, v_orig, v_conj, stat, col) in enumerate(
    [('R: v_R = Im Tr P_{0,1}', v_R, v_R_C, stat_R, '#d62728'),
     ('G: v_G = Im Tr P_{0,2}', v_G, v_G_C, stat_G, '#2ca02c'),
     ('B: v_B = Im Tr P_{0,3}', v_B, v_B_C, stat_B, '#1f77b4')]):
    ax = fig.add_subplot(gs[0, k])
    ax.hist(v_orig.flatten(), bins=bins, alpha=0.45, color=col,
            density=True, label='original v')
    ax.hist(-v_conj.flatten(), bins=bins, alpha=0.45, color=col,
            density=True, histtype='step', lw=2,
            label='-v^C (charge-conj)')
    ax.set_yscale('log')
    ax.set_xlabel('value'); ax.set_ylabel('density')
    ax.axvline(0, color='black', lw=0.5)
    ax.axvline(stat['mean'], color=col, lw=1.2, linestyle='--')
    ax.legend(fontsize=7, loc='upper right')
    ax.grid(True, alpha=0.3)
    stat_text = (f"n        = {stat['n']:,}\n"
                 f"mean     = {stat['mean']:+.2e}\n"
                 f"SEM      = {stat['sem']:.2e}\n"
                 f"|m|/SEM  = {stat['sig']:.2f}s\n"
                 f"sigma    = {stat['sigma']:.4f}\n"
                 f"sigma^2  = {stat['sigma2']:.4f}\n"
                 f"skew     = {stat['skew']:+.4f}")
    ax.text(0.02, 0.97, stat_text, transform=ax.transAxes,
            fontsize=7, family='monospace', verticalalignment='top',
            bbox=dict(facecolor='white', edgecolor=col, alpha=0.9,
                      boxstyle='round,pad=0.3'))
    ax.set_title(f'{label}\nsigned distribution (statistical test, per channel)',
                 fontsize=9, fontweight='bold')

# --- Row 2: per-site algebraic residuals (CP-odd identity, per channel)
for k, (label, resid, col) in enumerate(
    [('R: v_R + v_R^C', resid_R.flatten(), '#d62728'),
     ('G: v_G + v_G^C', resid_G.flatten(), '#2ca02c'),
     ('B: v_B + v_B^C', resid_B.flatten(), '#1f77b4')]):
    ax = fig.add_subplot(gs[1, k])
    if resid.max() == 0:
        ax.axvline(0, color=col, lw=4)
        ax.set_xlim(-1e-15, 1e-15)
        ax.set_ylim(0.5, len(resid) * 2)
        ax.text(0.5, 0.5,
                f'all {len(resid):,} sites\nexactly 0',
                transform=ax.transAxes,
                ha='center', va='center', fontsize=12, fontweight='bold',
                bbox=dict(facecolor='white', edgecolor=col,
                          alpha=0.95, boxstyle='round,pad=0.5'))
    else:
        ax.hist(resid, bins=60, color=col, edgecolor='black', alpha=0.8)
    ax.set_yscale('log')
    ax.set_xlabel('per-site |residual|')
    ax.set_ylabel('count (log)')
    ax.set_title(f'{label}\nmax|residual| = {resid.max():.2e}  '
                 f'(algebraic CP-odd identity)',
                 fontsize=9, fontweight='bold')
    ax.grid(True, alpha=0.3)

# --- Row 3 col 0: T^2 distributions (algebraic CP-even check)
ax = fig.add_subplot(gs[2, 0])
T2_max = np.percentile(T2_original, 99.5)
bins_T = np.linspace(0, T2_max * 1.05, 60)
ax.hist(T2_original.flatten(), bins=bins_T, alpha=0.55,
        color='#ff7f0e', density=True,
        label=f'original T^2\nmean={T2_original.mean():.4f}')
ax.hist(T2_C.flatten(), bins=bins_T, histtype='step', lw=2.5,
        color='black', density=True,
        label=f'charge-conj T^2_C\nmean={T2_C.mean():.4f}')
ax.set_yscale('log')
ax.set_xlabel('T^2 value'); ax.set_ylabel('density')
ax.legend(fontsize=7); ax.grid(True, alpha=0.3)
ax.set_title(f'T^2 (algebraic CP-even)\n'
             f'max |T^2 - T^2_C| = {max_diff_T2:.2e}',
             fontsize=9, fontweight='bold')

# --- Row 3 col 1: COMBINED signed v histogram across all three channels
ax = fig.add_subplot(gs[2, 1])
ax.hist(combined, bins=bins, color='#4d4dff', alpha=0.65, density=True,
        edgecolor='black', linewidth=0.5)
ax.axvline(0, color='black', lw=0.7)
ax.axvline(stat_combined['mean'], color='red', lw=1.5, linestyle='--',
           label=f"mean = {stat_combined['mean']:+.2e}")
ax.set_yscale('log')
ax.set_xlabel('Im Tr P_{0,i}  (combined R+G+B)')
ax.set_ylabel('density')
ax.legend(fontsize=7)
ax.grid(True, alpha=0.3)
stat_text = (f"n         = {stat_combined['n']:,}\n"
             f"mean      = {stat_combined['mean']:+.2e}\n"
             f"SEM       = {stat_combined['sem']:.3e}\n"
             f"|m|/SEM   = {stat_combined['sig']:.2f}s\n"
             f"sigma     = {stat_combined['sigma']:.4f}\n"
             f"sigma^2   = {stat_combined['sigma2']:.4f}\n"
             f"skew      = {stat_combined['skew']:+.4f}\n"
             f"verdict   = {'Consistent' if b_pass_combined else 'FAIL'}")
ax.text(0.02, 0.97, stat_text, transform=ax.transAxes,
        fontsize=7, family='monospace', verticalalignment='top',
        bbox=dict(facecolor='white', edgecolor='#4d4dff', alpha=0.9,
                  boxstyle='round,pad=0.3'))
ax.set_title(f'Combined signed Im Tr P_{{0,i}}\n'
             f'(statistical CP-odd, ensemble check)',
             fontsize=9, fontweight='bold')

# --- Row 3 col 2: summary text panel covering BOTH tests
ax = fig.add_subplot(gs[2, 2])
ax.axis('off')
text  = 'CP-PRESERVATION SUMMARY\n'
text += '=' * 38 + '\n\n'
text += f'Configuration:\n'
text += f'  N={N}  beta={beta}  alpha={alpha}\n'
text += f'  basin={basin}\n'
text += f'  seed={seed}\n\n'

text += '(A) ALGEBRAIC CP IDENTITIES\n'
text += '-' * 38 + '\n'
text += f'CP-odd  max|v + v^C|:\n'
text += f'  R={max_resid_R:.2e}  G={max_resid_G:.2e}\n'
text += f'  B={max_resid_B:.2e}\n'
text += f'  all={max_resid:.2e}\n'
text += f'CP-even max|T^2 - T^2_C|:\n'
text += f'  {max_diff_T2:.2e}\n'
text += f'tol = {args.tol:.0e}\n'
text += f'verdict: {"PASS" if (a1_pass and a2_pass) else "FAIL"}\n\n'

text += '(B) STATISTICAL ENSEMBLE\n'
text += '-' * 38 + '\n'
text += f'<Im Tr P_{{0,i}}> consistent with 0?\n'
text += f'  R:  |m|/SEM = {stat_R["sig"]:.2f}s\n'
text += f'  G:  |m|/SEM = {stat_G["sig"]:.2f}s\n'
text += f'  B:  |m|/SEM = {stat_B["sig"]:.2f}s\n'
text += f'  combined:   {stat_combined["sig"]:.2f}s\n'
text += f'sigma^2 (comb) = {stat_combined["sigma2"]:.4f}\n'
text += f'skew    (comb) = {stat_combined["skew"]:+.4f}\n'
text += f'tol = {args.tol_stat:.1f}s\n'
text += f'verdict: {"Consistent" if b_pass else "FAIL"}\n\n'

text += 'OVERALL\n'
text += '-' * 38 + '\n'
overall_pass = a1_pass and a2_pass and b_pass
text += f'{"ALL TESTS PASS" if overall_pass else "FAILURE DETECTED"}\n'
ax.text(0.0, 1.0, text, fontsize=9, family='monospace',
        verticalalignment='top', transform=ax.transAxes)

fig.suptitle(
    f'CP-symmetry verification: algebraic identity + statistical ensemble  '
    f'(N={N}, beta={beta}, alpha={alpha}, {basin})',
    fontsize=13, fontweight='bold', y=0.998
)

plot_path = os.path.join(args.outdir, f'cp_test_{TAG}.png')
plt.tight_layout()
plt.savefig(plot_path, dpi=140, bbox_inches='tight')
plt.close()
print(f'\nFigure: {plot_path}')


# =========================================================================
# JSON
# =========================================================================
json_path = os.path.join(args.outdir, f'cp_test_{TAG}.json')
with open(json_path, 'w') as f:
    json.dump({
        'N': N, 'beta': beta, 'alpha': alpha, 'seed': seed, 'basin': basin,
        'tolerance_algebraic': float(args.tol),
        'tolerance_statistical_sigma': float(args.tol_stat),
        'algebraic_cp_test': {
            'cp_odd':  {
                'max_residual_R':  float(max_resid_R),
                'max_residual_G':  float(max_resid_G),
                'max_residual_B':  float(max_resid_B),
                'max_overall':     float(max_resid),
                'pass':            bool(a1_pass),
            },
            'cp_even': {
                'max_diff_T2':     float(max_diff_T2),
                'pass':            bool(a2_pass),
            },
            'lattice_sums': {
                'original':         {'R': sum_R,   'G': sum_G,   'B': sum_B},
                'charge_conjugate': {'R': sum_R_C, 'G': sum_G_C, 'B': sum_B_C},
                'sum_T2_original':         float(sum_T2),
                'sum_T2_charge_conjugate': float(sum_T2_C),
            },
        },
        'statistical_cp_test': {
            'R':        stat_R,
            'G':        stat_G,
            'B':        stat_B,
            'combined': stat_combined,
            'pass_R':        bool(b_pass_R),
            'pass_G':        bool(b_pass_G),
            'pass_B':        bool(b_pass_B),
            'pass_combined': bool(b_pass_combined),
            'pass':          bool(b_pass),
        },
        'overall_pass': bool(overall_pass),
    }, f, indent=2)
print(f'JSON:   {json_path}')


# =========================================================================
# FINAL VERDICT
# =========================================================================
print('\n' + '=' * 74)
print('CP-PRESERVATION VERDICT')
print('=' * 74)
print(f'  (A1) CP-odd algebraic:   max |v + v^C|     = {max_resid:.3e}    '
      f'{"PASS" if a1_pass else "FAIL"}')
print(f'  (A2) CP-even algebraic:  max |T^2 - T^2_C| = {max_diff_T2:.3e}    '
      f'{"PASS" if a2_pass else "FAIL"}')
print(f'  (B)  Statistical (combined R+G+B):')
print(f'       <Im Tr P_{{0,i}}> = {stat_combined["mean"]:+.3e}    '
      f'|m|/SEM = {stat_combined["sig"]:.2f}s    '
      f'{"Consistent" if b_pass_combined else "FAIL"}')
print(f'       sigma^2 = {stat_combined["sigma2"]:.4f}    '
      f'skew = {stat_combined["skew"]:+.4f}    n = {stat_combined["n"]:,}')
print()
print(f'  Overall:  '
      f'{"CP PRESERVED (all tests pass)" if overall_pass else "FAILURE DETECTED"}')
print('=' * 74)
print()
print('Framework reading:')
print('  (A) Charge conjugation U -> U* exactly reverses the sign of Im Tr P')
print('      at every lattice site (CP-odd algebraic identity) and exactly')
print('      preserves T^2 = sum_i (Im Tr P_{0,i})^2 (CP-even algebraic')
print('      identity). The augmented term alpha (Im Tr P_{0,i})^2 is')
print('      therefore CP-even by construction and introduces no algebraic')
print('      CP violation.')
print('  (B) The equilibrium sample shows <Im Tr P_{0,i}> consistent with')
print('      zero across all 3*N^4 lattice-site evaluations, confirming the')
print('      Monte Carlo sampling produces an unbiased CP-symmetric ensemble.')
print('      Variance-based observables read by the framework therefore carry')
print('      no implicit CP-violating signal at the tested coupling.')
print()
print('Done.')
