#!/usr/bin/env python3
"""
forbidden_zone_from_U.py  —  Regenerate the Forbidden-Zone / mass-gap figure
(Figure 3) from a saved U_final.npy.

Renamed from figure1_from_U.py (2026-06-01). The script name no longer
encodes a figure number, so it stays correct under manuscript renumbering.
The figure this script produces is the four-panel Forbidden-Zone / mass-gap
result, currently Figure 3 in the manuscript.

Panel (d) plots m* vs theta in linear axes, with two sub-panels for
background and eddy cores. Each point is colored by its |grad . F_x| value,
making the third dimension directly visible: at any given theta, sites with
high |grad . F_x| sit at the BOTTOM of the cloud (lower m*), sites with low
|grad . F_x| sit at the TOP. Delta is shown as a horizontal dashed reference
line.

This visualisation honestly shows:
  - The cloud is tilted: m* grows with theta (m* = theta / |grad . F_x| at
    every site)
  - The cloud has finite width perpendicular to the tilt; that width is the
    spread of |grad . F_x| values, made visible by the color gradient
  - The data sits ABOVE Delta (no Forbidden Zone violations)
  - Eddy cores have higher theta AND higher m* than background, with both
    populations cleanly separated

Note on terminology. The quantity computed at each lattice site and labelled
|grad . F_x| in the paper (eqs. 14-16, prose at section 3.1) is the magnitude
of the covariant transverse derivative of the field strength F_munu, averaged
over the six plaquette orientations. It is linear in F. It is NOT the same
as |grad . T^0i|, which is quadratic in F. Earlier versions of this script
mistakenly used the T^0i label; that has been corrected here.

Panel (a) range fix (2026-05-04)
--------------------------------
Earlier versions clipped the (|grad . F_x|, theta) histogram at the 99.9
percentile and let matplotlib auto-size the axes. At stiff (high-alpha) runs
the |grad . F_x| distribution is narrow and concentrates near its upper end,
so the 99.9 percentile cap was visibly clipping the right edge of the
density blob, and the Delta line / Forbidden Zone fill were stopping at the
last masked data point instead of spanning the visible panel. Panel (a) now
caps at the 99.99 percentile (drops only the very extreme outliers), uses
explicit log-axis limits with a small margin, sets the histogram range to
match those limits, and draws the Delta line + Forbidden Zone across the
full visible x-range.

Delta source (2026-05-15)
-------------------------
Delta is the equilibrium mass gap Delta_eq, read from the run's records.json
and computed exactly as the 9-panel dashboard (dashboard_from_json.py,
panel 7) computes it:

    eq_cut       = len(mass_gap) // 2
    Delta_eq     = mean(mass_gap[eq_cut:])
    Delta_eq_std = std(mass_gap[eq_cut:], ddof=1)

records.json is auto-detected in the same directory as the U_final.npy
file. Because this figure and the dashboard now read the same array from the
same file with the same formula, they display the identical Delta with the
identical error bar by construction.

Fallback. If records.json cannot be found, or it lacks a usable mass_gap
array, the script prints a clear WARNING and falls back to the older
single-snapshot KDE extraction (extract_delta, below). The KDE value is a
noisier estimator with no error bar; the warning makes clear that the
displayed Delta is the fallback, not Delta_eq. To force a specific
records.json, pass --records.

Usage
-----
    python3 forbidden_zone_from_U.py /path/to/U_final_N32_b5.0_s42.npy

    # point at a specific records.json instead of auto-detecting:
    python3 forbidden_zone_from_U.py /path/to/U_final_N32_b5.0_s42.npy \\
        --records /path/to/CTC_Beta5_N32_b5.0_.../records.json

Optional flags
--------------
    --N, --beta, --seed     override autodetected metadata
    --records PATH          explicit records.json (default: auto-detect in
                            the same directory as the U_final.npy file)
    --outdir DIR            output directory (default: same as input)
    --dpi N                 output PNG resolution (default 300)
    --max_bg N              max background sites to plot (default 5000)
"""

import argparse
import json
import os
import re
import sys
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.ndimage import maximum_filter
from scipy.stats import gaussian_kde

# CLI
ap = argparse.ArgumentParser(
    description='Regenerate the Forbidden-Zone / mass-gap figure (Figure 3) '
                'from a saved U_final.npy.')
ap.add_argument('U_path', help='Path to U_final_N{N}_b{beta}_s{seed}.npy')
ap.add_argument('--N',    type=int,   default=None)
ap.add_argument('--beta', type=float, default=None)
ap.add_argument('--seed', type=int,   default=None)
ap.add_argument('--records', default=None,
                help='Explicit path to records.json. If omitted, the script '
                     'auto-detects records.json in the same directory as the '
                     'U_final.npy file.')
ap.add_argument('--outdir', default=None)
ap.add_argument('--dpi',  type=int, default=300)
ap.add_argument('--max_bg', type=int, default=5000,
                help='Max background sites to plot in panel (d-left) and '
                     'panel (b) histogram. Default 5000. Note: the visible gap '
                     'between Delta (topological floor) and the lowest background '
                     'bins is a REAL feature of the equilibrium m*(x) distribution, '
                     'not a sampling artifact. Delta is a strict lower bound; '
                     'the actual distribution sits above Delta with dynamical slack.')
args = ap.parse_args()

# Load U field and parse metadata
if not os.path.isfile(args.U_path):
    sys.exit(f'ERROR: not found: {args.U_path}')

print(f'Loading {args.U_path} ...')
U = np.load(args.U_path)
print(f'  shape={U.shape}  dtype={U.dtype}  size={U.nbytes/1e6:.1f} MB')

# Auto-detect metadata from filename. Three filename forms:
#   "U_final_N{N}_b{beta}_s{seed}.npy"                    (bare Wilson, no alpha)
#   "U_final_N{N}_b{beta}_a{alpha}_s{seed}.npy"           (augmented, alpha > 0)
#   "U_final_N{N}_b{beta}_am{|alpha|}_s{seed}.npy"        (augmented, alpha < 0)
m = re.search(r'N(\d+)_b([\d.]+?)_(?:(am?)([\d.]+?)_)?s(\d+)',
              os.path.basename(args.U_path))
if m is None:
    print(f'  WARN: could not parse N, beta, seed from filename "{os.path.basename(args.U_path)}"')
    print(f'        falling back to defaults / CLI overrides')
    parsed_N = parsed_beta = parsed_seed = None
    parsed_alpha = None
    alpha_filename_tag = ''
else:
    parsed_N    = int(m.group(1))
    parsed_beta = float(m.group(2))
    parsed_seed = int(m.group(5))
    alpha_prefix = m.group(3)
    alpha_magnitude = m.group(4)
    if alpha_magnitude is not None:
        sign = -1.0 if alpha_prefix == 'am' else 1.0
        parsed_alpha = sign * float(alpha_magnitude)
        alpha_filename_tag = f'_{alpha_prefix}{alpha_magnitude}'
    else:
        parsed_alpha = None
        alpha_filename_tag = ''
    if parsed_alpha is not None:
        print(f'  parsed from filename: N={parsed_N}, beta={parsed_beta}, '
              f'alpha={parsed_alpha:+.2f}, seed={parsed_seed}')
    else:
        print(f'  parsed from filename: N={parsed_N}, beta={parsed_beta}, '
              f'seed={parsed_seed}')

N    = args.N    if args.N    is not None else (parsed_N    if parsed_N    is not None else U.shape[1])
beta = args.beta if args.beta is not None else (parsed_beta if parsed_beta is not None else 5.0)
seed = args.seed if args.seed is not None else (parsed_seed if parsed_seed is not None else 0)

outdir = args.outdir if args.outdir is not None else os.path.dirname(os.path.abspath(args.U_path))
os.makedirs(outdir, exist_ok=True)

print(f'  N={N}  beta={beta}  seed={seed}  outdir={outdir}')

# SU(3) plaquette computation (matches ctc_beta5.py exactly)
PLANES = [(0,1),(0,2),(0,3),(1,2),(1,3),(2,3)]

def plaquette_batch(U, mu, nu):
    U_nu_xmu = np.roll(U[nu], -1, axis=mu)
    U_mu_xnu = np.roll(U[mu], -1, axis=nu)
    P  = U[mu] @ U_nu_xmu
    P  = P     @ U_mu_xnu.conj().swapaxes(-1,-2)
    P  = P     @ U[nu].conj().swapaxes(-1,-2)
    return P

def compute_ctc(U):
    """Returns curvature theta(x), m*(x), centre charge +/- 1, |grad . F_x|.

    The third return value is the magnitude of the covariant transverse
    derivative of F_munu, averaged over the six plaquette orientations.
    Paper notation: |grad . F_x|. NOT |grad . T^0i|.
    """
    Nl = U.shape[1]
    curv_sum = np.zeros((Nl,Nl,Nl,Nl))
    div_sum  = np.zeros((Nl,Nl,Nl,Nl))
    center   = np.zeros((Nl,Nl,Nl,Nl), dtype=int)
    for mu, nu in PLANES:
        P   = plaquette_batch(U, mu, nu)
        trP = np.real(np.trace(P, axis1=-2, axis2=-1))
        curv_sum += np.arccos(np.clip(trP/3.0, -1.0, 1.0))
        center += (trP < 1.0).astype(int)   # strict centre projection
        for rho in range(4):
            if rho == mu or rho == nu:
                continue
            P_fwd = np.roll(P, -1, axis=rho)
            transported = U[rho] @ P_fwd @ U[rho].conj().swapaxes(-1,-2)
            div_sum += np.sqrt(np.sum(np.abs(P - transported)**2, axis=(-2,-1)))
    curvature = curv_sum / len(PLANES)
    center_charge = np.where(center > 0, 1, -1)
    divF = div_sum / len(PLANES) + 1e-6
    mass = curvature / divF
    return curvature, mass, center_charge, divF

print('Computing m*(x), theta(x), |grad . F_x(x)| ...')
curvature, mass, center_charge, divF = compute_ctc(U)
print(f'  m* range: [{mass.min():.4f}, {mass.max():.4f}]   median={np.median(mass):.4f}')
print(f'  divF range: [{divF.min():.4f}, {divF.max():.4f}]')

# Identify eddy-core sites
local_max = (mass == maximum_filter(mass, size=5))   # peak_radius=2 -> window 5
core_mask = local_max & (center_charge == 1)
core_sites = np.argwhere(core_mask)
n_cores = len(core_sites)
print(f'  eddy cores: {n_cores}')

# ---------------------------------------------------------------------------
# Delta: equilibrium mass gap Delta_eq, read from records.json.
# ---------------------------------------------------------------------------
# Primary path: read records['mass_gap'] from the run's records.json and
# compute Delta_eq EXACTLY as dashboard_from_json.py panel 7 does --
#   eq_cut       = len(mass_gap) // 2
#   Delta_eq     = mean(mass_gap[eq_cut:])
#   Delta_eq_std = std(mass_gap[eq_cut:], ddof=1)
# so this figure and the dashboard display the identical number by
# construction.
#
# Fallback: if records.json is missing or unusable, fall back to the older
# single-snapshot KDE extraction (extract_delta) and print a loud WARNING so
# it is obvious the displayed Delta is the fallback, not Delta_eq.

def extract_delta(mass, divF):
    """Fallback: single-snapshot KDE gap-detection on this configuration.

    Noisier than the records.json plateau average, and carries no error
    bar. Used only when records.json is unavailable.
    """
    valid = (divF > 1e-6) & (mass < 100) & (mass > 0)
    m_flat = mass[valid].flatten()
    if len(m_flat) < 10:
        return float(np.percentile(m_flat, 0.5))
    kde = gaussian_kde(m_flat, bw_method='silverman')
    x_range = np.linspace(m_flat.min(), np.percentile(m_flat, 25), 1000)
    density = kde(x_range)
    noise   = np.percentile(density, 5)
    above   = x_range[density > 3.0*noise]
    return float(above[0]) if len(above) > 0 else float(np.percentile(m_flat, 0.5))


def find_records_json(u_path, explicit):
    """Locate records.json. Explicit path wins; otherwise look in the same
    directory as the U_final.npy file. Returns a path or None."""
    if explicit is not None:
        return explicit if os.path.isfile(explicit) else None
    cand = os.path.join(os.path.dirname(os.path.abspath(u_path)),
                        'records.json')
    return cand if os.path.isfile(cand) else None


def delta_eq_from_records(records_path):
    """Compute (Delta_eq, Delta_eq_std) from records.json using the same
    formula as dashboard_from_json.py panel 7. Returns (val, std) on success
    or None on any failure (missing key, too few points, bad data)."""
    try:
        with open(records_path) as f:
            records = json.load(f)
    except (json.JSONDecodeError, OSError) as e:
        print(f'  WARNING: could not read {records_path}: {e}')
        return None
    mg = records.get('mass_gap')
    if not isinstance(mg, list) or len(mg) < 4:
        print(f'  WARNING: records.json has no usable "mass_gap" array '
              f'(need >= 4 points, got {0 if mg is None else len(mg)}).')
        return None
    try:
        mg_arr = np.array(mg, dtype=float)
    except (ValueError, TypeError):
        print('  WARNING: records.json "mass_gap" array is not numeric.')
        return None
    eq_cut = len(mg_arr) // 2
    delta_eq     = float(np.mean(mg_arr[eq_cut:]))
    delta_eq_std = float(np.std(mg_arr[eq_cut:], ddof=1))
    return delta_eq, delta_eq_std


records_path = find_records_json(args.U_path, args.records)
delta_result = delta_eq_from_records(records_path) if records_path else None

if delta_result is not None:
    Delta, Delta_err = delta_result
    delta_is_eq = True
    print(f'  Delta_eq (from {os.path.basename(records_path)}, '
          f'dashboard formula) = {Delta:.4f} +/- {Delta_err:.4f}')
else:
    if records_path is None:
        print('  WARNING: records.json not found next to the U_final.npy file.')
        print('           Pass --records to point at it explicitly.')
    Delta = extract_delta(mass, divF)
    Delta_err = None
    delta_is_eq = False
    print(f'  WARNING: falling back to single-snapshot KDE Delta = {Delta:.4f}')
    print('           This is NOT Delta_eq: it is a noisier estimator with no '
          'error bar.')
    print('           The figure will be labelled to make the fallback explicit.')

# Mass ratio
core_masses = np.array([mass[tuple(c)] for c in core_sites if mass[tuple(c)] < 100])
np.random.seed(0)
bg_pts = []
for _ in range(args.max_bg * 5):
    pt = tuple(np.random.randint(0, N, 4))
    if mass[pt] < 100:
        if not core_mask[pt]:
            bg_pts.append(pt)
        if len(bg_pts) >= args.max_bg:
            break
bg_masses = np.array([mass[p] for p in bg_pts])
bg_divs   = np.array([divF[p] for p in bg_pts])
bg_curvs  = np.array([curvature[p] for p in bg_pts])
core_divs  = np.array([divF[tuple(c)] for c in core_sites if mass[tuple(c)] < 100])
core_curvs = np.array([curvature[tuple(c)] for c in core_sites if mass[tuple(c)] < 100])
ratio = float(np.mean(core_masses) / np.mean(bg_masses))
print(f'  mass ratio = {ratio:.3f}x')
print(f'  background n = {len(bg_masses)}   eddy cores n = {len(core_masses)}')

# Render figure
plt.style.use('default')
plt.rcParams.update({
    'font.family': 'serif',
    'figure.dpi': 150,
    'savefig.dpi': args.dpi,
    'axes.facecolor': '#f8f8f8',
    'axes.edgecolor': '#888',
    'grid.color': '#cccccc',
})

fig = plt.figure(figsize=(20, 12))
gs = fig.add_gridspec(2, 4, hspace=0.32, wspace=0.30,
                      width_ratios=[1, 1, 1, 1])

# Title. When Delta is the equilibrium value it is shown with its error bar.
# When the KDE fallback was used, the title says so explicitly so the figure
# is never silently mislabelled.
if delta_is_eq:
    delta_title = rf'$\Delta_{{eq}} = {Delta:.4f} \pm {Delta_err:.4f}$'
else:
    delta_title = rf'$\Delta = {Delta:.4f}$ (KDE fallback, no records.json)'

fig.suptitle(
    f'CTC SU(3): Quantum Vacuum Structure   '
    f'(post-equilibration single-configuration snapshot)\n'
    rf'$\beta = {beta}$,  $N^4 = {N}^4$,  ' + delta_title + ',  '
    rf'$\mathbf{{Mass\;Ratio = {ratio:.2f}\times}}$',
    fontsize=14, fontweight='bold', y=0.97)

# ----------------------------------------------------------------------------
# (a) Phase Space - Forbidden Zone (top-left, spans 2 columns)
# ----------------------------------------------------------------------------
# Range fix: cap at the 99.99 percentile (was 99.9, which clipped the visible
# right edge in stiff/high-alpha runs), set explicit log-axis limits with a
# small margin, match the histogram range to those limits, and span the Delta
# line + Forbidden Zone fill across the full visible panel rather than only
# across the masked data points.
ax_a = fig.add_subplot(gs[0, 0:2])
nbins = 80
flat_div  = divF.flatten()
flat_curv = curvature.flatten()

div_lo  = float(np.min(flat_div))
div_hi  = float(np.percentile(flat_div, 99.99))
curv_hi = float(np.percentile(flat_curv, 99.99))

# Small margins so the density blob does not touch the panel edges.
xlim_lo = div_lo / 1.03
xlim_hi = div_hi * 1.03
ylim_lo = 0.0
ylim_hi = curv_hi * 1.05

mask = (flat_div <= div_hi) & (flat_curv <= curv_hi)
H, xe, ye = np.histogram2d(flat_div[mask], flat_curv[mask],
                            bins=nbins,
                            range=[[div_lo, div_hi], [0.0, curv_hi]])
ax_a.pcolormesh(xe, ye, H.T,
                norm=matplotlib.colors.LogNorm(vmin=1, vmax=H.max()),
                cmap='magma', shading='flat')

# Delta line and Forbidden Zone fill across the full visible x-range.
xx = np.geomspace(xlim_lo, xlim_hi, 400)
ax_a.plot(xx, Delta * xx, '-', color='#0099cc', lw=3,
          label=f'$\\Delta$ = {Delta:.4f}')
ax_a.fill_between(xx, 0, Delta * xx, alpha=0.20, color='#cc4444',
                  label='Forbidden Zone')

ax_a.set_xscale('log')
ax_a.set_xlim(xlim_lo, xlim_hi)
ax_a.set_ylim(ylim_lo, ylim_hi)
ax_a.set_xlabel(r'$|\nabla \cdot F_{x}|$', fontsize=12)
ax_a.set_ylabel(r'Curvature $\theta$', fontsize=12)
ax_a.set_title('(a) Phase Space: Forbidden Zone', fontsize=13, fontweight='bold')
ax_a.legend(loc='upper left', framealpha=0.9)
ax_a.grid(True, alpha=0.3, linestyle='--')

# ----------------------------------------------------------------------------
# (b) Mass distribution (top-right, spans 2 columns)
# ----------------------------------------------------------------------------
ax_b = fig.add_subplot(gs[0, 2:4])
all_masses = np.concatenate([bg_masses, core_masses])
data_max = float(np.percentile(all_masses, 99.5))
mass_max = max(0.32, data_max * 1.05)
bins = np.linspace(0, mass_max, 60)
ax_b.hist(bg_masses, bins=bins, density=True, color='#3366cc', alpha=0.65,
          label=f'Background (n={len(bg_masses)})', edgecolor='none')
ax_b.hist(core_masses, bins=bins, density=True, color='#cc3344', alpha=0.65,
          label=f'Eddy cores (n={len(core_masses)})', edgecolor='none')
ax_b.axvline(Delta, color='#0099cc', lw=3, label=f'$\\Delta$ = {Delta:.3f} (nucleation floor)')
ax_b.axvline(np.mean(bg_masses),   color='#3366cc', lw=2, ls='--', alpha=0.6)
ax_b.axvline(np.mean(core_masses), color='#cc3344', lw=2, ls='--', alpha=0.6)
ax_b.fill_betweenx([0, 100], 0, Delta, alpha=0.2, color='#888888', hatch='///')
ax_b.set_yscale('log')
ax_b.set_ylim(0.05, 100)
ax_b.set_xlim(0, mass_max)
ax_b.set_xlabel(r'Mass $m^*$', fontsize=12)
ax_b.set_ylabel('Probability Density', fontsize=12)
ax_b.set_title(rf'(b) Mass Distribution: Ratio = {ratio:.2f}$\times$',
               fontsize=13, fontweight='bold')
ax_b.legend(loc='upper right', framealpha=0.9, fontsize=10)
ax_b.grid(True, alpha=0.3, linestyle='--')

# ----------------------------------------------------------------------------
# (c) Spatial mass map (bottom-left, spans 2 columns)
# ----------------------------------------------------------------------------
ax_c = fig.add_subplot(gs[1, 0:2])
z_slice, t_slice = N // 2, N // 2
slice_mass = mass[:, :, z_slice, t_slice]
im = ax_c.imshow(slice_mass.T, origin='lower', cmap='inferno',
                 extent=[0, N-1, 0, N-1], aspect='equal',
                 interpolation='bilinear',
                 vmin=np.percentile(slice_mass, 5),
                 vmax=np.percentile(slice_mass, 95))
core_in_slice = [c for c in core_sites if c[2] == z_slice and c[3] == t_slice]
if core_in_slice:
    ax_c.scatter([c[0] for c in core_in_slice], [c[1] for c in core_in_slice],
                 s=80, facecolors='cyan', edgecolors='black', lw=1.5,
                 label='Eddy cores')
    ax_c.legend(loc='upper right', framealpha=0.9)
plt.colorbar(im, ax=ax_c, label=r'Mass $m^*$')
ax_c.set_xlabel('x (lattice units)')
ax_c.set_ylabel('y (lattice units)')
ax_c.set_title(f'(c) Spatial Mass Map  (z={z_slice}, t={t_slice})',
               fontsize=13, fontweight='bold')

# ----------------------------------------------------------------------------
# (d) m* vs theta
# ----------------------------------------------------------------------------
# Plot m* vs theta in linear axes. Since m* = theta / |grad . F_x| at every
# site, the cloud naturally has a tilted shape (m* grows with theta) with
# finite width set by the spread of |grad . F_x|. Color each point by its
# |grad . F_x| value to make the third dimension visible directly:
# high-|grad . F_x| sites sit at the BOTTOM of the cloud at given theta,
# low-|grad . F_x| sites at the TOP.

# Sub-panel (d-left): background m* vs theta, colored by |grad . F_x|
ax_d1 = fig.add_subplot(gs[1, 2])
sc1 = ax_d1.scatter(bg_curvs, bg_masses, c=bg_divs, s=4, alpha=0.5,
                    cmap='viridis',
                    vmin=np.percentile(bg_divs, 2),
                    vmax=np.percentile(bg_divs, 98))
ax_d1.axhline(Delta, color='#0099cc', lw=2, ls='--', alpha=0.85,
              label=f'$\\Delta$ = {Delta:.3f}')
ax_d1.set_xlabel(r'Curvature $\theta$', fontsize=11)
ax_d1.set_ylabel(r'Mass $m^*$', fontsize=11)
ax_d1.set_title(f'(d-left) Background Vacuum (n={len(bg_masses)})',
                fontsize=11.5, fontweight='bold')
ax_d1.legend(loc='upper left', fontsize=8.5, framealpha=0.9)
ax_d1.grid(True, alpha=0.3, linestyle='--')
cbar1 = plt.colorbar(sc1, ax=ax_d1, fraction=0.046, pad=0.04)
cbar1.set_label(r'$|\nabla \cdot F_{x}|$', fontsize=9)
cbar1.ax.tick_params(labelsize=8)

# Sub-panel (d-right): eddy cores m* vs theta, colored by |grad . F_x|
ax_d2 = fig.add_subplot(gs[1, 3], sharex=ax_d1, sharey=ax_d1)
sc2 = ax_d2.scatter(core_curvs, core_masses, c=core_divs, s=12, alpha=0.8,
                    cmap='plasma',
                    edgecolors='#552233', lw=0.3,
                    vmin=np.percentile(core_divs, 2),
                    vmax=np.percentile(core_divs, 98))
ax_d2.axhline(Delta, color='#0099cc', lw=2, ls='--', alpha=0.85,
              label=f'$\\Delta$ = {Delta:.3f}')
ax_d2.set_xlabel(r'Curvature $\theta$', fontsize=11)
ax_d2.set_title(f'(d-right) Eddy Cores (n={len(core_masses)})',
                fontsize=11.5, fontweight='bold')
ax_d2.legend(loc='upper left', fontsize=8.5, framealpha=0.9)
ax_d2.grid(True, alpha=0.3, linestyle='--')
ax_d2.tick_params(labelleft=False)
cbar2 = plt.colorbar(sc2, ax=ax_d2, fraction=0.046, pad=0.04)
cbar2.set_label(r'$|\nabla \cdot F_{x}|$', fontsize=9)
cbar2.ax.tick_params(labelsize=8)

# Save. Output filename includes alpha tag when present so that bare-Wilson,
# positive-alpha, and negative-alpha runs at the same (N, beta, seed) don't
# overwrite each other.
out_png = os.path.join(
    outdir,
    f'forbidden_zone_N{N}_b{beta:.1f}{alpha_filename_tag}_s{seed}.png')
plt.savefig(out_png, dpi=args.dpi, bbox_inches='tight', facecolor='white')
plt.close()
print(f'\nSaved: {out_png}  ({os.path.getsize(out_png)//1024} KB)')
print('Done.')
