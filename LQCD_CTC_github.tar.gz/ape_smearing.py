#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ape_smearing.py

APE smearing for SU(3) gauge configurations on a hypercubic lattice.

Implements the standard recipe used by Takahashi & Suganuma 2002 and
Bali & Schilling 1992 for static three-quark and QQbar potential
extraction:

    U^(n+1)_i(x) = Proj_SU(3) [ (1 - alpha) U^(n)_i(x)
                                + (alpha / 6) Sum_staples_i(x) ]

where the sum runs over the six spatial staples around link i at site
x.  Only SPATIAL links are smeared; temporal links remain untouched.
This is the standard ground-state-projection trick for static-source
Wilson loops.

The SU(3) projection step uses an SVD-based polar decomposition + det
fix: V = U . W^H from M = U . diag(s) . W^H, divided by (det V)^(1/3)
to land in SU(3).  Verified against random SU(3) reference matrices to
produce the maximum-Re-Tr unitary (standard projection used in MILC
and Chroma).

Public API
----------
ape_smear_spatial_links(lat, alpha, n_levels)
    Apply n_levels iterations of APE smearing to the spatial links of
    `lat`.  Modifies `lat.U` IN PLACE.  The temporal links are
    untouched.  Returns the lattice for fluent chaining.

self_test()
    Self-contained smoke tests on an internally-generated random SU(3)
    lattice.  Does NOT require any other module from the validation
    pipeline.  Verifies:
      - alpha = 0 leaves links unchanged (no-op)
      - smeared links are unitary (U U^dag = I) within tolerance
      - smeared links have det = 1 within tolerance
      - temporal links are untouched by spatial smearing
      - SU(3) projector returns SU(3) inputs unchanged

Designed to be imported by su3_wilson_loop_validation_smeared.py.
"""

from __future__ import annotations
import numpy as np
from itertools import product

I3 = np.eye(3, dtype=np.complex128)


# ----------------------------------------------------------------------
# Staple construction
# ----------------------------------------------------------------------

def _spatial_staple_sum(lat, site, mu):
    """Sum of the six spatial staples around link U_mu(x), where x =
    site and mu in {0, 1, 2}.

        S_+nu = U_nu(x) U_mu(x + nu) U_nu^dag(x + mu)        (forward)
        S_-nu = U_nu^dag(x - nu) U_mu(x - nu) U_nu(x - nu + mu)  (backward)

    Total = sum over nu in spatial directions != mu of (S_+nu + S_-nu).
    Returns a 3x3 complex matrix (not in SU(3)).
    """
    if mu not in (0, 1, 2):
        raise ValueError(f"APE smearing only on spatial mu in (0,1,2), "
                         f"got mu={mu}")

    S = np.zeros((3, 3), dtype=np.complex128)
    for nu in (0, 1, 2):
        if nu == mu:
            continue
        # Forward staple
        x_plus_nu = lat.shift(site, nu)
        x_plus_mu = lat.shift(site, mu)
        S += (lat.link(site, nu)
              @ lat.link(x_plus_nu, mu)
              @ lat.link(x_plus_mu, nu).conj().T)
        # Backward staple
        x_minus_nu = lat.shift(site, nu, sign=-1)
        x_minus_nu_plus_mu = lat.shift(x_minus_nu, mu)
        S += (lat.link(x_minus_nu, nu).conj().T
              @ lat.link(x_minus_nu, mu)
              @ lat.link(x_minus_nu_plus_mu, nu))
    return S


# ----------------------------------------------------------------------
# SU(3) projection via SVD-based polar decomposition + det fix
# ----------------------------------------------------------------------

def _project_su3(M):
    """Project a 3x3 complex matrix M to the SU(3) matrix V that
    maximises Re Tr[V . M^dag].

    Computes the SVD M = U . diag(s) . W^H, sets V_u = U . W^H (the
    unitary polar factor), then fixes the determinant by dividing by
    (det V_u)^(1/3) to land in SU(3).
    """
    U, _, Wh = np.linalg.svd(M)
    V_u = U @ Wh
    d = np.linalg.det(V_u)
    if np.abs(d) < 1e-15:
        return V_u
    return V_u / (d ** (1.0 / 3.0))


# ----------------------------------------------------------------------
# APE smearing main routine
# ----------------------------------------------------------------------

def ape_smear_spatial_links(lat, alpha=0.7, n_levels=4):
    """Apply n_levels iterations of APE smearing to the spatial links of
    `lat`.  Each iteration:

        U_i(x) <- Proj_SU(3) [ (1 - alpha) U_i(x) + (alpha/6) Sum_staples ]

    for each spatial direction i in {0, 1, 2} and each site x.

    Modifies lat.U IN PLACE.  Temporal links (mu=3) are untouched.

    Requires on lat:
        lat.L, lat.T
        lat.link(site, mu) -> 3x3 SU(3) matrix
        lat.shift(site, mu, sign=+1) -> neighboring site
        lat.U[site][mu] writable
    """
    if alpha < 0 or alpha > 1:
        raise ValueError(f"alpha must be in [0, 1], got {alpha}")
    if n_levels < 0:
        raise ValueError(f"n_levels must be non-negative, got {n_levels}")
    if n_levels == 0:
        return lat

    L, T = lat.L, lat.T
    for _ in range(n_levels):
        for site in product(range(L), range(L), range(L), range(T)):
            for mu in (0, 1, 2):
                S = _spatial_staple_sum(lat, site, mu)
                U_old = lat.link(site, mu)
                M = (1.0 - alpha) * U_old + (alpha / 6.0) * S
                U_new = _project_su3(M)
                lat.U[site][mu] = U_new
    return lat


# ----------------------------------------------------------------------
# Self-contained smoke tests (no external imports required)
# ----------------------------------------------------------------------

class _MiniLat:
    """Minimal lattice stub used only for self_test.  Random SU(3) at
    every link.  Provides exactly the surface area
    ape_smear_spatial_links needs: L, T, link(), shift(), U[site][mu]."""

    def __init__(self, L, T, seed=42):
        self.L = L
        self.T = T
        rng = np.random.default_rng(seed)
        self.U = np.empty((L, L, L, T, 4, 3, 3), dtype=np.complex128)
        for x0 in range(L):
            for x1 in range(L):
                for x2 in range(L):
                    for x3 in range(T):
                        for mu in range(4):
                            A = (rng.standard_normal((3, 3))
                                 + 1j * rng.standard_normal((3, 3)))
                            Q, _ = np.linalg.qr(A)
                            d = np.linalg.det(Q)
                            self.U[x0, x1, x2, x3, mu] = Q / (d ** (1.0 / 3.0))

    def link(self, site, mu):
        return self.U[site][mu]

    def shift(self, site, mu, sign=+1):
        extents = (self.L, self.L, self.L, self.T)
        s = list(site)
        s[mu] = (s[mu] + sign) % extents[mu]
        return tuple(s)


def self_test():
    """Self-contained smoke tests on an internally-generated 4^4 lattice
    of random SU(3) matrices.  No external imports required."""

    import copy

    print("APE smearing self-test (standalone, 4^4 random SU(3) lattice)")
    lat = _MiniLat(L=4, T=4, seed=42)
    link_before = lat.link((0, 0, 0, 0), 0).copy()

    # Test 1: alpha = 0 is a no-op
    lat_test = copy.deepcopy(lat)
    ape_smear_spatial_links(lat_test, alpha=0.0, n_levels=4)
    diff_alpha0 = np.max(np.abs(lat_test.link((0, 0, 0, 0), 0) - link_before))
    print(f"  test 1 (alpha=0 no-op):               "
          f"max link diff      = {diff_alpha0:.2e}")
    test1 = diff_alpha0 < 1e-10

    # Test 2: smeared links are unitary, det = 1
    lat_test = copy.deepcopy(lat)
    ape_smear_spatial_links(lat_test, alpha=0.7, n_levels=4)
    max_unit_dev, max_det_dev = 0.0, 0.0
    for site in product(range(4), range(4), range(4), range(4)):
        for mu in (0, 1, 2):
            U = lat_test.link(site, mu)
            max_unit_dev = max(max_unit_dev,
                               np.max(np.abs(U @ U.conj().T - I3)))
            max_det_dev = max(max_det_dev,
                              abs(np.linalg.det(U) - 1.0))
    print(f"  test 2 (smeared unitarity):           "
          f"max |UU^dag - I|   = {max_unit_dev:.2e}")
    print(f"  test 2 (smeared det=1):               "
          f"max |det - 1|      = {max_det_dev:.2e}")
    test2 = (max_unit_dev < 1e-10) and (max_det_dev < 1e-10)

    # Test 3: temporal links unchanged
    max_temp_dev = 0.0
    for site in product(range(4), range(4), range(4), range(4)):
        max_temp_dev = max(max_temp_dev,
                           np.max(np.abs(lat.link(site, 3)
                                         - lat_test.link(site, 3))))
    print(f"  test 3 (temporal links untouched):    "
          f"max diff           = {max_temp_dev:.2e}")
    test3 = max_temp_dev < 1e-12

    # Test 4: SU(3) projector returns SU(3) input unchanged
    rng = np.random.default_rng(seed=11)
    A = rng.standard_normal((3, 3)) + 1j * rng.standard_normal((3, 3))
    Q, _ = np.linalg.qr(A)
    Q = Q / (np.linalg.det(Q) ** (1.0 / 3.0))
    V = _project_su3(Q)
    proj_dev = np.max(np.abs(V - Q))
    print(f"  test 4 (projector identity on SU(3)): "
          f"max diff           = {proj_dev:.2e}")
    test4 = proj_dev < 1e-10

    all_pass = test1 and test2 and test3 and test4
    print(f"\n  ALL TESTS {'PASSED' if all_pass else 'FAILED'}: "
          f"{[test1, test2, test3, test4]}")
    return all_pass


if __name__ == "__main__":
    self_test()
