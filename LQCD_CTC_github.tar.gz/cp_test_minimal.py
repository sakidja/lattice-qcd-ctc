#!/usr/bin/env python3
"""
cp_test_minimal.py
==================
Minimal-figure version of cp_test.py for the main-text CP-symmetry figure.

Produces a TWO-panel diagnostic figure per configuration:
  Left panel  - algebraic CP-odd identity residual, combined R+G+B
                ("all 3*N^4 sites exactly 0" when the identity holds)
  Right panel - statistical CP-odd ensemble check, combined Im Tr P_{0,i}
                across all three temporal-spatial planes, with mean,
                |m|/SEM significance, sigma^2, and verdict.

All numerical content (per-channel breakdowns, T^2 CP-even check, lattice
sums) is still computed and written to JSON, so this is a strict figure
simplification: nothing is lost from the verification record. Only the
main-text figure is slimmed.

Output per configuration:
  cp_test_minimal_<TAG>.png    two-panel figure
  cp_test_minimal_<TAG>.json   full numerical summary (identical structure
                               to cp_test.py JSON)

Usage:
  # Explicit files
  python3 cp_test_minimal.py U_final_N32_b5.8_a0.00_s137.npy
  python3 cp_test_minimal.py U_final_*.npy --outdir results

  # Recursive auto-discovery (no files given) - scans --root for all
  # U_final_*.npy and processes them
  python3 cp_test_minimal.py
  python3 cp_test_minimal.py --root /runs
  python3 cp_test_minimal.py --root /runs --beta 5.8 --seed 137
  python3 cp_test_minimal.py --root /runs --alpha 0.0 2.0

Multiple input files are processed sequentially; each produces its own
two-panel PNG and JSON. Filtering by --beta, --seed, --alpha works on the
filename metadata after either explicit listing or recursive discovery.
"""

import argparse, os, re, sys, json, warnings
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
warnings.filterwarnings('ignore')


# =========================================================================
# CLI
# =========================================================================
ap = argparse.ArgumentParser()
ap.add_argument('u_files', nargs='*', help='One or more U_final_*.npy paths (omit to auto-discover from --root)')
ap.add_argument('--root', default='.',
                help='Directory to scan recursively for U_final_*.npy when '
                     'no files are given (default: current directory)')
ap.add_argument('--beta', type=float, default=None,
                help='Filter to this beta only (matches filename metadata)')
ap.add_argument('--seed', type=int, default=None,
                help='Filter to this seed only')
ap.add_argument('--alpha', type=float, nargs='*', default=None,
                help='Filter to these alpha values only '
                     '(e.g. --alpha 0.0 2.0)')
ap.add_argument('--outdir', default='.', help='Output directory')
ap.add_argument('--tol', type=float, default=1e-10,
                help='Algebraic CP tolerance (default 1e-10)')
ap.add_argument('--tol_stat', type=float, default=3.0,
                help='Statistical CP tolerance in sigma units (default 3.0)')
ap.add_argument('--dpi', type=int, default=140, help='Output DPI (default 140)')
args = ap.parse_args()

TEMPORAL = [(0, 1), (0, 2), (0, 3)]


# =========================================================================
# CORE FUNCTIONS  (identical to cp_test.py, kept self-contained)
# =========================================================================

def plaq(U, mu, nu):
    """Plaquette P_{mu nu}(x)."""
    P = U[mu] @ np.roll(U[nu], -1, axis=mu)
    P = P @ np.roll(U[mu], -1, axis=nu).conj().swapaxes(-1, -2)
    return P @ U[nu].conj().swapaxes(-1, -2)


def compute_v_signed(U):
    """Returns signed Im Tr P_{0,i} for i = 1, 2, 3 (R, G, B channels)."""
    out = []
    for (mu, nu) in TEMPORAL:
        P = plaq(U, mu, nu)
        out.append(np.imag(np.trace(P, axis1=-2, axis2=-1)))
    return out


def sample_skewness(x):
    x = np.asarray(x).flatten()
    mu = float(x.mean())
    sg = float(x.std(ddof=0))
    if sg == 0:
        return 0.0
    return float(np.mean((x - mu)**3) / sg**3)


def stats_block(x, label=''):
    x = np.asarray(x).flatten()
    n = int(x.size)
    mu = float(x.mean())
    sg = float(x.std(ddof=0))
    sem = sg / np.sqrt(n) if n > 0 else 0.0
    sig = abs(mu) / sem if sem > 0 else 0.0
    sk = sample_skewness(x)
    return {'label': label, 'n': n, 'mean': mu, 'sem': sem,
            'sig': sig, 'sigma': sg, 'sigma2': sg * sg, 'skew': sk}


# =========================================================================
# PROCESS ONE CONFIGURATION
# =========================================================================

def process_one(u_file):
    if not os.path.isfile(u_file):
        print(f'  SKIP: not found: {u_file}')
        return

    m_meta = re.search(r'N(\d+)_b([\d.]+)_(?:a([\d.]+)_)?s(\d+)',
                       os.path.basename(u_file))
    if not m_meta:
        print(f'  SKIP: cannot parse metadata: {u_file}')
        return
    N = int(m_meta.group(1))
    beta = float(m_meta.group(2))
    alpha = float(m_meta.group(3)) if m_meta.group(3) is not None else 0.0
    seed = int(m_meta.group(4))
    basin = 'Wilson' if alpha == 0.0 else f'Augmented (alpha={alpha})'
    TAG = f'N{N}_b{beta:.1f}_a{alpha:.2f}_s{seed}'

    print(f'\nLoading {u_file}')
    print(f'  N={N}, beta={beta}, alpha={alpha} ({basin}), seed={seed}')
    U = np.load(u_file)

    # ---- compute signed v and charge-conjugate
    v_R, v_G, v_B = compute_v_signed(U)
    T2_original = v_R**2 + v_G**2 + v_B**2

    U_C = U.conj()
    v_R_C, v_G_C, v_B_C = compute_v_signed(U_C)
    T2_C = v_R_C**2 + v_G_C**2 + v_B_C**2

    # ---- algebraic residuals
    resid_R = np.abs(v_R + v_R_C)
    resid_G = np.abs(v_G + v_G_C)
    resid_B = np.abs(v_B + v_B_C)
    resid_combined = np.concatenate(
        [resid_R.flatten(), resid_G.flatten(), resid_B.flatten()])
    max_resid_R = float(resid_R.max())
    max_resid_G = float(resid_G.max())
    max_resid_B = float(resid_B.max())
    max_resid = max(max_resid_R, max_resid_G, max_resid_B)
    a1_pass = (max_resid < args.tol)

    diff_T2 = np.abs(T2_original - T2_C)
    max_diff_T2 = float(diff_T2.max())
    a2_pass = (max_diff_T2 < args.tol)

    # ---- statistical: combined
    combined = np.concatenate([v_R.flatten(), v_G.flatten(), v_B.flatten()])
    stat_combined = stats_block(combined, 'combined (R+G+B)')

    # ---- per-channel (for JSON only, not displayed)
    stat_R = stats_block(v_R, 'R: Im Tr P_{0,1}')
    stat_G = stats_block(v_G, 'G: Im Tr P_{0,2}')
    stat_B = stats_block(v_B, 'B: Im Tr P_{0,3}')

    b_pass_combined = stat_combined['sig'] < args.tol_stat
    b_pass_R = stat_R['sig'] < args.tol_stat
    b_pass_G = stat_G['sig'] < args.tol_stat
    b_pass_B = stat_B['sig'] < args.tol_stat
    b_pass = b_pass_combined and b_pass_R and b_pass_G and b_pass_B
    overall_pass = a1_pass and a2_pass and b_pass

    # Lattice sums (for JSON)
    sum_R = float(v_R.sum()); sum_R_C = float(v_R_C.sum())
    sum_G = float(v_G.sum()); sum_G_C = float(v_G_C.sum())
    sum_B = float(v_B.sum()); sum_B_C = float(v_B_C.sum())
    sum_T2 = float(T2_original.sum())
    sum_T2_C = float(T2_C.sum())

    # ---- console output
    print(f'  CP-odd  max|v + v^C|   = {max_resid:.3e}  '
          f'{"PASS" if a1_pass else "FAIL"}')
    print(f'  CP-even max|T^2 - T^2_C| = {max_diff_T2:.3e}  '
          f'{"PASS" if a2_pass else "FAIL"}')
    print(f'  Statistical combined: mean={stat_combined["mean"]:+.3e}  '
          f'|m|/SEM={stat_combined["sig"]:.2f}sigma  '
          f'{"Consistent" if b_pass_combined else "FAIL"}')
    print(f'  Overall: '
          f'{"CP PRESERVED" if overall_pass else "FAILURE DETECTED"}')

    # =====================================================================
    # FIGURE  (two panels, side by side)
    # =====================================================================
    fig, (ax_alg, ax_stat) = plt.subplots(1, 2, figsize=(13, 5.2))

    # --- LEFT: algebraic CP-odd residual (combined R+G+B)
    n_combined_sites = resid_combined.size
    if resid_combined.max() == 0:
        ax_alg.axvline(0, color='#2c3e50', lw=4)
        ax_alg.set_xlim(-1e-15, 1e-15)
        ax_alg.set_ylim(0.5, n_combined_sites * 2)
        ax_alg.text(
            0.5, 0.55,
            f'all {n_combined_sites:,} sites\nexactly 0',
            transform=ax_alg.transAxes,
            ha='center', va='center', fontsize=15, fontweight='bold',
            bbox=dict(facecolor='white', edgecolor='#2c3e50',
                      alpha=0.95, boxstyle='round,pad=0.6', linewidth=2))
        ax_alg.text(
            0.5, 0.22,
            f'tolerance = {args.tol:.0e}',
            transform=ax_alg.transAxes, ha='center', va='center',
            fontsize=10, family='monospace', color='#555555')
    else:
        ax_alg.hist(resid_combined, bins=60, color='#2c3e50',
                    edgecolor='black', alpha=0.8)
    ax_alg.set_yscale('log')
    ax_alg.set_xlabel(r'per-site $|\,v_i + v_i^{\mathcal{C}}\,|$',
                      fontsize=11)
    ax_alg.set_ylabel('count (log)', fontsize=11)
    ax_alg.set_title(
        f'(a) Algebraic CP-odd identity\n'
        f'$\\max\\,|\\,v_i + v_i^{{\\mathcal{{C}}}}\\,| = '
        f'{max_resid:.2e}$    (R+G+B, all {n_combined_sites:,} sites)',
        fontsize=10.5, fontweight='bold')
    ax_alg.grid(True, alpha=0.3)

    # --- RIGHT: statistical CP-odd ensemble check (combined R+G+B)
    v_max_abs = np.percentile(np.abs(combined), 99.5)
    bins = np.linspace(-v_max_abs * 1.05, v_max_abs * 1.05, 60)

    ax_stat.hist(combined, bins=bins, color='#4d4dff', alpha=0.65,
                 density=True, edgecolor='black', linewidth=0.5)
    ax_stat.axvline(0, color='black', lw=0.7)
    ax_stat.axvline(stat_combined['mean'], color='red', lw=1.6,
                    linestyle='--',
                    label=f"mean = {stat_combined['mean']:+.2e}")
    ax_stat.set_yscale('log')
    ax_stat.set_xlabel(r'$\mathrm{Im}\,\mathrm{Tr}\,P_{0,i}$  (combined R+G+B)',
                       fontsize=11)
    ax_stat.set_ylabel('density', fontsize=11)
    ax_stat.legend(fontsize=9, loc='upper right')
    ax_stat.grid(True, alpha=0.3)

    stat_text = (f"n         = {stat_combined['n']:,}\n"
                 f"mean      = {stat_combined['mean']:+.2e}\n"
                 f"SEM       = {stat_combined['sem']:.3e}\n"
                 f"|m|/SEM   = {stat_combined['sig']:.2f}sigma\n"
                 f"sigma^2   = {stat_combined['sigma2']:.4f}\n"
                 f"skew      = {stat_combined['skew']:+.4f}\n"
                 f"tol       = {args.tol_stat:.1f}sigma\n"
                 f"verdict   = "
                 f"{'Consistent' if b_pass_combined else 'FAIL'}")
    ax_stat.text(0.02, 0.97, stat_text, transform=ax_stat.transAxes,
                 fontsize=8.5, family='monospace', verticalalignment='top',
                 bbox=dict(facecolor='white', edgecolor='#4d4dff',
                           alpha=0.92, boxstyle='round,pad=0.4'))
    ax_stat.set_title(
        f'(b) Statistical CP-odd ensemble check\n'
        f'combined $\\langle\\mathrm{{Im}}\\,\\mathrm{{Tr}}\\,P_{{0,i}}'
        f'\\rangle$ consistent with zero',
        fontsize=10.5, fontweight='bold')

    fig.suptitle(
        f'CP-symmetry verification   '
        f'N={N},  beta={beta},  alpha={alpha},  {basin},  seed={seed}',
        fontsize=12, fontweight='bold', y=1.005)

    plot_path = os.path.join(args.outdir, f'cp_test_minimal_{TAG}.png')
    plt.tight_layout()
    plt.savefig(plot_path, dpi=args.dpi, bbox_inches='tight',
                facecolor='white')
    plt.close()
    print(f'  Figure: {plot_path}')

    # =====================================================================
    # JSON  (full record, same structure as cp_test.py)
    # =====================================================================
    json_path = os.path.join(args.outdir, f'cp_test_minimal_{TAG}.json')
    with open(json_path, 'w') as f:
        json.dump({
            'N': N, 'beta': beta, 'alpha': alpha, 'seed': seed,
            'basin': basin,
            'tolerance_algebraic': float(args.tol),
            'tolerance_statistical_sigma': float(args.tol_stat),
            'algebraic_cp_test': {
                'cp_odd':  {
                    'max_residual_R':  float(max_resid_R),
                    'max_residual_G':  float(max_resid_G),
                    'max_residual_B':  float(max_resid_B),
                    'max_overall':     float(max_resid),
                    'pass':            bool(a1_pass),
                },
                'cp_even': {
                    'max_diff_T2':     float(max_diff_T2),
                    'pass':            bool(a2_pass),
                },
                'lattice_sums': {
                    'original':         {'R': sum_R,   'G': sum_G,   'B': sum_B},
                    'charge_conjugate': {'R': sum_R_C, 'G': sum_G_C, 'B': sum_B_C},
                    'sum_T2_original':         float(sum_T2),
                    'sum_T2_charge_conjugate': float(sum_T2_C),
                },
            },
            'statistical_cp_test': {
                'R':        stat_R,
                'G':        stat_G,
                'B':        stat_B,
                'combined': stat_combined,
                'pass_R':        bool(b_pass_R),
                'pass_G':        bool(b_pass_G),
                'pass_B':        bool(b_pass_B),
                'pass_combined': bool(b_pass_combined),
                'pass':          bool(b_pass),
            },
            'overall_pass': bool(overall_pass),
        }, f, indent=2)
    print(f'  JSON:   {json_path}')


# =========================================================================
# MAIN
# =========================================================================
os.makedirs(args.outdir, exist_ok=True)

# ----- resolve input files: explicit, else recursive auto-discovery
if args.u_files:
    u_files = list(args.u_files)
    print(f'Using {len(u_files)} explicit U_final file(s).')
else:
    import glob
    u_files = sorted(glob.glob(
        os.path.join(args.root, '**', 'U_final_*.npy'), recursive=True))
    if not u_files:
        sys.exit(f'ERROR: no U_final_*.npy found under '
                 f'{os.path.abspath(args.root)} (searched recursively). '
                 f'Pass files explicitly or set --root.')
    print(f'Auto-discovered {len(u_files)} U_final_*.npy under '
          f'{os.path.abspath(args.root)}')

# ----- apply filters
def metadata(path):
    m = re.search(r'N(\d+)_b([\d.]+)_(?:a([\d.]+)_)?s(\d+)',
                  os.path.basename(path))
    if not m:
        return None
    return {
        'N': int(m.group(1)),
        'beta': float(m.group(2)),
        'alpha': float(m.group(3)) if m.group(3) is not None else 0.0,
        'seed': int(m.group(4)),
    }

filtered = []
for f in u_files:
    md = metadata(f)
    if md is None:
        print(f'  SKIP (cannot parse): {f}')
        continue
    if args.beta is not None and abs(md['beta'] - args.beta) > 1e-6:
        continue
    if args.seed is not None and md['seed'] != args.seed:
        continue
    if args.alpha is not None and not any(
            abs(md['alpha'] - a) < 1e-6 for a in args.alpha):
        continue
    filtered.append(f)

if not filtered:
    sys.exit(f'ERROR: no files matched the filters '
             f'(beta={args.beta}, seed={args.seed}, alpha={args.alpha}).')

if len(filtered) != len(u_files):
    print(f'Filtered to {len(filtered)} configuration(s) after applying '
          f'beta={args.beta} seed={args.seed} alpha={args.alpha}.')

print(f'\nProcessing {len(filtered)} configuration(s) ...')
for u_file in filtered:
    process_one(u_file)
print('\nDone.')
