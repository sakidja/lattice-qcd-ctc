#!/usr/bin/env python3
"""
ctc_meson_baryon_movie.py
==========================

Unified topological readout of the CTC SU(3) vacuum.

Replaces and supersedes:
    ctc_meson_baryon_map.py   (ℤ₃-sector classifier; saturates in confined phase)
    ctc_im_tr_p0i_map.py      (F-aspect classifier; loses topological structure)

The two prior scripts disagreed on which observable to use. This script
runs BOTH classifiers on the same set of connected components, adds the
two physics-grade tests the prior pair were missing, and reports the
overlap so a reviewer can see where the classifiers agree.

What the script does
--------------------
Per measurement frame on a 3D spatial slice at t = N/2:

  1. Compute the chromomagnetic rotational flux F(x):
        F_vec(x)    = (Im Tr P_{01}, Im Tr P_{02}, Im Tr P_{03})       (3-vector)
        F_scalar(x) = sum_i |Im Tr P_{0i}(x)|                          (scalar)
     F_vec is the signed per-plane field; F_scalar is its magnitude
     sum, used for thresholding.

  2. Compute the ℤ₃ Polyakov-loop sector field at every spatial site.

  3. Threshold F_scalar at a pinned percentile (default 92nd) to produce
     an active-site mask. Run connected-component analysis with
     selectable connectivity (default 26 for tube continuity).

  4. For every component compute:
        V                = voxel count
        principal axis   = eigenvector of largest cov eigenvalue
        L, w, L/w        = principal-axis length, transverse width, aspect
        p0, p1           = principal-axis endpoints
        z3_p0, z3_p1     = ℤ₃ sector at the two endpoints
        z3_sectors_set   = distinct ℤ₃ sectors within radius 1 of the component
        coherence        = |⟨F̂_vec⟩| over the component, where F̂_vec = F_vec / |F_vec|
                           Coherence = 1 means the chromomagnetic flux direction is
                           the same at every voxel; 0 means isotropic.

  5. Apply BOTH classifiers and store both verdicts:

       Aspect classifier (F-based):
          aspect_meson   <=>  V >= V_min_meson  AND  L/w >= L_over_w_min
          aspect_baryon  <=>  V >= V_min_baryon AND  L/w <  L_over_w_min

       ℤ₃ classifier (Script-1 lineage):
          z3_meson       <=>  |z3_sectors_set| = 2
          z3_baryon      <=>  |z3_sectors_set| = 3

     A component is high-confidence meson if it passes both AND
     z3_p0 != z3_p1 AND coherence >= coherence_min. High-confidence
     baryon if it passes both AND z3_sectors_set == {0, 1, 2}.

  6. Render the high-confidence components at full opacity, single-
     classifier (one criterion only) components at half opacity, and
     unclassified active sites as faint gray dots.

  7. Save per-frame component records to JSON so a downstream analysis
     can reproduce any number in the figures from the saved data.

Physical scales: F_floor vs Δ
-----------------------------
The previous Script 2 called the lower bound on F "Δ_pinned". That is
misleading. The paper's Δ is the m*-field nucleation floor (curvature /
divergence), a separate observable. Here:

   F_floor   = lower bound on F (chromomagnetic flux floor; new diagnostic)
   Δ_floor   = lower bound on m* (the paper's mass-gap floor)

Both are reported, both are pinned in the pre-pass, and both are saved
to the JSON header with their pre-pass spread so the reviewer can see
whether the run is equilibrated.

Run mode
--------
Continuation run from a pre-thermalized U_final.npy. The Monte Carlo
update is pure Wilson Metropolis: when reading an augmented-action
checkpoint, the continuation sweeps do not re-augment. This is correct
for the visualization since the source run already equilibrated under
the augmented action and the local Wilson updates are slow compared to
the topological structure we are visualizing.

Outputs
-------
  S5_meson_baryon_movie_<TAG>.gif        transparent-volume movie
  S5_meson_baryon_movie_<TAG>_history.json   per-frame component records

Usage
-----
    python3 ctc_meson_baryon_movie.py /path/to/U_final_*.npy

Run with --help for the full flag list. The defaults reproduce the
behaviour of Script 2 with the new tests turned on.
"""

import argparse, os, re, sys, time, json, warnings
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D                  # noqa: F401
from mpl_toolkits.mplot3d.art3d import Poly3DCollection, Line3DCollection
from scipy.ndimage import gaussian_filter, binary_dilation, label
from scipy.stats import gaussian_kde
import imageio
warnings.filterwarnings('ignore')


# ─── CLI ──────────────────────────────────────────────────────────────────
ap = argparse.ArgumentParser(
    description='Unified CTC meson/baryon topological movie.')
ap.add_argument('u_file',           help='Path to U_final_*.npy')
ap.add_argument('--movie_sweeps',   type=int,   default=400)
ap.add_argument('--save_every',     type=int,   default=2)
ap.add_argument('--fps',            type=int,   default=12)
ap.add_argument('--ema',            type=float, default=0.30,
                help='EMA mixing weight on the slice field')
ap.add_argument('--prepass_frames', type=int,   default=10,
                help='Pre-pass measurement frames for pinning thresholds')
ap.add_argument('--elev',           type=float, default=25.0)
ap.add_argument('--rotations',      type=float, default=1.0)

# Threshold and classification
ap.add_argument('--threshold_pct',  type=float, default=92.0,
                help='Percentile of F_scalar for active-site cutoff '
                     '(default 92, gives ~8%% active fraction)')
ap.add_argument('--L_over_w_min',   type=float, default=2.0,
                help='Minimum aspect ratio for aspect-meson classification')
ap.add_argument('--V_min_meson',    type=int,   default=4,
                help='Minimum component volume to be classified as meson')
ap.add_argument('--V_min_baryon',   type=int,   default=8,
                help='Minimum component volume to be classified as baryon')
ap.add_argument('--coherence_min',  type=float, default=0.3,
                help='Minimum F-vector coherence for high-confidence meson '
                     '(0=isotropic, 1=perfectly aligned). Default 0.3 is '
                     'calibrated to be above the random-permutation baseline '
                     'for typical aspect-meson volumes (V~5-15) at β=5.0; '
                     'tune by comparing per-frame coh_med to coh_baseline '
                     'in the printed output.')
ap.add_argument('--z3_radius',      type=int,   default=1,
                help='Radius for ℤ₃-sector dilation around a component')
ap.add_argument('--connectivity',   type=int,   default=26, choices=(6, 18, 26),
                help='Connected-component neighbourhood size (default 26)')
ap.add_argument('--smooth_sigma',   type=float, default=0.0,
                help='Gaussian smoothing sigma on F_scalar before thresholding')
ap.add_argument('--show_low', action='store_true',
                help='Show low-confidence components (small dim spheres for '
                     'mesons, translucent triangles for baryons) in addition '
                     'to the high-confidence layer. Default is hidden to '
                     'keep figures clean; use this when diagnosing the '
                     'classifier or investigating noise-level activity.')
ap.add_argument('--hide_low', action='store_true',
                help='(Deprecated alias: low-confidence is now hidden by '
                     'default. Use --show_low to bring it back.)')
ap.add_argument('--render', choices=['hadrons', 'cubes'], default='hadrons',
                help='Visualization style. "hadrons" (default) draws mesons '
                     'as dumbbells (two sector-coloured endpoint spheres '
                     'joined by a flux tube) and baryons as colour-singlet '
                     'triangles (three sector-coloured vertices with a '
                     'translucent face). "cubes" reproduces the original '
                     'voxel-volume rendering.')

# Metadata overrides
ap.add_argument('--N',              type=int,   default=None)
ap.add_argument('--beta',           type=float, default=None)
ap.add_argument('--alpha',          type=float, default=None)
ap.add_argument('--seed',           type=int,   default=None)
ap.add_argument('--rng_seed',       type=int,   default=None)
ap.add_argument('--outdir',         type=str,   default='.')
args = ap.parse_args()

if not os.path.isfile(args.u_file):
    sys.exit(f'ERROR: not found: {args.u_file}')

print(f'Loading {args.u_file} ...')
U = np.load(args.u_file)

m_meta = re.search(r'N(\d+)_b([\d.]+)_(?:a([\d.]+)_)?s(\d+)',
                   os.path.basename(args.u_file))
if m_meta:
    N     = args.N     if args.N     is not None else int(m_meta.group(1))
    beta  = args.beta  if args.beta  is not None else float(m_meta.group(2))
    alpha = (args.alpha if args.alpha is not None
             else (float(m_meta.group(3)) if m_meta.group(3) else None))
    seed  = args.seed  if args.seed  is not None else int(m_meta.group(4))
else:
    N     = args.N     if args.N     is not None else U.shape[1]
    beta  = args.beta  if args.beta  is not None else 5.0
    alpha = args.alpha
    seed  = args.seed  if args.seed  is not None else 0

rng_seed = args.rng_seed if args.rng_seed is not None else (1000 + seed)
np.random.seed(rng_seed)

print(f'  U.shape={U.shape}  N={N}  dtype={U.dtype}')
if alpha is not None:
    print(f'  beta={beta}  alpha={alpha}  seed={seed}  RNG seed={rng_seed}')
    TAG = f'N{N}_b{beta:.1f}_a{alpha:.2f}_s{seed}'
else:
    print(f'  beta={beta}  seed={seed}  RNG seed={rng_seed}')
    TAG = f'N{N}_b{beta:.1f}_s{seed}'
print(f'  threshold percentile = {args.threshold_pct:.1f}  '
      f'L/w >= {args.L_over_w_min}  V_meson >= {args.V_min_meson}  '
      f'V_baryon >= {args.V_min_baryon}')
print(f'  coherence_min = {args.coherence_min}  ℤ₃ radius = {args.z3_radius}'
      f'  connectivity = {args.connectivity}')

os.makedirs(args.outdir, exist_ok=True)


# ─── SU(3) primitives ────────────────────────────────────────────────────
PLANES = [(0,1),(0,2),(0,3),(1,2),(1,3),(2,3)]


def random_su3_batch(shape):
    size = int(np.prod(shape))
    A = np.random.randn(size, 3, 3) + 1j * np.random.randn(size, 3, 3)
    Q, _ = np.linalg.qr(A)
    d = np.linalg.det(Q)
    return (Q / (d[:, None, None] ** (1/3))).reshape(*shape, 3, 3)


def project_su3_batch(M):
    sh = M.shape; sz = int(np.prod(sh[:-2]))
    M2 = M.reshape(sz, 3, 3)
    Uu, _, Vh = np.linalg.svd(M2)
    Q = Uu @ Vh
    d = np.linalg.det(Q)
    return (Q / (d[:, None, None] ** (1/3))).reshape(sh)


def plaq(U, mu, nu):
    P = U[mu] @ np.roll(U[nu], -1, axis=mu)
    P = P @ np.roll(U[mu], -1, axis=nu).conj().swapaxes(-1, -2)
    return P @ U[nu].conj().swapaxes(-1, -2)


def staple(U, mu):
    S = np.zeros((N, N, N, N, 3, 3), dtype=complex)
    for nu in range(4):
        if nu == mu: continue
        fwd = (U[nu] @ np.roll(U[mu], -1, axis=nu)
               @ np.roll(U[nu], -1, axis=mu).conj().swapaxes(-1, -2))
        Ub = np.roll(U[nu], 1, axis=nu)
        bwd = (Ub.conj().swapaxes(-1, -2)
               @ np.roll(U[mu], 1, axis=nu)
               @ np.roll(Ub, -1, axis=mu))
        S += fwd + bwd
    return S


_x, _y, _z, _t = np.meshgrid(*[np.arange(N)] * 4, indexing='ij')
PAR = (_x + _y + _z + _t) % 2


def metropolis_sweep(U, beta, delta):
    accepted = total = 0
    for mu in range(4):
        S = staple(U, mu)
        for p in [0, 1]:
            mask = (PAR == p); idx = np.where(mask)
            old = U[mu][idx].copy()
            new = project_su3_batch(
                old + delta * (random_su3_batch((len(idx[0]),)) - old))
            dS = beta * (np.real(np.trace(new @ S[idx], axis1=-2, axis2=-1))
                         - np.real(np.trace(old @ S[idx], axis1=-2, axis2=-1)))
            acc = np.random.random(len(idx[0])) < np.exp(np.clip(dS, -100, 0))
            fa = np.zeros((N, N, N, N), dtype=bool); fa[idx] = acc
            U[mu][fa] = new[acc]
            accepted += int(acc.sum()); total += len(idx[0])
    rate = accepted / max(total, 1)
    if rate > 0.6:
        delta = min(delta * 1.05, 0.5)
    elif rate < 0.4:
        delta = max(delta * 0.95, 0.15)
    return U, rate, delta


def measure_plaq(U):
    s = 0.0; tot = 0
    for mu, nu in PLANES:
        trP = np.real(np.trace(plaq(U, mu, nu), axis1=-2, axis2=-1))
        s += np.sum(trP) / 3.0; tot += trP.size
    return s / tot


# ─── Field computations ─────────────────────────────────────────────────

def compute_z3_polyakov(U):
    """ℤ₃ Polyakov-loop trace phase classifier. Returns 3D array
    (N, N, N) of sector indices in {0, 1, 2}."""
    L = U[0][:, :, :, 0, :, :].copy()
    for tau in range(1, N):
        L = np.matmul(L, U[0][:, :, :, tau, :, :])
    Tr_L = np.trace(L, axis1=-2, axis2=-1)
    angle = np.angle(Tr_L) % (2 * np.pi)
    return np.round(angle * 3.0 / (2 * np.pi)).astype(int) % 3


def compute_F_fields(U):
    """Returns (F_scalar_4d, F_vector_4d).

    F_scalar(x)   = sum_i |Im Tr P_{0i}(x)|         shape (N, N, N, N)
    F_vector(x)   = (Im Tr P_{01}, Im Tr P_{02}, Im Tr P_{03})
                                                     shape (N, N, N, N, 3)

    F_vector is signed per-plane. F_scalar is the magnitude sum used for
    thresholding. F_vector is used for the directional coherence test.
    """
    F_scalar = np.zeros((N, N, N, N))
    F_vector = np.zeros((N, N, N, N, 3))
    for i_idx, i_plane in enumerate((1, 2, 3)):
        P = plaq(U, 0, i_plane)
        ImTr = np.imag(np.trace(P, axis1=-2, axis2=-1))
        F_vector[..., i_idx] = ImTr
        F_scalar += np.abs(ImTr)
    return F_scalar, F_vector


def compute_mass_floor(U):
    """Compute the m*-field nucleation floor Δ via KDE gap detection.
    Independent of F. This is the paper's Δ, not to be confused with the
    F-field floor F_floor computed in compute_F_floor below.

    Returns Δ (scalar). Skipped for speed during the main movie loop;
    only invoked during the pre-pass.
    """
    curv = np.zeros((N, N, N, N))
    div  = np.zeros((N, N, N, N))
    for mu, nu in PLANES:
        P = plaq(U, mu, nu)
        trP = np.real(np.trace(P, axis1=-2, axis2=-1))
        curv += np.arccos(np.clip(trP / 3, -1, 1))
        for rho in range(4):
            if rho == mu or rho == nu: continue
            Pf = np.roll(P, -1, axis=rho)
            Tt = U[rho] @ Pf @ U[rho].conj().swapaxes(-1, -2)
            div += np.sqrt(np.sum(np.abs(P - Tt) ** 2, axis=(-2, -1)))
    curv /= len(PLANES)
    div  = div / len(PLANES) + 1e-6
    mass = curv / div

    valid = (div > 1e-6) & (mass < 100) & (mass > 0)
    m_flat = mass[valid].flatten()
    if len(m_flat) < 10:
        return 0.15
    try:
        kde = gaussian_kde(m_flat, bw_method='silverman')
        xr = np.linspace(m_flat.min(), np.percentile(m_flat, 25), 500)
        dens = kde(xr)
        noise = np.percentile(dens, 5)
        above = xr[dens > 3.0 * noise]
        return float(above[0]) if len(above) else float(np.percentile(m_flat, 0.5))
    except Exception:
        return float(np.percentile(m_flat, 0.5))


def compute_F_floor(F_scalar):
    """Same KDE-gap protocol applied to F_scalar. Returns the lower-bound
    F_floor below which the F distribution has no support.
    """
    flat = F_scalar[F_scalar > 0].flatten()
    if len(flat) < 10:
        return 0.0
    try:
        kde = gaussian_kde(flat, bw_method='silverman')
        xr = np.linspace(flat.min(), np.percentile(flat, 25), 500)
        dens = kde(xr)
        noise = np.percentile(dens, 5)
        above = xr[dens > 3.0 * noise]
        return float(above[0]) if len(above) else float(np.percentile(flat, 0.5))
    except Exception:
        return float(np.percentile(flat, 0.5))


# ─── Component analysis ─────────────────────────────────────────────────

def make_connectivity_structure(connectivity):
    """Return the SciPy structuring element for the chosen connectivity."""
    if connectivity == 6:
        s = np.zeros((3, 3, 3), dtype=bool)
        s[1, 1, :] = True; s[1, :, 1] = True; s[:, 1, 1] = True
        return s
    elif connectivity == 18:
        s = np.ones((3, 3, 3), dtype=bool)
        s[0, 0, 0] = s[0, 0, 2] = s[0, 2, 0] = s[0, 2, 2] = False
        s[2, 0, 0] = s[2, 0, 2] = s[2, 2, 0] = s[2, 2, 2] = False
        return s
    else:  # 26
        return np.ones((3, 3, 3), dtype=bool)


def principal_axis_metrics(coords, V_for_cov_floor):
    """Cov-eigendecomposition principal-axis metrics for a component.

    For V < V_for_cov_floor the cov matrix is rank-deficient; in that case
    we report a spherical placeholder with L/w = 1, so the aspect
    classifier will not flag the component as a tube on noise alone.
    """
    V = len(coords)
    if V < 2:
        c = coords[0].astype(float)
        return dict(V=V, L=1.0, w=1.0, L_over_w=1.0,
                    centroid=tuple(map(float, c)),
                    p0=tuple(map(float, c)), p1=tuple(map(float, c)),
                    axis=(1.0, 0.0, 0.0))
    c = coords.mean(axis=0)
    if V < V_for_cov_floor:
        return dict(V=V, L=float(V) ** (1/3), w=float(V) ** (1/3),
                    L_over_w=1.0,
                    centroid=tuple(map(float, c)),
                    p0=tuple(map(float, c)), p1=tuple(map(float, c)),
                    axis=(1.0, 0.0, 0.0))
    cov = np.cov((coords - c).T)
    try:
        eigvals, eigvecs = np.linalg.eigh(cov)
    except np.linalg.LinAlgError:
        eigvals = np.array([1.0, 1.0, 1.0]); eigvecs = np.eye(3)
    order = np.argsort(eigvals)
    eigvals = np.maximum(eigvals[order], 1e-9)
    eigvecs = eigvecs[:, order]
    L = 2.0 * np.sqrt(eigvals[2])
    w = 2.0 * np.sqrt(eigvals[0])
    axis = eigvecs[:, 2]
    proj = (coords - c) @ axis
    p0 = c + proj.min() * axis
    p1 = c + proj.max() * axis
    return dict(V=int(V), L=float(L), w=float(w),
                L_over_w=float(L / max(w, 1e-9)),
                centroid=tuple(map(float, c)),
                p0=tuple(map(float, p0)),
                p1=tuple(map(float, p1)),
                axis=tuple(map(float, axis)))


def f_vec_coherence(coords, F_vec_3d):
    """Coherence of the F_vec direction across a component.

    Returns |⟨F̂⟩| where F̂ = F_vec / |F_vec|, averaged over the component's
    voxels. Range [0, 1]. 1.0 = perfectly aligned chromomagnetic flux
    (a real coherent flux tube). 0.0 = isotropic. Voxels with zero
    |F_vec| are skipped.
    """
    vecs = F_vec_3d[coords[:, 0], coords[:, 1], coords[:, 2]]   # (V, 3)
    norms = np.linalg.norm(vecs, axis=1)
    mask = norms > 1e-9
    if mask.sum() == 0:
        return 0.0
    unit = vecs[mask] / norms[mask][:, None]
    mean_dir = unit.mean(axis=0)
    return float(np.linalg.norm(mean_dir))


def coherence_random_baseline(F_vec_3d, active_mask, V_typical, n_trials=20,
                              rng=None):
    """Coherence of V_typical random voxels drawn from the active set.

    Establishes a per-frame null hypothesis. Any aspect-meson candidate
    whose coherence exceeds this baseline is coherent beyond the level
    that random sampling of the field would explain. Coherence at or
    below the baseline indicates the component's F-vector direction is
    statistically indistinguishable from a random sample, and the
    component is therefore most likely a noise concentration rather
    than a coherent flux tube.

    Returns the median coherence over `n_trials` random samples.
    """
    rng = rng if rng is not None else np.random
    coords_all = np.argwhere(active_mask)
    if len(coords_all) < V_typical or V_typical < 2:
        return 0.0
    coh_vals = []
    for _ in range(n_trials):
        idx = rng.choice(len(coords_all), V_typical, replace=False)
        coh_vals.append(f_vec_coherence(coords_all[idx], F_vec_3d))
    return float(np.median(coh_vals))


def z3_at_point(z3_3d, p):
    """ℤ₃ sector at a (possibly non-integer) spatial point p.
    Uses nearest-voxel rounding with periodic boundary."""
    xi = int(round(p[0])) % N
    yi = int(round(p[1])) % N
    zi = int(round(p[2])) % N
    return int(z3_3d[xi, yi, zi])


def z3_sectors_near_component(component_mask, z3_3d, radius):
    """Set of distinct ℤ₃ sectors within `radius` of a component."""
    if radius > 0:
        dilated = binary_dilation(component_mask, iterations=radius)
    else:
        dilated = component_mask
    return set(np.unique(z3_3d[dilated]).tolist())


def classify_unified(f_scalar_3d, f_vec_3d, z3_3d,
                     threshold_high,
                     L_over_w_min, V_min_meson, V_min_baryon,
                     coherence_min, z3_radius,
                     connectivity_struct,
                     smooth_sigma):
    """Single-pass classification of every connected component.

    Two classifiers are reported side-by-side:

      Aspect (F-based):
          aspect_meson  <=>  V >= V_min_meson  AND  L/w >= L_over_w_min
          aspect_baryon <=>  V >= V_min_baryon AND  L/w <  L_over_w_min

      ℤ₃ dilation (Script-1 lineage, diagnostic only):
          z3_cls = meson/baryon/pure/other from |z3_sectors_present_dilation|

    The dilation-based ℤ₃ classifier saturates in the confined phase
    (ℤ₃ mixes at lattice scale, so any radius>=1 dilation finds all 3
    sectors). It is kept in the JSON output as a diagnostic but is NOT
    used to gate the high-confidence promotion. The promotion is gated
    by physically robust tests that survive ℤ₃ mixing:

      High-confidence meson:
          aspect_meson
          AND z3_p0 != z3_p1                 (topology at the two endpoints)
          AND coherence >= coherence_min      (chromomagnetic flux coherence)

      High-confidence baryon:
          aspect_baryon
          AND component voxels themselves span all three ℤ₃ sectors
              (NOT the dilation — the true tri-junction signature)

    Returns (records, sites_high_meson, sites_low_meson,
             sites_high_baryon, sites_low_baryon, sites_other, n_active,
             counts).
    `counts` is a dict with the per-criterion failure breakdown for
    on-screen and JSON reporting.
    """
    f_for_thresh = (gaussian_filter(f_scalar_3d, sigma=smooth_sigma)
                    if smooth_sigma > 0 else f_scalar_3d)
    active = f_for_thresh > threshold_high
    labelled, n_comp = label(active, structure=connectivity_struct)

    high_m = np.zeros_like(active)
    low_m  = np.zeros_like(active)
    high_b = np.zeros_like(active)
    low_b  = np.zeros_like(active)
    other  = np.zeros_like(active)

    counts = dict(
        n_aspect_meson=0, n_aspect_baryon=0,
        n_aspect_meson_endpoint_pass=0,
        n_aspect_meson_coherence_pass=0,
        n_aspect_baryon_z3_all3_pass=0,
        coh_aspect_meson=[],   # coherence values for every aspect-meson
    )

    records = []
    for cid in range(1, n_comp + 1):
        comp_mask = (labelled == cid)
        coords = np.argwhere(comp_mask)
        pm = principal_axis_metrics(coords, V_for_cov_floor=V_min_meson)
        V, L_over_w = pm['V'], pm['L_over_w']

        # ℤ₃ at endpoints
        z3_p0 = z3_at_point(z3_3d, pm['p0'])
        z3_p1 = z3_at_point(z3_3d, pm['p1'])

        # ℤ₃ at the component's own voxels (topologically meaningful)
        z3_at_comp = z3_3d[coords[:, 0], coords[:, 1], coords[:, 2]]
        z3_set_comp = sorted(np.unique(z3_at_comp).tolist())

        # ℤ₃ in the dilated component (kept as diagnostic only)
        z3_set_dil = sorted(z3_sectors_near_component(
            comp_mask, z3_3d, z3_radius))

        # Directional coherence
        coh = f_vec_coherence(coords, f_vec_3d)

        # Aspect verdict
        if V >= V_min_meson and L_over_w >= L_over_w_min:
            aspect = 'meson'
        elif V >= V_min_baryon and L_over_w < L_over_w_min:
            aspect = 'baryon'
        else:
            aspect = 'other'

        # Dilation-ℤ₃ verdict (diagnostic)
        if len(z3_set_dil) == 2:
            z3_cls = 'meson'
        elif len(z3_set_dil) == 3:
            z3_cls = 'baryon'
        elif len(z3_set_dil) == 1:
            z3_cls = 'pure'
        else:
            z3_cls = 'other'

        # Physically robust checks
        endpoint_diff = (z3_p0 != z3_p1)
        coherent      = (coh >= coherence_min)
        all_three     = (set(z3_set_comp) == {0, 1, 2})

        # Failure-breakdown counters
        if aspect == 'meson':
            counts['n_aspect_meson'] += 1
            counts['coh_aspect_meson'].append(coh)
            if endpoint_diff:
                counts['n_aspect_meson_endpoint_pass'] += 1
            if coherent:
                counts['n_aspect_meson_coherence_pass'] += 1
        elif aspect == 'baryon':
            counts['n_aspect_baryon'] += 1
            if all_three:
                counts['n_aspect_baryon_z3_all3_pass'] += 1

        # High-confidence gates (now ℤ₃-mixing-robust)
        is_high_meson  = (aspect == 'meson') and endpoint_diff and coherent
        is_high_baryon = (aspect == 'baryon') and all_three
        is_low_meson   = (aspect == 'meson') and not is_high_meson
        is_low_baryon  = (aspect == 'baryon') and not is_high_baryon

        if is_high_meson:
            high_m[comp_mask] = True; final = 'meson_high'
        elif is_high_baryon:
            high_b[comp_mask] = True; final = 'baryon_high'
        elif is_low_meson:
            low_m[comp_mask] = True;  final = 'meson_low'
        elif is_low_baryon:
            low_b[comp_mask] = True;  final = 'baryon_low'
        else:
            other[comp_mask] = True;  final = 'other'

        # Baryon vertex extraction: for every aspect-baryon that spans all
        # three ℤ₃ sectors at the voxel level, pick one representative
        # voxel per sector (the one closest to the component centroid).
        # These three sites form the triangle visualised in --render hadrons.
        baryon_vertices = None
        if (aspect == 'baryon') and all_three:
            cen = np.asarray(pm['centroid'])
            baryon_vertices = {}
            for k in (0, 1, 2):
                sel = (z3_at_comp == k)
                if not np.any(sel):
                    baryon_vertices = None
                    break
                coords_k = coords[sel]
                d = np.linalg.norm(coords_k.astype(float) - cen, axis=1)
                baryon_vertices[k] = tuple(map(float,
                                               coords_k[int(np.argmin(d))]))

        records.append(dict(
            cid=int(cid),
            volume=V,
            L=pm['L'], w=pm['w'], L_over_w=L_over_w,
            centroid=pm['centroid'], p0=pm['p0'], p1=pm['p1'],
            axis=pm['axis'],
            z3_p0=z3_p0, z3_p1=z3_p1,
            z3_endpoints_match=(z3_p0 == z3_p1),
            z3_sectors_at_component=z3_set_comp,
            z3_sectors_present_dilation=z3_set_dil,
            coherence=coh,
            endpoint_diff=endpoint_diff,
            coherent=coherent,
            all_three_sectors_in_component=all_three,
            baryon_vertices=baryon_vertices,
            classify_aspect=aspect,
            classify_z3_dilation=z3_cls,
            classify_final=final,
            agree=(aspect == z3_cls)
        ))
    return (records, high_m, low_m, high_b, low_b, other,
            int(active.sum()), counts)


# ─── Rendering ───────────────────────────────────────────────────────────

def _cube_mesh_faces(coords, size=1.0):
    if len(coords) == 0: return []
    half = size / 2.0
    offsets = np.array([
        [-half, -half, -half], [+half, -half, -half],
        [+half, +half, -half], [-half, +half, -half],
        [-half, -half, +half], [+half, -half, +half],
        [+half, +half, +half], [-half, +half, +half],
    ])
    face_idx = [[0,1,2,3], [4,5,6,7], [0,1,5,4],
                [2,3,7,6], [1,2,6,5], [0,3,7,4]]
    all_faces = []
    for c in coords:
        corners = c + offsets
        for fi in face_idx:
            all_faces.append(corners[fi])
    return all_faces


def add_cube_volume(ax, indicator_3d, color_rgb, alpha, size=1.05,
                    edgecolor=(0, 0, 0, 0.35), linewidth=0.25):
    coords = np.argwhere(indicator_3d)
    if len(coords) == 0: return
    faces = _cube_mesh_faces(coords, size=size)
    mesh = Poly3DCollection(faces, alpha=alpha)
    mesh.set_facecolor(list(color_rgb) + [alpha])
    mesh.set_edgecolor(edgecolor)
    mesh.set_linewidth(linewidth)
    ax.add_collection3d(mesh)


def fig_to_rgba(fig):
    fig.canvas.draw()
    img = np.asarray(fig.canvas.buffer_rgba())
    plt.close(fig)
    return img


# Sector → RGB triplet (shared with z3_rgb_movie.py colour convention)
SECTOR_RGB = {
    0: (1.00, 0.25, 0.25),   # R
    1: (0.25, 0.95, 0.30),   # G
    2: (0.30, 0.55, 1.00),   # B
}


def render_frame_hadrons(high_meson, low_meson, high_baryon, low_baryon,
                         other_sites, records, sweep_num, plaq_val,
                         F_floor, Delta_floor, threshold_high,
                         F_max, F_mean, az, elev, hide_low=False):
    """Hadron-geometry view.

    Mesons are drawn as dumbbells: two endpoint spheres coloured by the
    ℤ₃ sector at each endpoint, joined by a translucent flux-tube line.
    Baryons are drawn as triangles: one vertex per ℤ₃ sector with a
    translucent yellow singlet face. Low-confidence components, if shown,
    use muted versions of the same primitives. The faint gray dots of
    unclassified active voxels are kept as spatial context.
    """
    fig = plt.figure(figsize=(12, 10), facecolor='black')
    ax = fig.add_subplot(111, projection='3d', facecolor='black')

    # ── Faint context: unclassified active sites ──────────────────────
    o_coords = np.argwhere(other_sites)
    if len(o_coords) > 0:
        if len(o_coords) > 1200:
            idx = np.random.choice(len(o_coords), 1200, replace=False)
            o_coords = o_coords[idx]
        ax.scatter(o_coords[:, 0], o_coords[:, 1], o_coords[:, 2],
                   c='#666666', s=1.5, alpha=0.08, marker='.',
                   edgecolors='none')

    # Split records into the four buckets
    hi_m = [r for r in records if r['classify_final'] == 'meson_high']
    lo_m = [r for r in records if r['classify_final'] == 'meson_low']
    hi_b = [r for r in records
            if r['classify_final'] == 'baryon_high'
            and r.get('baryon_vertices') is not None]
    lo_b = [r for r in records
            if r['classify_final'] == 'baryon_low'
            and r.get('baryon_vertices') is not None]

    # ── Low-confidence layer (drawn first, muted) ────────────────────
    if not hide_low:
        # Low-confidence meson dumbbells
        if lo_m:
            lc = Line3DCollection(
                [[r['p0'], r['p1']] for r in lo_m],
                colors=(0.7, 0.7, 0.7, 0.25), linewidths=1.2)
            ax.add_collection3d(lc)
            for r in lo_m:
                ax.scatter([r['p0'][0]], [r['p0'][1]], [r['p0'][2]],
                           c=[SECTOR_RGB[r['z3_p0']]], s=60, alpha=0.35,
                           edgecolors='none', depthshade=True)
                ax.scatter([r['p1'][0]], [r['p1'][1]], [r['p1'][2]],
                           c=[SECTOR_RGB[r['z3_p1']]], s=60, alpha=0.35,
                           edgecolors='none', depthshade=True)
        # Low-confidence baryon triangles (only if vertices exist)
        if lo_b:
            tri_lo = [[r['baryon_vertices'][0],
                       r['baryon_vertices'][1],
                       r['baryon_vertices'][2]] for r in lo_b]
            pc = Poly3DCollection(tri_lo, facecolors=(1.0, 0.82, 0.0, 0.10),
                                  edgecolors=(1.0, 1.0, 1.0, 0.18),
                                  linewidths=0.6)
            ax.add_collection3d(pc)

    # ── High-confidence meson dumbbells ──────────────────────────────
    if hi_m:
        # Flux tube: white-ish, semi-transparent, thick
        tube_segments = [[r['p0'], r['p1']] for r in hi_m]
        lc = Line3DCollection(tube_segments,
                              colors=(0.95, 0.95, 0.95, 0.75),
                              linewidths=3.0)
        ax.add_collection3d(lc)
        # Endpoint spheres coloured by sector
        for r in hi_m:
            c0, c1 = SECTOR_RGB[r['z3_p0']], SECTOR_RGB[r['z3_p1']]
            ax.scatter([r['p0'][0]], [r['p0'][1]], [r['p0'][2]],
                       c=[c0], s=200, alpha=0.95,
                       edgecolors='white', linewidths=0.5, depthshade=True)
            ax.scatter([r['p1'][0]], [r['p1'][1]], [r['p1'][2]],
                       c=[c1], s=200, alpha=0.95,
                       edgecolors='white', linewidths=0.5, depthshade=True)

    # ── High-confidence baryon triangles ─────────────────────────────
    if hi_b:
        tri_hi = [[r['baryon_vertices'][0],
                   r['baryon_vertices'][1],
                   r['baryon_vertices'][2]] for r in hi_b]
        # Translucent singlet face (warm yellow)
        pc = Poly3DCollection(tri_hi, facecolors=(1.0, 0.82, 0.0, 0.30),
                              edgecolors=(1.0, 1.0, 1.0, 0.70),
                              linewidths=1.4)
        ax.add_collection3d(pc)
        # Vertices coloured per sector, batched per sector for speed
        per_sec = {0: [], 1: [], 2: []}
        for r in hi_b:
            for k in (0, 1, 2):
                per_sec[k].append(r['baryon_vertices'][k])
        for k in (0, 1, 2):
            if per_sec[k]:
                pts = np.array(per_sec[k])
                ax.scatter(pts[:, 0], pts[:, 1], pts[:, 2],
                           c=[SECTOR_RGB[k]], s=140, alpha=0.95,
                           edgecolors='white', linewidths=0.5,
                           depthshade=True)

    # ── Annotations ─────────────────────────────────────────────────
    n_hm = len(hi_m); n_lm = len(lo_m)
    n_hb = len(hi_b); n_lb = len(lo_b)
    coh_vals = [r['coherence'] for r in hi_m]
    coh_mean = float(np.mean(coh_vals)) if coh_vals else 0.0
    L_vals = [r['L'] for r in hi_m]
    L_mean = float(np.mean(L_vals)) if L_vals else 0.0

    ax.text2D(0.02, 0.97,
              f'F = sum_i |Im Tr P_0i|     '
              f'F_floor = {F_floor:.4f}     '
              f'Δ_floor (m*) = {Delta_floor:.4f}',
              transform=ax.transAxes, color='cyan', fontsize=9,
              bbox=dict(facecolor='black', alpha=0.5, pad=2))
    ax.text2D(0.02, 0.93,
              f'F threshold = {threshold_high:.4f}     '
              f'Sweep {sweep_num}   ⟨P⟩ = {plaq_val:.4f}   '
              f'F̄ = {F_mean:.3f}  F_max = {F_max:.3f}',
              transform=ax.transAxes, color='white', fontsize=8)
    ax.text2D(0.02, 0.85,
              f'Meson dumbbells  high: {n_hm}   low: {n_lm}',
              transform=ax.transAxes, color='#cccccc', fontsize=9)
    ax.text2D(0.02, 0.81,
              f'  ⟨coherence⟩(high) = {coh_mean:.2f}     '
              f'⟨L⟩(high) = {L_mean:.2f} lattice units',
              transform=ax.transAxes, color='#cccccc', fontsize=8)
    ax.text2D(0.02, 0.75,
              f'Baryon triangles  high: {n_hb}   low: {n_lb}',
              transform=ax.transAxes, color='#ffd400', fontsize=9)
    # Sector colour key
    ax.text2D(0.78, 0.97, '■ R sector',
              transform=ax.transAxes, color='#ff4040', fontsize=9,
              fontweight='bold')
    ax.text2D(0.78, 0.93, '■ G sector',
              transform=ax.transAxes, color='#40f050', fontsize=9,
              fontweight='bold')
    ax.text2D(0.78, 0.89, '■ B sector',
              transform=ax.transAxes, color='#5090ff', fontsize=9,
              fontweight='bold')

    ax.set_xlim(0, N); ax.set_ylim(0, N); ax.set_zlim(0, N)
    ax.set_xlabel('x', color='white', fontsize=8)
    ax.set_ylabel('y', color='white', fontsize=8)
    ax.set_zlabel('z', color='white', fontsize=8)
    ax.tick_params(colors='white', labelsize=6)
    for pane in (ax.xaxis.pane, ax.yaxis.pane, ax.zaxis.pane):
        pane.fill = False
        pane.set_edgecolor('#222222')
    ax.view_init(elev=elev, azim=az)

    fig.suptitle(
        f'CTC SU(3) — Hadron geometry    N={N}, β={beta}'
        + (f', α={alpha}' if alpha is not None else '') + '\n'
        f'Mesons as dumbbells (sector-coloured endpoints + flux tube)   '
        f'Baryons as triangles (R/G/B vertices + singlet face)',
        color='white', fontsize=10, y=0.995)
    fig.tight_layout()
    return fig_to_rgba(fig)


def render_frame(high_meson, low_meson, high_baryon, low_baryon, other_sites,
                 records, sweep_num, plaq_val,
                 F_floor, Delta_floor, threshold_high,
                 F_max, F_mean, az, elev, hide_low=False):
    fig = plt.figure(figsize=(12, 10), facecolor='black')
    ax = fig.add_subplot(111, projection='3d', facecolor='black')

    # Faint context: unclassified active sites
    o_coords = np.argwhere(other_sites)
    if len(o_coords) > 0:
        if len(o_coords) > 1500:
            idx = np.random.choice(len(o_coords), 1500, replace=False)
            o_coords = o_coords[idx]
        ax.scatter(o_coords[:, 0], o_coords[:, 1], o_coords[:, 2],
                   c='#888888', s=2.0, alpha=0.10, marker='.',
                   edgecolors='none')

    # Low-confidence shells (drawn first, behind). Suppressed entirely
    # when --hide_low is set, leaving only the high-confidence layer
    # against the faint gray-dot context for cleaner publication stills.
    if not hide_low:
        add_cube_volume(ax, low_baryon,
                        color_rgb=(1.0, 0.82, 0.0), alpha=0.30, size=1.05)
        add_cube_volume(ax, low_meson,
                        color_rgb=(0.0, 0.85, 1.0), alpha=0.30, size=1.05)

    # High-confidence cubes
    add_cube_volume(ax, high_baryon,
                    color_rgb=(1.0, 0.82, 0.0), alpha=0.90, size=1.05)
    add_cube_volume(ax, high_meson,
                    color_rgb=(0.0, 0.85, 1.0), alpha=0.80, size=1.05)

    # Principal-axis line for high-confidence mesons only
    tube_segments = [[r['p0'], r['p1']] for r in records
                     if r['classify_final'] == 'meson_high']
    if tube_segments:
        lc = Line3DCollection(tube_segments,
                              colors=(1.0, 1.0, 1.0, 0.95), linewidths=2.5)
        ax.add_collection3d(lc)

    # Annotations
    n_hm = sum(1 for r in records if r['classify_final'] == 'meson_high')
    n_lm = sum(1 for r in records if r['classify_final'] == 'meson_low')
    n_hb = sum(1 for r in records if r['classify_final'] == 'baryon_high')
    n_lb = sum(1 for r in records if r['classify_final'] == 'baryon_low')

    coh_vals = [r['coherence'] for r in records
                if r['classify_final'] == 'meson_high']
    coh_mean = float(np.mean(coh_vals)) if coh_vals else 0.0
    L_vals = [r['L'] for r in records if r['classify_final'] == 'meson_high']
    L_mean = float(np.mean(L_vals)) if L_vals else 0.0

    ax.text2D(0.02, 0.97,
              f'F = sum_i |Im Tr P_0i|     '
              f'F_floor = {F_floor:.4f}     '
              f'Δ_floor (m*) = {Delta_floor:.4f}',
              transform=ax.transAxes, color='cyan', fontsize=9,
              bbox=dict(facecolor='black', alpha=0.5, pad=2))
    ax.text2D(0.02, 0.93,
              f'F threshold = {threshold_high:.4f}     '
              f'Sweep {sweep_num}   ⟨P⟩ = {plaq_val:.4f}   '
              f'F̄ = {F_mean:.3f}  F_max = {F_max:.3f}',
              transform=ax.transAxes, color='white', fontsize=8)
    ax.text2D(0.02, 0.85,
              f'Meson tubes  high: {n_hm}   low: {n_lm}',
              transform=ax.transAxes, color='#00d8ff', fontsize=9)
    ax.text2D(0.02, 0.81,
              f'  ⟨coherence⟩(high) = {coh_mean:.2f}     '
              f'⟨L⟩(high) = {L_mean:.2f} lattice units',
              transform=ax.transAxes, color='#00d8ff', fontsize=8)
    ax.text2D(0.02, 0.75,
              f'Baryon junctions  high: {n_hb}   low: {n_lb}',
              transform=ax.transAxes, color='#ffd400', fontsize=9)

    # Agreement diagnostic
    n_meson_total = n_hm + n_lm
    agree_m = n_hm / n_meson_total if n_meson_total else 0.0
    n_baryon_total = n_hb + n_lb
    agree_b = n_hb / n_baryon_total if n_baryon_total else 0.0
    ax.text2D(0.02, 0.69,
              f'Classifier agreement   meson: {agree_m:.0%}     '
              f'baryon: {agree_b:.0%}',
              transform=ax.transAxes, color='#bbbbbb', fontsize=8)

    ax.set_xlim(0, N); ax.set_ylim(0, N); ax.set_zlim(0, N)
    ax.set_xlabel('x', color='white', fontsize=8)
    ax.set_ylabel('y', color='white', fontsize=8)
    ax.set_zlabel('z', color='white', fontsize=8)
    ax.tick_params(colors='white', labelsize=6)
    for pane in (ax.xaxis.pane, ax.yaxis.pane, ax.zaxis.pane):
        pane.fill = False
        pane.set_edgecolor('#222222')
    ax.view_init(elev=elev, azim=az)

    legend_line = ('Full opacity = both classifiers agree; '
                   'half opacity = single-classifier candidate'
                   if not hide_low
                   else 'High-confidence components only '
                        '(low-confidence suppressed by --hide_low)')
    fig.suptitle(
        f'CTC SU(3) — Unified meson/baryon readout    N={N}, β={beta}'
        + (f', α={alpha}' if alpha is not None else '') + '\n'
        f'Cyan: meson tubes (Im Tr P_{{0i}} aspect + ℤ₃ endpoints + flux coherence)   '
        f'Yellow: baryon junctions (compact + all 3 ℤ₃ sectors)\n'
        + legend_line,
        color='white', fontsize=10, y=0.995)
    fig.tight_layout()
    return fig_to_rgba(fig)


# ─── Pre-pass ────────────────────────────────────────────────────────────

delta_step = 0.15
plaq_val = measure_plaq(U)
print(f'\nInitial ⟨P⟩ = {plaq_val:.4f}')
print(f'\n[Pre-pass] Sampling {args.prepass_frames} frames for pinned thresholds ...')

prepass_F_thresh = []
prepass_F_floor  = []
prepass_Delta    = []
prepass_F_max    = []
prepass_F_mean   = []
prepass_f3ds     = []
prepass_plaq     = []                                          # NEW

for k in range(args.prepass_frames):
    U, rate, delta_step = metropolis_sweep(U, beta, delta_step)
    F4d, _ = compute_F_fields(U)
    f3d    = F4d[..., N // 2]
    prepass_F_floor.append(compute_F_floor(F4d))
    prepass_Delta.append(compute_mass_floor(U))
    prepass_F_thresh.append(float(np.percentile(f3d, args.threshold_pct)))
    prepass_F_max.append(float(F4d.max()))
    prepass_F_mean.append(float(F4d.mean()))
    prepass_f3ds.append(f3d.copy())
    prepass_plaq.append(measure_plaq(U))                       # NEW
    print(f'  pre {k+1}/{args.prepass_frames}: '
          f'F̄={prepass_F_mean[-1]:.4f}  F_max={prepass_F_max[-1]:.4f}  '
          f'F_floor={prepass_F_floor[-1]:.4f}  Δ_floor={prepass_Delta[-1]:.4f}  '
          f'F_thr({args.threshold_pct:.0f}%)={prepass_F_thresh[-1]:.4f}')

F_floor_pinned     = float(np.median(prepass_F_floor))
F_floor_pinned_std = float(np.std(prepass_F_floor))
Delta_floor_pinned     = float(np.median(prepass_Delta))
Delta_floor_pinned_std = float(np.std(prepass_Delta))
threshold_high     = float(np.median(prepass_F_thresh))
threshold_high_std = float(np.std(prepass_F_thresh))

# Stability check
print(f'\n  PINNED F_floor    = {F_floor_pinned:.4f}   '
      f'± {F_floor_pinned_std:.4f}   '
      f'({100*F_floor_pinned_std/max(F_floor_pinned,1e-9):.1f}%)')
print(f'  PINNED Δ_floor    = {Delta_floor_pinned:.4f}   '
      f'± {Delta_floor_pinned_std:.4f}   '
      f'({100*Delta_floor_pinned_std/max(Delta_floor_pinned,1e-9):.1f}%)')
print(f'  PINNED F threshold = {threshold_high:.4f}   '
      f'± {threshold_high_std:.4f}   '
      f'({100*threshold_high_std/max(threshold_high,1e-9):.1f}%)')

# ── Equilibration guard ──────────────────────────────────────────────
# A pre-thermalized checkpoint is stationary: the pre-pass ⟨P⟩ and F̄
# sequences should have no monotonic trend. A trend means the checkpoint
# still has thermalization left in it, the pinned threshold is stale by
# frame 1, and the movie will silently decay to an empty 0/0/0/0 history.
# Detect a trend (not just a spread) and refuse, rather than limp.
def _trend_frac(seq):
    """Signed end-to-end drift of a linear fit, as a fraction of the mean."""
    y = np.asarray(seq, dtype=float)
    if len(y) < 3:
        return 0.0
    x = np.arange(len(y))
    slope = np.polyfit(x, y, 1)[0]
    span = slope * (len(y) - 1)
    denom = abs(np.mean(y)) if abs(np.mean(y)) > 1e-12 else 1e-12
    return span / denom

plaq_trend = _trend_frac(prepass_plaq)
fmean_trend = _trend_frac(prepass_F_mean)
TREND_TOL = 0.05   # 5% end-to-end drift across the pre-pass

print(f'\n  Pre-pass trend check:  ⟨P⟩ drift = {100*plaq_trend:+.1f}%   '
      f'F̄ drift = {100*fmean_trend:+.1f}%   (tolerance ±{100*TREND_TOL:.0f}%)')

if abs(plaq_trend) > TREND_TOL or abs(fmean_trend) > TREND_TOL:
    sys.exit(
        '\nERROR: the input checkpoint is not equilibrated.\n'
        f'  Pre-pass ⟨P⟩ drifts {100*plaq_trend:+.1f}% and '
        f'F̄ drifts {100*fmean_trend:+.1f}% across {args.prepass_frames} '
        f'frames;\n'
        f'  a pre-thermalized U_final.npy should hold both flat to within '
        f'±{100*TREND_TOL:.0f}%.\n'
        '  The pinned F threshold would be stale by the first measurement '
        'frame\n'
        '  and the movie would decay to an empty 0/0/0/0 history.\n'
        '  Fix upstream: use a later U_final checkpoint, or extend '
        'eq_sweeps\n'
        '  in the production run until ⟨P⟩ plateaus before it is saved.')

# The pre-pass exists ONLY to pin thresholds. Its field values are
# thermalization-era and must not enter the measurement EMA. The EMA is
# seeded from the first real measurement frame instead (see main loop).
f3d_ema = None
connectivity_struct = make_connectivity_structure(args.connectivity)


# ─── Main loop ───────────────────────────────────────────────────────────

frames = []
hist = {
    'sweep': [], 'plaq': [], 'F_mean': [], 'F_max': [],
    'n_active': [],
    'n_meson_high': [], 'n_meson_low': [],
    'n_baryon_high': [], 'n_baryon_low': [],
    'n_z3_meson_only': [], 'n_aspect_meson_only': [],
    'meson_high_centroids': [], 'baryon_high_centroids': [],
    'coherence_high_mean': [], 'coherence_high_std': [],
    'L_mean_high': [], 'L_max_high': [],
    'L_over_w_mean_high': [],
    'agreement_meson': [], 'agreement_baryon': [],
    # Per-criterion failure breakdown so the user can see WHY a candidate
    # was rejected (endpoint match? coherence too low? not enough sectors?)
    'n_aspect_meson':                  [],
    'n_aspect_meson_endpoint_pass':    [],
    'n_aspect_meson_coherence_pass':   [],
    'coh_aspect_meson_median':         [],
    'coh_random_baseline':             [],   # per-frame null baseline
    'n_aspect_baryon':                 [],
    'n_aspect_baryon_z3_all3_pass':    [],
    'per_component': [],   # full per-component dump per frame
}

t0 = time.time()
n_frames = args.movie_sweeps // args.save_every
print(f'\n[Movie] {n_frames} frames over {args.movie_sweeps} sweeps')

for s in range(args.movie_sweeps):
    U, rate, delta_step = metropolis_sweep(U, beta, delta_step)
    if s % args.save_every == 0:
        idx = s // args.save_every
        plaq_val = measure_plaq(U)
        F4d, F_vec_4d = compute_F_fields(U)
        F_mean = float(F4d.mean()); F_max = float(F4d.max())

        f3d_raw = F4d[..., N // 2]
        if f3d_ema is None:
            f3d_ema = f3d_raw.copy()        # seed EMA from first real frame
        else:
            f3d_ema = args.ema * f3d_raw + (1.0 - args.ema) * f3d_ema
        f_vec_3d = F_vec_4d[..., N // 2, :]
        z3_3d = compute_z3_polyakov(U)

        (records, h_m, l_m, h_b, l_b, other_sites, n_active, counts) = \
            classify_unified(
                f3d_ema, f_vec_3d, z3_3d, threshold_high,
                args.L_over_w_min, args.V_min_meson, args.V_min_baryon,
                args.coherence_min, args.z3_radius,
                connectivity_struct, args.smooth_sigma)

        n_hm = sum(1 for r in records if r['classify_final'] == 'meson_high')
        n_lm = sum(1 for r in records if r['classify_final'] == 'meson_low')
        n_hb = sum(1 for r in records if r['classify_final'] == 'baryon_high')
        n_lb = sum(1 for r in records if r['classify_final'] == 'baryon_low')

        n_z3_only_m  = sum(1 for r in records
                           if r['classify_z3_dilation'] == 'meson'
                           and r['classify_aspect'] != 'meson')
        n_asp_only_m = sum(1 for r in records
                           if r['classify_aspect'] == 'meson'
                           and r['classify_z3_dilation'] != 'meson')

        coh_high = [r['coherence'] for r in records
                    if r['classify_final'] == 'meson_high']
        L_high   = [r['L'] for r in records
                    if r['classify_final'] == 'meson_high']
        Lw_high  = [r['L_over_w'] for r in records
                    if r['classify_final'] == 'meson_high']

        hist['sweep'].append(s)
        hist['plaq'].append(plaq_val)
        hist['F_mean'].append(F_mean)
        hist['F_max'].append(F_max)
        hist['n_active'].append(n_active)
        hist['n_meson_high'].append(n_hm)
        hist['n_meson_low'].append(n_lm)
        hist['n_baryon_high'].append(n_hb)
        hist['n_baryon_low'].append(n_lb)
        hist['n_z3_meson_only'].append(n_z3_only_m)
        hist['n_aspect_meson_only'].append(n_asp_only_m)
        hist['n_aspect_meson'].append(counts['n_aspect_meson'])
        hist['n_aspect_meson_endpoint_pass'].append(
            counts['n_aspect_meson_endpoint_pass'])
        hist['n_aspect_meson_coherence_pass'].append(
            counts['n_aspect_meson_coherence_pass'])
        hist['coh_aspect_meson_median'].append(
            float(np.median(counts['coh_aspect_meson']))
            if counts['coh_aspect_meson'] else 0.0)
        hist['n_aspect_baryon'].append(counts['n_aspect_baryon'])
        hist['n_aspect_baryon_z3_all3_pass'].append(
            counts['n_aspect_baryon_z3_all3_pass'])

        # Random-permutation coherence baseline. Uses median V of the
        # aspect-meson candidates this frame as the sample size; if no
        # aspect-mesons this frame, falls back to V_min_meson.
        if counts['n_aspect_meson'] > 0:
            V_typical = int(np.median(
                [r['volume'] for r in records
                 if r['classify_aspect'] == 'meson']))
        else:
            V_typical = args.V_min_meson
        active_mask_this_frame = (gaussian_filter(f3d_ema,
                                                  sigma=args.smooth_sigma)
                                  > threshold_high) if args.smooth_sigma > 0 \
                                  else (f3d_ema > threshold_high)
        coh_baseline = coherence_random_baseline(
            f_vec_3d, active_mask_this_frame, V_typical, n_trials=20)
        hist['coh_random_baseline'].append(coh_baseline)
        hist['meson_high_centroids'].append(
            [r['centroid'] for r in records
             if r['classify_final'] == 'meson_high'])
        hist['baryon_high_centroids'].append(
            [r['centroid'] for r in records
             if r['classify_final'] == 'baryon_high'])
        hist['coherence_high_mean'].append(
            float(np.mean(coh_high)) if coh_high else 0.0)
        hist['coherence_high_std'].append(
            float(np.std(coh_high)) if coh_high else 0.0)
        hist['L_mean_high'].append(float(np.mean(L_high)) if L_high else 0.0)
        hist['L_max_high'].append(float(np.max(L_high)) if L_high else 0.0)
        hist['L_over_w_mean_high'].append(
            float(np.mean(Lw_high)) if Lw_high else 0.0)
        total_m = n_hm + n_lm; total_b = n_hb + n_lb
        hist['agreement_meson'].append(n_hm / total_m if total_m else 0.0)
        hist['agreement_baryon'].append(n_hb / total_b if total_b else 0.0)
        hist['per_component'].append(records)

        az = (idx * args.rotations * 360 / max(n_frames, 1)) % 360
        render_fn = (render_frame_hadrons if args.render == 'hadrons'
                     else render_frame)
        hide_low_flag = not args.show_low   # default: True (hidden)
        img = render_fn(h_m, l_m, h_b, l_b, other_sites, records,
                        s, plaq_val,
                        F_floor_pinned, Delta_floor_pinned, threshold_high,
                        F_max, F_mean, az, args.elev,
                        hide_low=hide_low_flag)
        frames.append(img)

        elapsed = (time.time() - t0) / 60
        rem = (n_frames - idx - 1) * (time.time() - t0) / max(idx + 1, 1) / 60
        # Per-frame gate counts so the user can see WHICH criterion is filtering
        n_a_m   = counts['n_aspect_meson']
        n_ep    = counts['n_aspect_meson_endpoint_pass']
        n_co    = counts['n_aspect_meson_coherence_pass']
        coh_med = (float(np.median(counts['coh_aspect_meson']))
                   if counts['coh_aspect_meson'] else 0.0)
        n_a_b   = counts['n_aspect_baryon']
        n_b3    = counts['n_aspect_baryon_z3_all3_pass']
        # Coherence-vs-baseline reading: coh_med / coh_baseline > 1 means
        # the aspect-mesons have F-vector coherence above the random null
        coh_ratio = (coh_med / coh_baseline) if coh_baseline > 1e-6 else 0.0
        print(f'  frame {idx+1:3d}/{n_frames}  sw={s:4d}  '
              f'⟨P⟩={plaq_val:.4f}   '
              f'M[asp/ep/coh/hi]={n_a_m}/{n_ep}/{n_co}/{n_hm}   '
              f'B[asp/z3all/hi]={n_a_b}/{n_b3}/{n_hb}   '
              f'coh={coh_med:.2f}(base={coh_baseline:.2f}, '
              f'×{coh_ratio:.1f})  '
              f'el={elapsed:.1f}m rem~{rem:.1f}m')


# ─── Save outputs ────────────────────────────────────────────────────────

gif_path  = os.path.join(args.outdir, f'S5_meson_baryon_movie_{TAG}.gif')
hist_path = os.path.join(args.outdir,
                         f'S5_meson_baryon_movie_{TAG}_history.json')

print(f'\nSaving {len(frames)} frames to {gif_path} ...')
imageio.mimsave(gif_path, frames, fps=args.fps, loop=0)
print(f'Saved: {gif_path}  ({os.path.getsize(gif_path)/1024/1024:.1f} MB)')

with open(hist_path, 'w') as f:
    json.dump({
        'classifier':            'unified_F_aspect_with_z3_check',
        'movie_sweeps':          args.movie_sweeps,
        'save_every':            args.save_every,
        'ema':                   args.ema,
        'fps':                   args.fps,
        'rotations':             args.rotations,
        'elev':                  args.elev,
        'threshold_pct':         args.threshold_pct,
        'L_over_w_min':          args.L_over_w_min,
        'V_min_meson':           args.V_min_meson,
        'V_min_baryon':          args.V_min_baryon,
        'coherence_min':         args.coherence_min,
        'z3_radius':             args.z3_radius,
        'connectivity':          args.connectivity,
        'smooth_sigma':          args.smooth_sigma,
        'F_floor_pinned':        F_floor_pinned,
        'F_floor_pinned_std':    F_floor_pinned_std,
        'Delta_floor_pinned':    Delta_floor_pinned,
        'Delta_floor_pinned_std': Delta_floor_pinned_std,
        'threshold_high':        threshold_high,
        'threshold_high_std':    threshold_high_std,
        'history':               hist,
    }, f, indent=2)
print(f'History: {hist_path}')


# Summary
n_hm_arr = np.asarray(hist['n_meson_high'])
n_lm_arr = np.asarray(hist['n_meson_low'])
n_hb_arr = np.asarray(hist['n_baryon_high'])
n_lb_arr = np.asarray(hist['n_baryon_low'])
agree_m  = np.asarray(hist['agreement_meson'])
agree_b  = np.asarray(hist['agreement_baryon'])
coh_arr  = np.asarray(hist['coherence_high_mean'])
L_arr    = np.asarray(hist['L_mean_high'])

print('\n=== Run-averaged diagnostics ===')
print(f'  ⟨n meson high⟩     = {n_hm_arr.mean():.2f} ± {n_hm_arr.std():.2f}')
print(f'  ⟨n meson low⟩      = {n_lm_arr.mean():.2f} ± {n_lm_arr.std():.2f}')
print(f'  ⟨n baryon high⟩    = {n_hb_arr.mean():.2f} ± {n_hb_arr.std():.2f}')
print(f'  ⟨n baryon low⟩     = {n_lb_arr.mean():.2f} ± {n_lb_arr.std():.2f}')
print(f'  ⟨classifier agreement, meson⟩  = {agree_m.mean():.1%}')
print(f'  ⟨classifier agreement, baryon⟩ = {agree_b.mean():.1%}')
print(f'  ⟨coherence, high-conf meson⟩   = {coh_arr.mean():.2f} '
      f'± {coh_arr.std():.2f}')

# Run-averaged coherence-vs-baseline comparison
coh_med_arr = np.asarray(hist['coh_aspect_meson_median'])
coh_base_arr = np.asarray(hist['coh_random_baseline'])
nonzero = (coh_base_arr > 1e-6) & (coh_med_arr > 1e-6)
if nonzero.any():
    ratio_arr = coh_med_arr[nonzero] / coh_base_arr[nonzero]
    print(f'  ⟨coh_med / coh_baseline⟩      = '
          f'{ratio_arr.mean():.2f} ± {ratio_arr.std():.2f}')
    print(f'     ratio > 1  =>  aspect-mesons coherent above random null')
    print(f'     ratio ~ 1  =>  components are noise concentrations, not tubes')
if (L_arr > 0).any():
    print(f'  ⟨L⟩ high-conf meson tube       = {L_arr[L_arr>0].mean():.2f} '
          f'lattice units')
print(f'\n  F_floor = {F_floor_pinned:.4f}   '
      f'Δ_floor (m*) = {Delta_floor_pinned:.4f}')
print(f'  Both floors > 0 confirms F and m* are bounded away from zero in '
      f'the CTC vacuum,')
print(f'  i.e. precisely the chromomagnetic flux Wilson sets to zero on '
      f'average.')
print('\nDone.')
