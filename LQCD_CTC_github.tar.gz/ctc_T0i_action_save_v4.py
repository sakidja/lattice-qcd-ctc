#!/usr/bin/env python3
"""
ctc_T0i_action_save_v4.py — CTC SU(3) T0i augmented action with U_final save.

CHANGES FROM v3 (ctc_T0i_action_save_v3.py):
  Methodology now matches ctc_beta5.py exactly. The T0i action augmentation
  (alpha-scan), Polyakov-loop Z3 classifier, eq+measurement phase split,
  U_final save, and T0i diagnostics are all preserved unchanged. Only the
  core-identification and hadron-counting routines have been swapped.

  1. STRICT VORTEX CORE FILTER. compute_ctc now returns center_charge
     based on (trP < 1.0) projection, summed across all six planes. A
     "core" is now a local maximum of m* AT A SITE WITH AT LEAST ONE
     STRICT-VORTEX PLAQUETTE — matching ctc_beta5.py and the paper's
     definition of a vortex core. v3's find_cores used a dead z3 filter
     (np.any([z3==0,z3==1,z3==2]) is always True since z3 is in {0,1,2}),
     so it returned every local mass peak whether or not it was actually
     in a vortex state. v4 fixes this.

  2. ADAPTIVE HADRON DISTANCE THRESHOLDS. v3 used fixed --meson_dist=3
     and --baryon_dist=4. v4 uses ctc_beta5.py's adaptive scheme:
       d_mean       = (N^4 / n_cores)^(1/4)              # mean inter-core spacing
       meson_reach  = max(10, int(2.5 * d_mean))         # ~12 lattice units at N=24
       baryon_perim = max(25, int(3.5 * meson_reach))    # perimeter cap, not pair cap
     Baryons are now perimeter-bounded rather than mutual-pair-bounded,
     and planarity is t_spread < 0.15*N (time-coplanar Y-junction), both
     matching ctc_beta5.py. The CLI args --meson_dist and --baryon_dist
     have been removed.

  3. PER-COLOR MESON SAMPLING. find_rgb_mesons now mirrors the structure
     of find_rgb_baryons: per-color cap (max_per_color=1000) preventing
     any one Z3 sector from consuming the search subset. v3's meson
     counter had no cap at all so this is a defensive change rather
     than a bug fix; at the N=24 alpha-scan range, the cap never binds.

  4. R-INCLUSIVE BARYON SEARCH. find_rgb_baryons uses the same
     per-color-sampling structure (max_per_color=200, lower because
     baryons are O(n^3)). Independent of meson assignment — a core can
     appear in both the meson list and the baryon list (v3 had
     mesons-claim-first). This matches ctc_beta5.py.

  5. MESON TYPE BREAKDOWN PRESERVED. n_mes_RR / n_mes_GB / n_mes_BG
     are still computed and stored in records, so existing alpha-scan
     plotting scripts continue to work.

USAGE:
  python3 ctc_T0i_action_save_v4.py --N 24 --beta 5.8 --alpha 0.6 \\
       --sweeps 500 --eq_sweeps 1500 --seed 42

OUTPUT (per run):
  run_TAG.log
  monitor_TAG.log
  records_TAG.json    (same columns as v3)
  U_final_TAG.npy
"""

import numpy as np
import warnings, datetime, os, json, argparse, time
from scipy.ndimage import maximum_filter
from scipy.stats import gaussian_kde
warnings.filterwarnings('ignore')

parser = argparse.ArgumentParser()
parser.add_argument('--N',             type=int,   default=24)
parser.add_argument('--beta',          type=float, default=5.8)
parser.add_argument('--alpha',         type=float, default=0.0)
parser.add_argument('--sweeps',        type=int,   default=500)
parser.add_argument('--eq_sweeps',     type=int,   default=400)
parser.add_argument('--measure_every', type=int,   default=10)
parser.add_argument('--seed',          type=int,   default=42)
parser.add_argument('--outdir',        type=str,   default='.')
parser.add_argument('--planar_tol',    type=float, default=0.15,
                    help='Planarity threshold as fraction of N for t_spread '
                         '(matches ctc_beta5.py default 0.15)')
args = parser.parse_args()

N     = args.N
beta  = args.beta
alpha = args.alpha
SEED  = args.seed
np.random.seed(SEED)

TAG = f"N{N}_b{beta:.1f}_a{alpha:.2f}_s{SEED}"
OUTPUT_DIR = args.outdir
os.makedirs(OUTPUT_DIR, exist_ok=True)
LOG_FILE = os.path.join(OUTPUT_DIR, f"run_{TAG}.log")

def log(msg):
    print(msg, flush=True)
    with open(LOG_FILE, 'a') as f:
        f.write(msg + '\n')

log("="*80)
log(f"CTC SU(3) — T0i AUGMENTED ACTION v4 (ctc_beta5.py-aligned methodology)")
MONITOR_LOG = f"monitor_{TAG}.log"
try:
    if os.path.exists(MONITOR_LOG): os.remove(MONITOR_LOG)
    os.symlink(LOG_FILE, MONITOR_LOG)
except: pass
log(f"Monitor: tail -f {MONITOR_LOG}")
log(f"N={N}  beta={beta}  alpha={alpha}  seed={SEED}")
log(f"Equilibration: {args.eq_sweeps} sweeps (not measured)")
log(f"Measurement:   {args.sweeps} sweeps")
log(f"Action: S = S_Wilson + {alpha} * sum_x sum_i (Im Tr[P_0i(x)])^2")
log(f"Z3 classifier: Polyakov-loop trace phase (true topological sector)")
log(f"  + parallel single-plane plaquette classifier kept for diagnostics")
log(f"Cores: local max of m* AND strict vortex (trP<1.0 on >=1 plaquette)")
log(f"Hadron thresholds: adaptive (meson 2.5*d_mean, baryon perim 3.5*meson)")
log(f"Planarity: t_spread < {args.planar_tol}*N")
log("="*80)

PLANES   = [(0,1),(0,2),(0,3),(1,2),(1,3),(2,3)]
TEMPORAL = [(0,1),(0,2),(0,3)]


# ── SU(3) primitives (unchanged from v3) ──────────────────────────────────────

def random_su3_batch(shape):
    size = int(np.prod(shape))
    A = np.random.randn(size,3,3) + 1j*np.random.randn(size,3,3)
    Q,R = np.linalg.qr(A)
    d = np.linalg.det(Q)
    return (Q/(d[:,None,None]**(1/3))).reshape(*shape,3,3)

def project_su3_batch(M):
    sh = M.shape; sz = int(np.prod(sh[:-2]))
    M2 = M.reshape(sz,3,3)
    U,_,Vh = np.linalg.svd(M2)
    Q = U @ Vh
    d = np.linalg.det(Q)
    return (Q/(d[:,None,None]**(1/3))).reshape(sh)

def plaq(U, mu, nu):
    P = U[mu] @ np.roll(U[nu],-1,axis=mu)
    P = P @ np.roll(U[mu],-1,axis=nu).conj().swapaxes(-1,-2)
    return P @ U[nu].conj().swapaxes(-1,-2)

def staple(U, mu):
    S = np.zeros((N,N,N,N,3,3), dtype=complex)
    for nu in range(4):
        if nu==mu: continue
        fwd = (U[nu] @ np.roll(U[mu],-1,axis=nu)
               @ np.roll(U[nu],-1,axis=mu).conj().swapaxes(-1,-2))
        Ub  = np.roll(U[nu],1,axis=nu)
        bwd = (Ub.conj().swapaxes(-1,-2)
               @ np.roll(U[mu],1,axis=nu)
               @ np.roll(Ub,-1,axis=mu))
        S  += fwd + bwd
    return S


# ── Parity mask (unchanged) ───────────────────────────────────────────────────
_x,_y,_z,_t = np.meshgrid(*[np.arange(N)]*4, indexing='ij')
PAR = (_x+_y+_z+_t) % 2


# ── T0i field (unchanged from v3) ─────────────────────────────────────────────

def compute_T0i(U):
    T0i_sq = np.zeros((N,N,N,N))
    vals = []
    for mu,nu in TEMPORAL:
        P   = plaq(U, mu, nu)
        trP = np.trace(P, axis1=-2, axis2=-1)
        im  = np.abs(np.imag(trP))
        T0i_sq += np.imag(trP)**2
        vals.append(im)
    all_vals = np.concatenate([v.flatten() for v in vals])
    return float(np.mean(all_vals)), float(np.std(all_vals)), T0i_sq


# ── Metropolis (unchanged from v3) ────────────────────────────────────────────

def metropolis_sweep(U, beta, alpha, delta):
    accepted = total = 0
    for mu in range(4):
        S = staple(U, mu)
        if alpha > 0.0:
            _, _, T0i_sq_old = compute_T0i(U)

        for p in [0,1]:
            mask = (PAR==p); idx = np.where(mask)
            old  = U[mu][idx].copy()
            new  = project_su3_batch(
                       old + delta*(random_su3_batch((len(idx[0]),)) - old))

            dS = beta*(np.real(np.trace(new@S[idx],axis1=-2,axis2=-1))
                      -np.real(np.trace(old@S[idx],axis1=-2,axis2=-1)))

            if alpha > 0.0:
                U_test = list(U); U_test[mu] = U[mu].copy()
                U_test[mu][idx] = new
                _, _, T0i_sq_new = compute_T0i(U_test)
                dS_T0i = alpha*(T0i_sq_new - T0i_sq_old)
                dS_T0i_site = np.zeros(len(idx[0]))
                for k,site in enumerate(zip(*idx)):
                    dS_T0i_site[k] = float(np.sum(
                        dS_T0i[max(0,site[0]-1):site[0]+2,
                               max(0,site[1]-1):site[1]+2,
                               max(0,site[2]-1):site[2]+2,
                               max(0,site[3]-1):site[3]+2]))
                dS += dS_T0i_site

            acc = np.random.random(len(idx[0])) < np.exp(np.clip(dS,-100,0))
            fa  = np.zeros((N,N,N,N), dtype=bool); fa[idx] = acc
            U[mu][fa] = new[acc]
            accepted += int(acc.sum()); total += len(idx[0])

    rate  = accepted / max(total, 1)
    if rate > 0.6:
        delta = min(delta * 1.05, 0.5)
    elif rate < 0.4:
        delta = max(delta * 0.95, 0.15)
    return U, rate, delta


# ── Z3 classifiers (unchanged from v3) ────────────────────────────────────────

def compute_z3_polyakov(U):
    """True topological Z3 sector at each spatial site via Polyakov loop.
    L(x,y,z) = U_t(x,y,z,0) @ U_t(x,y,z,1) @ ... @ U_t(x,y,z,N-1)
    arg(Tr L) ∈ {≈0, ≈2π/3, ≈4π/3} → sector k = 0, 1, 2.
    Returns 4D array with same Z3 sector tiled across all t.
    """
    L = U[0][:, :, :, 0, :, :].copy()
    for tau in range(1, N):
        L = np.matmul(L, U[0][:, :, :, tau, :, :])
    Tr_L = np.trace(L, axis1=-2, axis2=-1)
    angle = np.angle(Tr_L) % (2 * np.pi)
    z3_3d = np.round(angle * 3.0 / (2 * np.pi)).astype(int) % 3
    return np.broadcast_to(z3_3d[:, :, :, None], (N, N, N, N)).copy()


def compute_z3_plaquette_old(U):
    """Original v2 single-plane (0,1) plaquette argmax classifier.
    Kept for direct comparison with the Polyakov-loop classifier."""
    P01  = plaq(U, 0, 1)
    tr01 = np.trace(P01, axis1=-2, axis2=-1)
    vals = np.stack([np.real(tr01*np.exp(-2j*np.pi*k/3)) for k in range(3)],axis=-1)
    return np.argmax(vals, axis=-1).astype(int)


# ── CTC observables — UPDATED to return center_charge (matches ctc_beta5.py) ──

def compute_ctc(U):
    """
    Returns curv, mass, div, center_charge.

    center_charge[x] = +1 if at least one of the 6 plaquettes at site x has
    Re Tr[P]/3 < 1/3 (i.e. trP < 1.0, the strict vortex projection),
    else -1. This is the gateway condition for "vortex core" used in
    ctc_beta5.py and the paper text. v3 dropped this filter; v4 restores it.
    """
    curv = np.zeros((N,N,N,N))
    div  = np.zeros((N,N,N,N))
    cent = np.zeros((N,N,N,N), dtype=int)
    for mu,nu in PLANES:
        P   = plaq(U,mu,nu)
        trP = np.real(np.trace(P,axis1=-2,axis2=-1))
        curv += np.arccos(np.clip(trP/3.0, -1.0, 1.0))
        # ── STRICT center projection: trP < 1.0 (matches ctc_beta5.py) ──
        cent += (trP < 1.0).astype(int)
        for rho in range(4):
            if rho == mu or rho == nu: continue
            Pf = np.roll(P,-1,axis=rho)
            T  = U[rho] @ Pf @ U[rho].conj().swapaxes(-1,-2)
            div += np.sqrt(np.sum(np.abs(P - T)**2, axis=(-2,-1)))
    curv /= len(PLANES)
    div   = div/len(PLANES) + 1e-6
    mass  = curv/div
    center_charge = np.where(cent > 0, 1, -1)
    return curv, mass, div, center_charge


def extract_delta(mass, div):
    mask = (div>1e-6)&(mass<100)&(mass>0)
    m = mass[mask].flatten()
    if len(m) < 10:
        return float(np.percentile(m, 0.5)), 0.0
    try:
        kde  = gaussian_kde(m, bw_method='silverman')
        xr   = np.linspace(m.min(), np.percentile(m, 25), 1000)
        dens = kde(xr)
        noise = np.percentile(dens, 5)
        above = xr[dens > 3.0*noise]
        gap   = float(above[0]) if len(above) > 0 else float(np.percentile(m, 0.5))
        gd    = kde(np.array([gap]))[0]
        err   = float(0.5/(gd*len(m)) if gd > 0 else 0.0)
        return gap, err
    except:
        return float(np.percentile(m, 0.5)), 0.0


# ── Core identification — UPDATED to use strict vortex filter ─────────────────

def find_cores(mass, center_charge, peak_radius=2):
    """Local maxima of m* that also sit at a strict-vortex site.
    Matches ctc_beta5.py's find_eddy_cores exactly.
    """
    local_max = (mass == maximum_filter(mass, size=peak_radius*2+1))
    return np.argwhere(local_max & (center_charge == 1))


# ── Distance utility (matches ctc_beta5.py) ───────────────────────────────────

def pbc_dist(p1, p2):
    diff = np.abs(p1.astype(int) - p2.astype(int))
    return float(np.sqrt(np.sum(np.minimum(diff, N - diff)**2)))


# ── Hadron searches — replaced with ctc_beta5.py's per-color-sampling versions ─

def find_rgb_mesons(cores, z3_charges, mass, max_dist):
    """
    Per-color-sampling meson search (matches ctc_beta5.py with the
    2026-05-08 meson cap fix).

    A meson is any pair of eddy cores whose Z3 charges sum to 0 mod 3:
    (R,R), (G,B), or (B,G). Returns a list of dicts so the caller can
    extract type breakdown (n_mes_RR / n_mes_GB / n_mes_BG).
    """
    if len(cores) < 2:
        return []
    mesons = []
    used = set()

    r_idx = np.where(z3_charges == 0)[0]
    g_idx = np.where(z3_charges == 1)[0]
    b_idx = np.where(z3_charges == 2)[0]

    # Per-color cap (defensive; doesn't bind at N=24 alpha scan range).
    max_per_color = 1000

    if len(r_idx) > max_per_color:
        r_sample = np.random.choice(r_idx, max_per_color, replace=False)
    else:
        r_sample = r_idx
    if len(g_idx) > max_per_color:
        g_sample = np.random.choice(g_idx, max_per_color, replace=False)
    else:
        g_sample = g_idx
    if len(b_idx) > max_per_color:
        b_sample = np.random.choice(b_idx, max_per_color, replace=False)
    else:
        b_sample = b_idx

    sample_idx     = np.concatenate([r_sample, g_sample, b_sample]).astype(int)
    sample_cores   = cores[sample_idx]
    sample_charges = z3_charges[sample_idx]

    n = len(sample_cores)
    for i in range(n):
        if i in used:
            continue
        c1 = int(sample_charges[i])
        best_dist = max_dist + 1
        best_j = -1
        for j in range(n):
            if j == i or j in used:
                continue
            if (c1 + int(sample_charges[j])) % 3 != 0:
                continue
            d = pbc_dist(sample_cores[i], sample_cores[j])
            if d < best_dist:
                best_dist = d
                best_j = j
        if best_j >= 0 and best_dist <= max_dist:
            mesons.append({
                'charge1': c1,
                'charge2': int(sample_charges[best_j]),
                'distance': best_dist,
                'total_mass': float(
                    mass[tuple(sample_cores[i])] +
                    mass[tuple(sample_cores[best_j])]
                )
            })
            used.add(i)
            used.add(best_j)
    return mesons


def find_rgb_baryons(cores, z3_charges, mass, max_perim, planarity_thresh):
    """
    R-inclusive baryon search with per-color-cap sampling. Independent
    of meson assignment — a core can appear in both the meson list and
    the baryon list. Matches ctc_beta5.py exactly.
    """
    if len(cores) < 3:
        return []
    baryons = []
    t_thresh = planarity_thresh * N

    r_idx = np.where(z3_charges == 0)[0]
    g_idx = np.where(z3_charges == 1)[0]
    b_idx = np.where(z3_charges == 2)[0]

    max_per_color = 200

    if len(r_idx) > max_per_color:
        r_sample = np.random.choice(r_idx, max_per_color, replace=False)
    else:
        r_sample = r_idx
    if len(g_idx) > max_per_color:
        g_sample = np.random.choice(g_idx, max_per_color, replace=False)
    else:
        g_sample = g_idx
    if len(b_idx) > max_per_color:
        b_sample = np.random.choice(b_idx, max_per_color, replace=False)
    else:
        b_sample = b_idx

    sample_idx     = np.concatenate([r_sample, g_sample, b_sample]).astype(int)
    sample_cores   = cores[sample_idx]
    sample_charges = z3_charges[sample_idx]

    n = len(sample_cores)
    for i in range(n):
        if len(baryons) > 500: break
        for j in range(i+1, n):
            for k in range(j+1, n):
                c1 = int(sample_charges[i])
                c2 = int(sample_charges[j])
                c3 = int(sample_charges[k])
                if sorted([c1, c2, c3]) != [0, 1, 2]:
                    continue
                v1, v2, v3 = sample_cores[i], sample_cores[j], sample_cores[k]
                d12 = pbc_dist(v1, v2)
                d23 = pbc_dist(v2, v3)
                d31 = pbc_dist(v3, v1)
                perim = d12 + d23 + d31
                if perim >= max_perim:
                    continue
                # Triangle inequality
                if not (d12 + d23 > d31 and
                        d23 + d31 > d12 and
                        d31 + d12 > d23):
                    continue
                t_spread = float(max(v1[3], v2[3], v3[3]) -
                                 min(v1[3], v2[3], v3[3]))
                baryons.append({
                    'perimeter': float(perim),
                    'total_mass': float(
                        mass[tuple(v1)] + mass[tuple(v2)] + mass[tuple(v3)]
                    ),
                    'is_planar': t_spread < t_thresh,
                    't_spread': t_spread
                })
    return baryons


# ── measure_all: UPDATED to use the new core+hadron pipeline ──────────────────

def measure_all(U):
    plaq_sum = 0.0; total = 0
    for mu, nu in PLANES:
        trP = np.real(np.trace(plaq(U, mu, nu), axis1=-2, axis2=-1))
        plaq_sum += np.sum(trP) / 3.0; total += trP.size
    plaq_val = plaq_sum / total

    curv, mass, div, center_charge = compute_ctc(U)
    delta_val, delta_err = extract_delta(mass, div)

    # CORRECTED Z3 (Polyakov-loop)
    z3_poly = compute_z3_polyakov(U)
    cores   = find_cores(mass, center_charge)
    n_cores = len(cores)

    if n_cores > 0:
        z3_charges = z3_poly[cores[:,0], cores[:,1], cores[:,2], cores[:,3]]
        n_R = int(np.sum(z3_charges == 0))
        n_G = int(np.sum(z3_charges == 1))
        n_B = int(np.sum(z3_charges == 2))
        rgb = [n_R, n_G, n_B]
        z3_balance = min(rgb) / max(rgb) if max(rgb) > 0 else 0.0
    else:
        z3_charges = np.array([], dtype=int)
        n_R = n_G = n_B = 0
        z3_balance = 0.0

    # OLD Z3 (single-plane plaquette) — kept for diagnostics
    z3_plaq = compute_z3_plaquette_old(U)
    if n_cores > 0:
        z3c_p = z3_plaq[cores[:,0], cores[:,1], cores[:,2], cores[:,3]]
        n_R_p = int(np.sum(z3c_p == 0))
        n_G_p = int(np.sum(z3c_p == 1))
        n_B_p = int(np.sum(z3c_p == 2))
    else:
        n_R_p = n_G_p = n_B_p = 0

    # Adaptive hadron thresholds (match ctc_beta5.py)
    if n_cores > 0:
        d_mean       = (N**4 / max(n_cores, 1))**0.25
        meson_reach  = max(10, int(2.5 * d_mean))
        baryon_perim = max(25, int(3.5 * meson_reach))
        mesons  = find_rgb_mesons(cores, z3_charges, mass, meson_reach)
        baryons = find_rgb_baryons(cores, z3_charges, mass,
                                   baryon_perim, args.planar_tol)
    else:
        mesons  = []
        baryons = []
        meson_reach = 0; baryon_perim = 0

    n_mesons = len(mesons)
    n_RR = sum(1 for m in mesons if m['charge1'] == 0 and m['charge2'] == 0)
    n_GB = sum(1 for m in mesons if (m['charge1'], m['charge2']) == (1, 2))
    n_BG = sum(1 for m in mesons if (m['charge1'], m['charge2']) == (2, 1))

    n_baryons = len(baryons)
    n_planar  = sum(1 for b in baryons if b['is_planar'])

    # Mass ratio (eddy / background)
    eddy_m = [float(mass[tuple(c)]) for c in cores if mass[tuple(c)] < 100]
    bg_m = []
    rng = np.random.default_rng(SEED + 1)
    attempts = 0
    while len(bg_m) < 500 and attempts < 5000:
        pt = tuple(rng.integers(0, N, 4))
        if mass[pt] < 100:
            if n_cores > 0:
                d_min = min(pbc_dist(c, np.array(pt)) for c in cores)
                if d_min > 5:
                    bg_m.append(float(mass[pt]))
            else:
                bg_m.append(float(mass[pt]))
        attempts += 1
    mass_ratio = (float(np.mean(eddy_m) / np.mean(bg_m))
                  if eddy_m and bg_m else 1.0)

    T0i_mean, T0i_std, _ = compute_T0i(U)

    vx_pct = 0.0
    for mu, nu in PLANES:
        trP = np.real(np.trace(plaq(U, mu, nu), axis1=-2, axis2=-1))
        vx_pct += float(np.mean(np.abs(trP / 3) < 0.99)) * 100
    vx_pct /= len(PLANES)

    return dict(
        plaquette    = float(plaq_val),
        vortex_pct   = float(vx_pct),
        delta_val    = float(delta_val),
        mass_gap     = float(delta_val),
        mass_gap_err = float(delta_err),
        n_cores      = int(n_cores),
        # Polyakov Z3 (primary)
        n_R = n_R, n_G = n_G, n_B = n_B,
        z3_balance   = float(z3_balance),
        # Plaquette Z3 (parallel diagnostic)
        n_R_plaq = n_R_p, n_G_plaq = n_G_p, n_B_plaq = n_B_p,
        # Hadron counts
        n_mesons   = n_mesons,
        n_mes_RR   = n_RR,
        n_mes_GB   = n_GB,
        n_mes_BG   = n_BG,
        n_baryons  = n_baryons,
        n_planar   = n_planar,
        # Adaptive thresholds (logged for diagnostics)
        meson_reach  = int(meson_reach),
        baryon_perim = int(baryon_perim),
        # Existing
        mass_ratio = float(mass_ratio),
        T0i_mean   = float(T0i_mean),
        T0i_std    = float(T0i_std),
    )


# ── Initialise ────────────────────────────────────────────────────────────────

log(f"\nInitializing U[4,{N},{N},{N},{N},3,3]...")
U     = random_su3_batch((4,N,N,N,N))
delta = 0.15
log("Done.\n")


# ── Phase 1: Equilibration ────────────────────────────────────────────────────

log(f"[Phase 1] Equilibrating ({args.eq_sweeps} sweeps — not recorded)...")
t0 = time.time()
for s in range(args.eq_sweeps):
    U, rate, delta = metropolis_sweep(U, beta, alpha, delta)
    if s % 50 == 0 or s == args.eq_sweeps-1:
        pl = np.mean([np.real(np.trace(plaq(U,mu,nu),axis1=-2,axis2=-1)).mean()/3
                      for mu,nu in PLANES])
        el = (time.time()-t0)/60
        rem = (args.eq_sweeps-s-1)*(time.time()-t0)/max(s+1,1)/60
        log(f"  EQ {s:5d}/{args.eq_sweeps}: <P>={pl:.4f}  delta={delta:.3f}  "
            f"acc={rate:.3f}  elapsed={el:.1f}m  rem~{rem:.1f}m")

log(f"\n[Phase 2] Measuring ({args.sweeps} sweeps)...")
log("-"*80)


# ── Phase 2: Measurement ──────────────────────────────────────────────────────

records = {k:[] for k in [
    'sweep','plaquette','vortex_pct','acceptance',
    'delta_val','mass_gap','mass_gap_err',
    'n_cores','n_R','n_G','n_B','z3_balance',
    'n_R_plaq','n_G_plaq','n_B_plaq',
    'n_mesons','n_mes_RR','n_mes_GB','n_mes_BG',
    'n_baryons','n_planar',
    'meson_reach','baryon_perim',
    'mass_ratio','T0i_mean','T0i_std',
]}
records['alpha']      = alpha
records['beta']       = beta
records['N']          = N
records['seed']       = SEED
records['eq_sweeps']  = args.eq_sweeps
records['classifier'] = 'polyakov_loop_phase'
records['core_def']   = 'local_max_AND_strict_vortex_trP_lt_1.0'
records['hadron_thresholds'] = 'adaptive_2.5_dmean_perim_3.5x'
records['planar_tol'] = args.planar_tol

t0 = time.time()
for s in range(args.sweeps):
    U, rate, delta = metropolis_sweep(U, beta, alpha, delta)

    if s % args.measure_every == 0 or s == args.sweeps-1:
        t1 = time.time()
        obs = measure_all(U)
        t_ms = time.time()-t1

        records['sweep'].append(s)
        records['acceptance'].append(float(rate))
        for k,v in obs.items():
            if k in records:
                records[k].append(v)

        with open(os.path.join(OUTPUT_DIR,f'records_{TAG}.json'),'w') as f:
            json.dump(records, f, indent=2)

        el = (time.time()-t0)/60
        log(f"  SW {s:4d}: <P>={obs['plaquette']:.4f}  "
            f"Δ={obs['delta_val']:.5f}±{obs['mass_gap_err']:.5f}  "
            f"T0i={obs['T0i_mean']:.4f}  "
            f"cores={obs['n_cores']}  "
            f"RGB_poly=({obs['n_R']}/{obs['n_G']}/{obs['n_B']})  "
            f"RGB_plaq=({obs['n_R_plaq']}/{obs['n_G_plaq']}/{obs['n_B_plaq']})  "
            f"mes={obs['n_mesons']}({obs['n_mes_RR']}+{obs['n_mes_GB']+obs['n_mes_BG']})  "
            f"bar={obs['n_baryons']}({obs['n_planar']}pl)  "
            f"reach={obs['meson_reach']}/{obs['baryon_perim']}  "
            f"acc={rate:.3f}  t={el:.1f}m")


# ── Summary ───────────────────────────────────────────────────────────────────

sw_arr  = np.array(records['sweep'])
eq_cut  = args.sweeps // 2
eq_mask = sw_arr >= eq_cut

def eq_mean(key):
    v = np.array(records[key])[eq_mask]
    return float(np.mean(v)), float(np.std(v))

d_m, d_s   = eq_mean('delta_val')
t_m, t_s   = eq_mean('T0i_mean')
z_m, _     = eq_mean('z3_balance')
mes_m, mes_s = eq_mean('n_mesons')
bar_m, bar_s = eq_mean('n_baryons')
pla_m, _   = eq_mean('n_planar')
core_m, _  = eq_mean('n_cores')

log("\n"+"="*80)
log(f"FINAL SUMMARY: N={N}  beta={beta}  alpha={alpha}  seed={SEED}")
log("="*80)
log(f"  Delta (eq mean ± std):    {d_m:.5f} ± {d_s:.5f}")
log(f"  T0i mean (eq):            {t_m:.4f} ± {t_s:.4f}")
log(f"  Z3 balance (Polyakov):    {z_m:.3f}")
log(f"  Cores (eq mean):          {core_m:.1f}")
log(f"  Mesons (eq mean ± std):   {mes_m:.1f} ± {mes_s:.1f}")
log(f"  Baryons (eq mean ± std):  {bar_m:.1f} ± {bar_s:.1f}")
log(f"  Planar baryons (eq mean): {pla_m:.1f}")
log(f"")
log(f"  JSON: {os.path.join(OUTPUT_DIR,f'records_{TAG}.json')}")


# ── Save final equilibrated U field ──────────────────────────────────────────
u_path = os.path.join(OUTPUT_DIR, f'U_final_{TAG}.npy')
np.save(u_path, U)
log(f"  Saved equilibrated U field: {u_path}")
log(f"    Shape: {U.shape}  dtype: {U.dtype}  size: {U.nbytes/1e6:.1f} MB")
log("Done.")
