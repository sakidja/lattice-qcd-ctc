#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
su3_wilson_loop_validation_smeared.py

Smeared-Wilson-loop validation driver.  Imports the un-smeared engine
from su3_wilson_loop_validation.py and wraps it with optional APE
smearing on the SPATIAL links of each measured configuration.

This is a SEPARATE driver from the un-smeared one.  The original
script is untouched.

Usage
-----
    python su3_wilson_loop_validation_smeared.py \
        --beta 6.0 --L 8 --T 12 --nconf 200 \
        --smear 4 --smear-alpha 0.7

With --smear 0 (default), behaviour is identical to the un-smeared
script and filenames are NOT tagged.  With --smear N >= 1, output
files get a "_smearN" suffix:

    wloops_b6.0_L8T12_smear4.png
    wloops_b6.0_L8T12_smear4.csv
    wloops_b6.0_L8T12_smear4.log

Implementation detail: smearing is applied to a DEEP COPY of the
lattice before each measurement, so:
  * the Metropolis Markov chain runs on the un-smeared field (correct
    Wilson sampling preserved);
  * the Wilson loops are measured on the smeared spatial-link copy;
  * smearing is repeated fresh on each measured configuration.
"""

from __future__ import annotations
import argparse
import time
import sys
import copy
import numpy as np

# Re-use everything from the un-smeared engine.
from su3_wilson_loop_validation import (
    WLConfig, Lattice, metropolis_sweep,
    measure_wilson_loops,
    analyze, report, write_csv, write_figure,
    append_summary_row, emit_summary_line,
    Tee,
)

from ape_smearing import ape_smear_spatial_links


def run_smeared(wc: WLConfig, smear_levels: int = 0,
                smear_alpha: float = 0.7, verbose: bool = True):
    """Mirror of un-smeared run(), with APE smearing applied to a deep
    copy of the lattice at each measurement step.  When smear_levels=0
    the smearing is skipped entirely and behaviour matches the un-smeared
    run() exactly."""

    # Auto r_max / t_max, same defaults as un-smeared run()
    if wc.r_max == 0:
        wc.r_max = min(wc.L // 2, 5)
    if wc.t_max == 0:
        wc.t_max = min(wc.T // 2, 8)

    lat = Lattice(wc.L, wc.T, wc.beta, seed=wc.seed)

    if verbose:
        if smear_levels >= 1:
            print(f"  smearing protocol: APE x {smear_levels} levels at "
                  f"alpha = {smear_alpha}")
        else:
            print(f"  smearing protocol: none (un-smeared baseline)")
        print(f"  thermalizing {wc.n_therm} sweeps ...", flush=True)

    # Thermalize - identical to un-smeared run()
    t0 = time.time()
    for s in range(wc.n_therm):
        rate = metropolis_sweep(lat, wc.eps)
        if verbose and (s + 1) % 100 == 0:
            print(f"    therm sweep {s+1}/{wc.n_therm}   "
                  f"acc={rate:.3f}   elapsed={time.time()-t0:.1f}s",
                  flush=True)
    if verbose:
        print(f"  thermalized in {time.time()-t0:.1f}s", flush=True)

    # Equilibrium measurement loop with smearing intercept
    all_W = []
    t_m0 = time.time()
    for c in range(wc.n_conf):
        for _ in range(wc.n_sep):
            metropolis_sweep(lat, wc.eps)

        if smear_levels >= 1:
            # Smear a deep copy; the Markov chain (lat) is untouched
            lat_meas = copy.deepcopy(lat)
            ape_smear_spatial_links(lat_meas,
                                    alpha=smear_alpha,
                                    n_levels=smear_levels)
        else:
            lat_meas = lat

        W_rt = measure_wilson_loops(lat_meas, wc.r_max, wc.t_max)
        all_W.append(W_rt)
        if verbose:
            elapsed = time.time() - t_m0
            print(f"  config {c+1}/{wc.n_conf}   "
                  f"W(1,1)={W_rt[0,0]:.4f}   "
                  f"W({wc.r_max},{wc.t_max})={W_rt[-1,-1]:.2e}   "
                  f"(elapsed = {elapsed/60:.1f} min)",
                  flush=True)
    return np.stack(all_W, axis=0)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--beta", type=float, default=6.0)
    ap.add_argument("--L", type=int, default=8)
    ap.add_argument("--T", type=int, default=12)
    ap.add_argument("--nconf", type=int, default=200)
    ap.add_argument("--ntherm", type=int, default=1000)
    ap.add_argument("--nsep", type=int, default=20)
    ap.add_argument("--rmax", type=int, default=0)
    ap.add_argument("--tmax", type=int, default=0)
    ap.add_argument("--plateau_t", type=int, default=3)
    ap.add_argument("--summary_csv", type=str,
                    default="wloops_summary.csv")
    # Smearing options
    ap.add_argument("--smear", type=int, default=0,
                    help="Number of APE smearing levels (0 = none)")
    ap.add_argument("--smear-alpha", type=float, default=0.7,
                    help="APE smearing parameter alpha (default 0.7)")
    args = ap.parse_args()

    wc = WLConfig(L=args.L, T=args.T, beta=args.beta,
                  n_conf=args.nconf, n_therm=args.ntherm,
                  n_sep=args.nsep,
                  r_max=args.rmax, t_max=args.tmax)

    tag = f"b{wc.beta}_L{wc.L}T{wc.T}"
    if args.smear >= 1:
        tag = f"{tag}_smear{args.smear}"

    log_path = f"wloops_{tag}.log"

    original_stdout = sys.stdout
    log_handle = open(log_path, 'w', buffering=1)
    sys.stdout = Tee(original_stdout, log_handle)

    try:
        print(f"# su3_wilson_loop_validation_smeared.py")
        print(f"# command-line args: beta={args.beta}  L={args.L}  "
              f"T={args.T}  nconf={args.nconf}  ntherm={args.ntherm}  "
              f"nsep={args.nsep}  rmax={args.rmax}  tmax={args.tmax}  "
              f"plateau_t={args.plateau_t}  "
              f"smear={args.smear}  smear_alpha={args.smear_alpha}")
        print(f"# log file: {log_path}")
        print()

        W_stack = run_smeared(wc,
                              smear_levels=args.smear,
                              smear_alpha=args.smear_alpha)
        res = analyze(wc, W_stack, t_plateau_start=args.plateau_t)
        report(wc, res)

        write_csv(wc, W_stack, f"wloops_{tag}.csv")
        write_figure(wc, res, f"wloops_{tag}.png")
        print(f"\nWrote wloops_{tag}.csv and wloops_{tag}.png")

        if args.summary_csv:
            append_summary_row(wc, res, args.summary_csv)
            print(f"Appended summary row to {args.summary_csv}")

        print()
        print(emit_summary_line(wc, res))
    finally:
        sys.stdout = original_stdout
        log_handle.close()
        print(f"Full log written to {log_path}")


if __name__ == "__main__":
    main()
