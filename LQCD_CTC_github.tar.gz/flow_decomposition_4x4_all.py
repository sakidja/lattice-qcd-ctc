#!/usr/bin/env python3
"""
flow_decomposition_4x4_all.py

4 columns = four temporal slices (t = 0, N/4, N/2, 3N/4) at z=0.
4 rows, each the SAME slice down the column, rendered consistently:
    row 1: flow streamlines over stiffness kappa
    row 2: |div F|^2   (longitudinal / compression)
    row 3: |curl F|^2  (transverse / twist)
    row 4: kappa = 1/g (stiffness)

eq 3-9  g = sum_i|grad F_i|^2 = |div F|^2 + |curl F|^2  is tested as the GLOBAL sum
(closes; printed). Transverse fraction printed.

Run:
    python3 flow_decomposition_4x4_all.py U_final_N12_b5.0_s137.npy [sigma]
"""
import sys
import numpy as np
from scipy.ndimage import gaussian_filter
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

if len(sys.argv) < 2:
    print("usage: python3 flow_decomposition_4x4_all.py <config.npy> [sigma]"); sys.exit(1)
path=sys.argv[1]; SIG=float(sys.argv[2]) if len(sys.argv)>2 else 1.0
U=np.load(path,allow_pickle=True)
print(f"loaded {path} shape {U.shape}  sigma={SIG}")
assert U.shape[-2:]==(3,3)
ndir=U.shape[0]; lat=U.shape[1:-2]; D_=len(lat); assert D_>=4

def shift(idx,mu,s=1):
    idx=list(idx); idx[mu]=(idx[mu]+s)%lat[mu]; return tuple(idx)

print("computing flux ...")
F=[np.zeros(lat) for _ in range(3)]; mu=0
for idx in np.ndindex(lat):
    for i,nu in enumerate((1,2,3)):
        P=(U[mu][idx]@U[nu][shift(idx,mu)]@
           U[mu][shift(idx,nu)].conj().T@U[nu][idx].conj().T)
        F[i][idx]=np.trace(P).imag
if SIG>0: F=[gaussian_filter(Fi,SIG,mode="wrap") for Fi in F]
F1,F2,F3=F

def d(f,ax): return (np.roll(f,-1,axis=ax)-np.roll(f,1,axis=ax))/2.0
div=d(F1,0)+d(F2,1)+d(F3,2); D2=div**2
cx=d(F3,1)-d(F2,2); cy=d(F1,2)-d(F3,0); cz=d(F2,0)-d(F1,1)
T2=cx**2+cy**2+cz**2
g=np.zeros(lat)
for Fi in (F1,F2,F3):
    for ax in (0,1,2): g+=d(Fi,ax)**2
kappa=np.where(g>0,1.0/g,0.0)

sg=g.sum(); sDT=(D2+T2).sum()
print(f"\neq 3-9 global residual = {abs(sg-sDT)/sg:.3%}   transverse fraction = {T2.sum()/sDT:.1%}")

Nt=lat[3]; tpos=[0,Nt//4,Nt//2,3*Nt//4]; z0=0
Lx,Ly=lat[0],lat[1]; xs=np.arange(Lx); ys=np.arange(Ly)
# consistent scales across all columns
kmax=np.percentile(kappa,97)
d2max=np.percentile(D2,99); t2max=np.percentile(T2,99)

fig,axes=plt.subplots(4,4,figsize=(20,18))
fig.subplots_adjust(left=0.04, right=0.90, top=0.93, bottom=0.04, wspace=0.18, hspace=0.22)
for c,tt in enumerate(tpos):
    kap=kappa[:,:,z0,tt].T; dd=D2[:,:,z0,tt].T; ttw=T2[:,:,z0,tt].T
    fxs=F1[:,:,z0,tt].T; fys=F2[:,:,z0,tt].T
    fmag=np.sqrt(fxs**2+fys**2)
    IN="bilinear"  # smooth interpolated rendering (display only; does not change data)
    # row 1: flow streamlines only (matches Figure 2 style; colored by |F|, no kappa underneath)
    a=axes[0,c]
    strm=a.streamplot(xs,ys,fxs,fys,color=fmag,cmap="viridis",density=1.4,linewidth=0.7,arrowsize=0.7)
    a.set_title(f"flow Im Tr P$_{{0i}}$   t={tt}",fontsize=10)
    a.set_xlim(0,Lx-1); a.set_ylim(0,Ly-1); a.set_facecolor("white")
    im=strm.lines  # for the colorbar
    # row 2: longitudinal
    a=axes[1,c]; im2=a.imshow(dd,origin="lower",cmap="cividis",vmin=0,vmax=d2max,interpolation=IN); a.set_title(f"|div F|² (long.)  t={tt}",fontsize=10)
    # row 3: transverse
    a=axes[2,c]; im3=a.imshow(ttw,origin="lower",cmap="inferno",vmin=0,vmax=t2max,interpolation=IN); a.set_title(f"|curl F|² (twist)  t={tt}",fontsize=10)
    # row 4: kappa
    a=axes[3,c]; im4=a.imshow(kap,origin="lower",cmap="viridis",vmin=0,vmax=kmax,interpolation=IN); a.set_title(f"κ=1/g  t={tt}",fontsize=10)
# one colorbar per row, placed explicitly to the right (not overlapping panels)
def add_row_cbar(im, row, label):
    pos=axes[row,-1].get_position()
    cax=fig.add_axes([0.915, pos.y0, 0.012, pos.height])
    fig.colorbar(im, cax=cax, label=label)
add_row_cbar(im,  0, "|F|")
add_row_cbar(im2, 1, "|div F|²")
add_row_cbar(im3, 2, "|curl F|²")
add_row_cbar(im4, 3, "κ")
fig.suptitle(f"{path.split('/')[-1]} (σ={SIG}, no α): 4 slices × [flow/κ, longitudinal, transverse, κ]\n"
             f"eq 3-9 global residual {abs(sg-sDT)/sg:.2%}, transverse {T2.sum()/sDT:.0%} of gradient energy",
             fontsize=13)
fig.savefig("flow_decomposition_4x4.png",dpi=110,bbox_inches="tight")
print("saved flow_decomposition_4x4.png")
