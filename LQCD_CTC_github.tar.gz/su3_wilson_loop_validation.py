#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
su3_wilson_loop_validation.py

SU(3) Wilson Monte Carlo, then measure planar rectangular Wilson loops
W(r, t) at the equilibrium gauge configurations. Extract the static
QQbar potential V(r) from the plateau of the effective potential
V_eff(r, t) = -log[ W(r, t) / W(r, t-1) ], then fit V(r) to the
Cornell form

    V(r) = -A/r + sigma * r + C

and compare the extracted string tension sigma to published lattice
SU(3) values (Bali & Schilling 1992; Takahashi & Suganuma 2002).

Designed to slot into the same validation pipeline as
su3_plaquette_validation.py and reuse the same Metropolis engine.
Defaults target the early-stage validation runs:
    Stage 1: --L 6  --T 8   --nconf 64
    Stage 2: --L 8  --T 16  --nconf 64
both at --beta 6.0.

Output:
    wloops_b{beta}_L{L}T{T}.csv  -- raw <W(r,t)> per configuration
    wloops_b{beta}_L{L}T{T}.png  -- four-panel diagnostic figure
"""

from __future__ import annotations
import numpy as np
from dataclasses import dataclass
from itertools import product
import argparse
import time
import csv

# Reuse the existing engine. If the import fails the user is told to
# place this script next to su3_plaquette_validation.py.
try:
    from su3_plaquette_validation import (
        Lattice, metropolis_sweep, I3
    )
except ImportError:
    raise SystemExit(
        "Could not import from su3_plaquette_validation. "
        "Place this script in the same directory."
    )

np.set_printoptions(precision=5, suppress=True)


# ----------------------------------------------------------------------
# Wilson loop construction
# ----------------------------------------------------------------------

def spatial_line(lat: Lattice, site, mu_s, r):
    """Product of r consecutive spatial links in direction mu_s starting
    at site. Returns a 3x3 SU(3) matrix."""
    M = I3.copy()
    s = site
    for _ in range(r):
        M = M @ lat.link(s, mu_s)
        s = lat.shift(s, mu_s)
    return M


def temporal_line(lat: Lattice, site, t):
    """Product of t consecutive temporal links (mu=3) starting at site."""
    M = I3.copy()
    s = site
    for _ in range(t):
        M = M @ lat.link(s, 3)
        s = lat.shift(s, 3)
    return M


def wilson_loop(lat: Lattice, site, mu_s, r, t):
    """Planar rectangular Wilson loop W(r, t) of size r (spatial, in
    direction mu_s) by t (temporal), with one corner at site.

    Path:  site --r--> site_r --t--> site_rt --(-r)--> site_t --(-t)--> site
    Equivalently: U_s(r) at site, U_t(t) at site+r, U_s(r)^dag at site+t,
    U_t(t)^dag at site.
    """
    s = site
    s_r = s
    for _ in range(r):
        s_r = lat.shift(s_r, mu_s)
    s_t = s
    for _ in range(t):
        s_t = lat.shift(s_t, 3)

    U1 = spatial_line(lat, s, mu_s, r)
    U2 = temporal_line(lat, s_r, t)
    U3 = spatial_line(lat, s_t, mu_s, r).conj().T
    U4 = temporal_line(lat, s, t).conj().T
    return U1 @ U2 @ U3 @ U4


def measure_wilson_loops(lat: Lattice, r_max: int, t_max: int):
    """Return a 2D array W[r-1, t-1] of <Re Tr W(r,t)> / 3 averaged
    over the three spatial directions and over all spatial origins,
    for r in [1, r_max] and t in [1, t_max]."""
    W = np.zeros((r_max, t_max), dtype=np.float64)
    count = np.zeros((r_max, t_max), dtype=np.int64)

    for site in product(range(lat.L), range(lat.L),
                        range(lat.L), range(lat.T)):
        for mu_s in (0, 1, 2):
            for r in range(1, r_max + 1):
                for t in range(1, t_max + 1):
                    M = wilson_loop(lat, site, mu_s, r, t)
                    W[r-1, t-1] += np.real(np.trace(M)) / 3.0
                    count[r-1, t-1] += 1
    return W / np.maximum(count, 1)


# ----------------------------------------------------------------------
# Effective potential and Cornell fit
# ----------------------------------------------------------------------

def effective_potential(W_rt: np.ndarray):
    """Given W[r-1, t-1], return V_eff[r-1, t-1] = -log(W(r,t)/W(r,t-1)).
    The t=1 column is -log(W(r,1)) (no predecessor); we drop it for the
    plateau fit but keep it for inspection.

    Filters out non-positive or NaN ratios."""
    nr, nt = W_rt.shape
    V_eff = np.full((nr, nt), np.nan, dtype=np.float64)
    # t=1 col: just -log W(r,1)
    pos1 = W_rt[:, 0] > 0
    V_eff[pos1, 0] = -np.log(W_rt[pos1, 0])
    for t_idx in range(1, nt):
        ratio = W_rt[:, t_idx] / W_rt[:, t_idx - 1]
        ok = (ratio > 0) & np.isfinite(ratio)
        V_eff[ok, t_idx] = -np.log(ratio[ok])
    return V_eff


def plateau_potential(V_eff: np.ndarray, t_plateau_start: int = 3):
    """Average V_eff over t indices >= t_plateau_start to get V(r),
    with one-sigma run-to-run scatter as the uncertainty.

    Inputs use 0-based indexing on the t axis; t_plateau_start=3 means
    start at t=4 (t_idx=3). If the slice is empty, returns NaN arrays
    so downstream code can detect and report cleanly."""
    if t_plateau_start >= V_eff.shape[1]:
        # Plateau region is empty: t_max too small for the chosen
        # starting index. Return NaN arrays of the right shape.
        nan_r = np.full(V_eff.shape[0], np.nan)
        return nan_r, nan_r.copy()
    seg = V_eff[:, t_plateau_start:]
    # Mean and std ignoring nans; suppress the empty-slice warning
    # since we now handle that case above.
    with np.errstate(invalid='ignore'):
        V_r = np.nanmean(seg, axis=1)
        sig_r = np.nanstd(seg, axis=1, ddof=1) if seg.shape[1] > 1 else \
            np.zeros_like(V_r)
    return V_r, sig_r


def cornell_fit(r_vals: np.ndarray, V_r: np.ndarray, sig_r: np.ndarray):
    """Fit V(r) = -A/r + sigma * r + C using weighted least squares.
    Returns (A, sigma, C, cov, chi2_per_dof), or (nan, nan, nan, None,
    nan) if there are fewer than 3 usable r-points (underdetermined).

    If sig_r values are all zero or non-finite (e.g. plateau averaged
    over a single t-point so the run-to-run std is undefined), uniform
    weights are used instead of dropping the points. In that case
    chi2_per_dof should be interpreted with caution."""
    finite_V = np.isfinite(V_r) & np.isfinite(r_vals) & (r_vals > 0)
    finite_s = np.isfinite(sig_r) & (sig_r > 0)
    used_uniform_weights = False
    if not np.any(finite_s):
        # No usable sigma values: fall back to uniform weights
        mask = finite_V
        used_uniform_weights = True
    else:
        mask = finite_V & finite_s
    r = r_vals[mask].astype(float)
    V = V_r[mask].astype(float)
    if used_uniform_weights:
        s = np.ones_like(V)
    else:
        s = sig_r[mask].astype(float)

    if len(r) < 3:
        # Underdetermined: 3 parameters need at least 3 r-points
        nan = float('nan')
        return nan, nan, nan, None, nan

    # Design matrix: columns [-1/r, r, 1]
    X = np.stack([-1.0 / r, r, np.ones_like(r)], axis=1)
    Wd = np.diag(1.0 / s**2)
    XtWX = X.T @ Wd @ X
    XtWy = X.T @ Wd @ V
    try:
        params = np.linalg.solve(XtWX, XtWy)
        cov = np.linalg.inv(XtWX)
    except np.linalg.LinAlgError:
        nan = float('nan')
        return nan, nan, nan, None, nan
    A, sigma, C = params
    resid = V - X @ params
    chi2 = float(np.sum((resid / s) ** 2))
    dof = max(len(r) - 3, 1)
    return A, sigma, C, cov, chi2 / dof


# ----------------------------------------------------------------------
# Reference values
# ----------------------------------------------------------------------

SIGMA_BENCH = {
    # sigma in lattice units, quenched SU(3) Wilson
    5.7: 0.123,    # ~ Bali-Schilling regime, larger sigma at coarser beta
    5.8: 0.075,
    6.0: 0.0513,   # Bali & Schilling 1992 canonical
    6.2: 0.030,
}


# ----------------------------------------------------------------------
# Driver
# ----------------------------------------------------------------------

@dataclass
class WLConfig:
    L: int = 6
    T: int = 8
    beta: float = 6.0
    seed: int = 42
    n_therm: int = 1000
    n_sep: int = 20
    n_conf: int = 64
    eps: float = 0.20
    r_max: int = 0          # 0 means auto: min(L//2, 5)
    t_max: int = 0          # 0 means auto: min(T//2, 8)


def run(wc: WLConfig, verbose: bool = True):
    if wc.r_max == 0:
        wc.r_max = min(wc.L // 2, 5)
    if wc.t_max == 0:
        wc.t_max = min(wc.T // 2, 8)

    lat = Lattice(wc.L, wc.T, wc.beta, seed=wc.seed)

    # Thermalize
    t0 = time.time()
    if verbose:
        print(f"  thermalizing {wc.n_therm} sweeps ...", flush=True)
    for s in range(wc.n_therm):
        rate = metropolis_sweep(lat, wc.eps)
        if verbose and (s + 1) % 100 == 0:
            print(f"    therm sweep {s+1}/{wc.n_therm}   "
                  f"acc={rate:.3f}   elapsed={time.time()-t0:.1f}s",
                  flush=True)
    if verbose:
        print(f"  thermalized in {time.time()-t0:.1f}s", flush=True)

    # Equilibrium loop measurements
    all_W = []
    t_m0 = time.time()
    for c in range(wc.n_conf):
        for _ in range(wc.n_sep):
            metropolis_sweep(lat, wc.eps)
        W_rt = measure_wilson_loops(lat, wc.r_max, wc.t_max)
        all_W.append(W_rt)
        if verbose:
            elapsed = time.time() - t_m0
            print(f"  config {c+1}/{wc.n_conf}   "
                  f"W(1,1)={W_rt[0,0]:.4f}   "
                  f"W({wc.r_max},{wc.t_max})={W_rt[-1,-1]:.2e}   "
                  f"(elapsed = {elapsed/60:.1f} min)",
                  flush=True)
    return np.stack(all_W, axis=0)   # shape (n_conf, r_max, t_max)


def analyze(wc: WLConfig, W_stack: np.ndarray, t_plateau_start: int = 3):
    """Mean over configs, effective potential, plateau, Cornell fit."""
    W_mean = W_stack.mean(axis=0)
    W_err = W_stack.std(axis=0, ddof=1) / np.sqrt(W_stack.shape[0])
    V_eff = effective_potential(W_mean)
    V_r, sig_r = plateau_potential(V_eff, t_plateau_start)
    r_vals = np.arange(1, wc.r_max + 1, dtype=float)
    A, sigma, C, cov, chi2_dof = cornell_fit(r_vals, V_r, sig_r)
    return {
        'W_mean': W_mean,
        'W_err': W_err,
        'V_eff': V_eff,
        'V_r': V_r,
        'sig_r': sig_r,
        'A': A, 'sigma': sigma, 'C': C,
        'cov': cov, 'chi2_dof': chi2_dof,
        'r_vals': r_vals,
    }


def report(wc: WLConfig, res: dict):
    print("=" * 70)
    print(f"SU(3) Wilson-loop validation  (beta = {wc.beta}, "
          f"L^3 x T = {wc.L}^3 x {wc.T}, n_conf = {wc.n_conf})")
    print("=" * 70)

    sigma_ref = SIGMA_BENCH.get(wc.beta, float('nan'))

    if not np.isfinite(res['sigma']):
        print(f"  FIT UNDERDETERMINED  -- fewer than 3 usable r-points; "
              f"Cornell parameters could not be extracted.")
        print(f"  Need at least 3 distinct r values to fit "
              f"V(r) = -A/r + sigma*r + C.")
        print(f"  On this lattice r_max = {wc.r_max}; rerun with a "
              f"larger spatial extent L or a larger --rmax.")
    else:
        print(f"  Cornell fit  V(r) = -A/r + sigma * r + C")
        print(f"    A     = {res['A']:.4f}")
        print(f"    sigma = {res['sigma']:.4f}   "
              f"(reference {sigma_ref:.4f}, "
              f"delta = "
              f"{(res['sigma']-sigma_ref)/sigma_ref*100:+.1f}%)")
        print(f"    C     = {res['C']:.4f}")
        print(f"    chi2/dof = {res['chi2_dof']:.2f}")

    print(f"  V_eff plateau (r, V(r) +/- sig_r):")
    for i, r in enumerate(res['r_vals']):
        print(f"    r={int(r)}:  V={res['V_r'][i]:.4f}  "
              f"+/- {res['sig_r'][i]:.4f}")


def write_csv(wc: WLConfig, W_stack: np.ndarray, path: str):
    n_conf, n_r, n_t = W_stack.shape
    with open(path, 'w', newline='') as f:
        w = csv.writer(f)
        w.writerow(['config', 'r', 't', 'W'])
        for c in range(n_conf):
            for ri in range(n_r):
                for ti in range(n_t):
                    w.writerow([c, ri + 1, ti + 1, W_stack[c, ri, ti]])


def write_figure(wc: WLConfig, res: dict, path: str):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt

    fig, axes = plt.subplots(2, 2, figsize=(13, 9))
    fig.suptitle(
        f"SU(3) Wilson-loop validation  "
        f"(beta = {wc.beta}, L^3 x T = {wc.L}^3 x {wc.T}, "
        f"n_conf = {wc.n_conf})",
        fontsize=12)

    # (a) log W(r, t) vs t for each r
    ax = axes[0, 0]
    for ri in range(wc.r_max):
        y = res['W_mean'][ri, :]
        ok = y > 0
        ax.semilogy(np.arange(1, wc.t_max + 1)[ok], y[ok],
                    'o-', label=f"r={ri+1}")
    ax.set_xlabel("t  (lattice units)")
    ax.set_ylabel("<W(r, t)>")
    ax.set_title("(a) Wilson loops, log scale")
    ax.legend(fontsize=8, ncol=2)
    ax.grid(True, alpha=0.3)

    # (b) effective potential V_eff(r, t) vs t for each r, with plateau
    ax = axes[0, 1]
    for ri in range(wc.r_max):
        ax.plot(np.arange(1, wc.t_max + 1), res['V_eff'][ri, :],
                'o-', label=f"r={ri+1}")
    ax.set_xlabel("t  (lattice units)")
    ax.set_ylabel("V_eff(r, t) = -log[W(r,t)/W(r,t-1)]")
    ax.set_title("(b) Effective potential, plateau extraction")
    ax.legend(fontsize=8, ncol=2)
    ax.grid(True, alpha=0.3)

    # (c) V(r) plateau values vs r, with Cornell fit overlaid
    ax = axes[1, 0]
    ax.errorbar(res['r_vals'], res['V_r'], yerr=res['sig_r'],
                fmt='o', capsize=3, label='plateau V(r)')
    fit_ok = np.isfinite(res['sigma'])
    if fit_ok:
        r_fine = np.linspace(0.6, wc.r_max + 0.5, 200)
        V_fit = -res['A'] / r_fine + res['sigma'] * r_fine + res['C']
        ax.plot(r_fine, V_fit, '-',
                label=f"Cornell: -A/r + sigma*r + C\n"
                      f"sigma = {res['sigma']:.4f}")
        sigma_ref = SIGMA_BENCH.get(wc.beta, float('nan'))
        if np.isfinite(sigma_ref):
            ax.axhline(0, color='gray', lw=0.5)
            ax.text(0.05, 0.95,
                    f"reference sigma (beta={wc.beta}) = "
                    f"{sigma_ref:.4f}\n"
                    f"measured = {res['sigma']:.4f}\n"
                    f"delta = "
                    f"{(res['sigma']-sigma_ref)/sigma_ref*100:+.1f}%",
                    transform=ax.transAxes, fontsize=9,
                    verticalalignment='top',
                    bbox=dict(boxstyle='round', facecolor='white',
                              alpha=0.8))
    else:
        ax.text(0.5, 0.5,
                f"FIT UNDERDETERMINED\n(need r_max >= 3, "
                f"have r_max = {wc.r_max})",
                transform=ax.transAxes, fontsize=11,
                ha='center', va='center', color='firebrick',
                bbox=dict(boxstyle='round', facecolor='mistyrose',
                          alpha=0.9))
    ax.set_xlabel("r  (lattice units)")
    ax.set_ylabel("V(r)")
    ax.set_title("(c) Static potential and Cornell fit")
    ax.legend(fontsize=9, loc='lower right')
    ax.grid(True, alpha=0.3)

    # (d) residuals of the Cornell fit
    ax = axes[1, 1]
    if fit_ok:
        r = res['r_vals']
        V_pred = -res['A'] / r + res['sigma'] * r + res['C']
        resid = res['V_r'] - V_pred
        ax.errorbar(r, resid, yerr=res['sig_r'], fmt='o', capsize=3)
        ax.axhline(0, color='gray', lw=0.5)
        ax.set_title(f"(d) Cornell-fit residuals  "
                     f"(chi2/dof = {res['chi2_dof']:.2f})")
    else:
        ax.text(0.5, 0.5, "no fit",
                transform=ax.transAxes, fontsize=11,
                ha='center', va='center', color='gray')
        ax.set_title("(d) Cornell-fit residuals  (no fit available)")
    ax.set_xlabel("r  (lattice units)")
    ax.set_ylabel("V_data - V_fit")
    ax.grid(True, alpha=0.3)

    plt.tight_layout()
    fig.savefig(path, dpi=130)
    plt.close(fig)


# ----------------------------------------------------------------------
# CLI
# ----------------------------------------------------------------------

class Tee:
    """Mirror stdout writes to one or more file handles.

    Used to capture the full per-run log to disk without losing the
    live console output."""

    def __init__(self, *streams):
        self.streams = streams

    def write(self, data):
        for s in self.streams:
            s.write(data)
            s.flush()

    def flush(self):
        for s in self.streams:
            s.flush()


def emit_summary_line(wc: WLConfig, res: dict) -> str:
    """One-line, fixed-format summary suitable for grep / paste-into-
    table. Always emitted last after report()."""
    sigma_ref = SIGMA_BENCH.get(wc.beta, float('nan'))
    if np.isfinite(sigma_ref) and sigma_ref != 0:
        d_pct = (res['sigma'] - sigma_ref) / sigma_ref * 100
        d_str = f"{d_pct:+.1f}%"
    else:
        d_str = "n/a"
    return (
        f"SUMMARY  beta={wc.beta}  L={wc.L}  T={wc.T}  "
        f"n_conf={wc.n_conf}  n_therm={wc.n_therm}  "
        f"A={res['A']:.4f}  sigma={res['sigma']:.4f}  "
        f"C={res['C']:.4f}  chi2_dof={res['chi2_dof']:.2f}  "
        f"sigma_ref={sigma_ref:.4f}  delta_sigma={d_str}"
    )


def append_summary_row(wc: WLConfig, res: dict, path: str):
    """Append one row to the cumulative summary CSV, creating the file
    with a header if it doesn't yet exist."""
    import os
    sigma_ref = SIGMA_BENCH.get(wc.beta, float('nan'))
    if np.isfinite(sigma_ref) and sigma_ref != 0:
        d_pct = (res['sigma'] - sigma_ref) / sigma_ref * 100
    else:
        d_pct = float('nan')
    new_file = not os.path.exists(path)
    with open(path, 'a', newline='') as f:
        w = csv.writer(f)
        if new_file:
            w.writerow(['beta', 'L', 'T', 'n_conf', 'n_therm',
                        'A', 'sigma', 'C', 'chi2_dof',
                        'sigma_ref', 'delta_sigma_pct'])
        w.writerow([wc.beta, wc.L, wc.T, wc.n_conf, wc.n_therm,
                    f"{res['A']:.6f}", f"{res['sigma']:.6f}",
                    f"{res['C']:.6f}", f"{res['chi2_dof']:.4f}",
                    f"{sigma_ref:.6f}", f"{d_pct:.4f}"])


def main():
    import sys

    ap = argparse.ArgumentParser()
    ap.add_argument("--beta", type=float, default=6.0)
    ap.add_argument("--L", type=int, default=6)
    ap.add_argument("--T", type=int, default=8)
    ap.add_argument("--nconf", type=int, default=64)
    ap.add_argument("--ntherm", type=int, default=1000)
    ap.add_argument("--nsep", type=int, default=20)
    ap.add_argument("--rmax", type=int, default=0,
                    help="0 = auto (min(L//2, 5))")
    ap.add_argument("--tmax", type=int, default=0,
                    help="0 = auto (min(T//2, 8))")
    ap.add_argument("--plateau_t", type=int, default=3,
                    help="t index at which to start the plateau "
                         "average; default 3 means t>=4")
    ap.add_argument("--summary_csv", type=str,
                    default="wloops_summary.csv",
                    help="Cumulative summary CSV path. Each run "
                         "appends one row. Set to empty string to "
                         "disable.")
    args = ap.parse_args()

    wc = WLConfig(L=args.L, T=args.T, beta=args.beta,
                  n_conf=args.nconf, n_therm=args.ntherm,
                  n_sep=args.nsep,
                  r_max=args.rmax, t_max=args.tmax)

    tag = f"b{wc.beta}_L{wc.L}T{wc.T}"
    log_path = f"wloops_{tag}.log"

    # Open log file and tee stdout to it. Everything from this point
    # on (including report(), the SUMMARY line, and the file-writing
    # confirmations) is captured.
    original_stdout = sys.stdout
    log_handle = open(log_path, 'w', buffering=1)
    sys.stdout = Tee(original_stdout, log_handle)

    try:
        print(f"# su3_wilson_loop_validation.py")
        print(f"# command-line args: beta={args.beta}  L={args.L}  "
              f"T={args.T}  nconf={args.nconf}  ntherm={args.ntherm}  "
              f"nsep={args.nsep}  rmax={args.rmax}  tmax={args.tmax}  "
              f"plateau_t={args.plateau_t}")
        print(f"# log file: {log_path}")
        print()

        W_stack = run(wc)
        res = analyze(wc, W_stack, t_plateau_start=args.plateau_t)
        report(wc, res)

        write_csv(wc, W_stack, f"wloops_{tag}.csv")
        write_figure(wc, res, f"wloops_{tag}.png")
        print(f"\nWrote wloops_{tag}.csv and wloops_{tag}.png")

        # Cumulative summary table (one row per run)
        if args.summary_csv:
            append_summary_row(wc, res, args.summary_csv)
            print(f"Appended summary row to {args.summary_csv}")

        # Fixed-format one-line summary, always last so it's easy to
        # grep across many run logs.
        print()
        print(emit_summary_line(wc, res))
    finally:
        sys.stdout = original_stdout
        log_handle.close()
        print(f"Full log written to {log_path}")


if __name__ == "__main__":
    main()
